package com.example.upgradetool;

import com.example.upgradetool.commands.UpgradeCommand;
import com.example.upgradetool.gui.UpgradeGUIListener;
import com.example.upgradetool.listeners.Mine3x3Listener;
import com.example.upgradetool.managers.EconomyManager;
import com.example.upgradetool.managers.UpgradeManager;
import org.bukkit.plugin.java.JavaPlugin;

public class UpgradeToolPlugin extends JavaPlugin {

    private static UpgradeToolPlugin instance;
    private UpgradeManager upgradeManager;
    private EconomyManager economyManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.upgradeManager  = new UpgradeManager(this);
        this.economyManager  = new EconomyManager(this);

        // Register command
        UpgradeCommand upgradeCommand = new UpgradeCommand(this);
        getCommand("upgradetool").setExecutor(upgradeCommand);
        getCommand("upgradetool").setTabCompleter(upgradeCommand);

        // Register GUI listener
        getServer().getPluginManager().registerEvents(new UpgradeGUIListener(this), this);

        // Register Mine 3x3 listener
        getServer().getPluginManager().registerEvents(new Mine3x3Listener(this), this);

        getLogger().info("UpgradeTool plugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("UpgradeTool plugin disabled!");
    }

    public static UpgradeToolPlugin getInstance() {
        return instance;
    }

    public UpgradeManager getUpgradeManager() {
        return upgradeManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }
}
