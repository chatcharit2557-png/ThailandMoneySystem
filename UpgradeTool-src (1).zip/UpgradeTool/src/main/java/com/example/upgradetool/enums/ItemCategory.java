package com.example.upgradetool.enums;

import org.bukkit.Material;
import java.util.Arrays;
import java.util.List;

public enum ItemCategory {

    PICKAXE(Arrays.asList(
        Material.WOODEN_PICKAXE, Material.STONE_PICKAXE, Material.IRON_PICKAXE,
        Material.GOLDEN_PICKAXE, Material.DIAMOND_PICKAXE, Material.NETHERITE_PICKAXE
    ), "§6⛏ จอบขุด"),

    SWORD(Arrays.asList(
        Material.WOODEN_SWORD, Material.STONE_SWORD, Material.IRON_SWORD,
        Material.GOLDEN_SWORD, Material.DIAMOND_SWORD, Material.NETHERITE_SWORD
    ), "§c⚔ ดาบ"),

    AXE(Arrays.asList(
        Material.WOODEN_AXE, Material.STONE_AXE, Material.IRON_AXE,
        Material.GOLDEN_AXE, Material.DIAMOND_AXE, Material.NETHERITE_AXE
    ), "§e🪓 ขวาน"),

    SHOVEL(Arrays.asList(
        Material.WOODEN_SHOVEL, Material.STONE_SHOVEL, Material.IRON_SHOVEL,
        Material.GOLDEN_SHOVEL, Material.DIAMOND_SHOVEL, Material.NETHERITE_SHOVEL
    ), "§a🪣 พลั่ว"),

    HOE(Arrays.asList(
        Material.WOODEN_HOE, Material.STONE_HOE, Material.IRON_HOE,
        Material.GOLDEN_HOE, Material.DIAMOND_HOE, Material.NETHERITE_HOE
    ), "§b🌾 จอบ"),

    BOW(Arrays.asList(
        Material.BOW, Material.CROSSBOW
    ), "§d🏹 ธนู"),

    ARMOR(Arrays.asList(
        Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS,
        Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS,
        Material.GOLDEN_HELMET, Material.GOLDEN_CHESTPLATE, Material.GOLDEN_LEGGINGS, Material.GOLDEN_BOOTS,
        Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS,
        Material.NETHERITE_HELMET, Material.NETHERITE_CHESTPLATE, Material.NETHERITE_LEGGINGS, Material.NETHERITE_BOOTS,
        Material.CHAINMAIL_HELMET, Material.CHAINMAIL_CHESTPLATE, Material.CHAINMAIL_LEGGINGS, Material.CHAINMAIL_BOOTS
    ), "§9🛡 เกราะ");

    private final List<Material> materials;
    private final String displayName;

    ItemCategory(List<Material> materials, String displayName) {
        this.materials = materials;
        this.displayName = displayName;
    }

    public List<Material> getMaterials() { return materials; }
    public String getDisplayName() { return displayName; }

    public static ItemCategory fromMaterial(Material material) {
        for (ItemCategory cat : values()) {
            if (cat.materials.contains(material)) return cat;
        }
        return null;
    }

    public boolean matches(Material material) {
        return materials.contains(material);
    }
}
