package com.example.upgradetool.gui;

import com.example.upgradetool.UpgradeToolPlugin;
import com.example.upgradetool.enums.ItemCategory;
import com.example.upgradetool.enums.UpgradeType;
import com.example.upgradetool.managers.EconomyManager;
import com.example.upgradetool.managers.UpgradeManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class UpgradeGUI {

    // Inventory title (used as ID)
    public static final String GUI_TITLE = "§8§l⚒ Upgrade Tool";

    // Slot constants
    public static final int ITEM_SLOT        = 13;  // Center – place your item here
    public static final int FAST_MINE_SLOT   = 28;
    public static final int MINE_3X3_SLOT    = 29;
    public static final int STRONG_ATK_SLOT  = 32;
    public static final int FAST_ATK_SLOT    = 33;
    public static final int CONFIRM_SLOT     = 49;
    public static final int CLOSE_SLOT       = 45;

    private final UpgradeToolPlugin plugin;
    private final UpgradeManager manager;
    private final EconomyManager economy;

    public UpgradeGUI(UpgradeToolPlugin plugin) {
        this.plugin   = plugin;
        this.manager  = plugin.getUpgradeManager();
        this.economy  = plugin.getEconomyManager();
    }

    public void open(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, GUI_TITLE);
        fillBorder(gui);
        setupStaticItems(gui, null, player);
        player.openInventory(gui);
    }

    public void refresh(Inventory gui, ItemStack heldItem, Player player) {
        ItemStack item = gui.getItem(ITEM_SLOT);
        if (item == null || item.getType().isAir()) item = null;
        setupStaticItems(gui, item, player);
    }

    private void setupStaticItems(Inventory gui, ItemStack heldItem, Player player) {
        // Item slot indicator
        if (gui.getItem(ITEM_SLOT) == null || (gui.getItem(ITEM_SLOT) != null && gui.getItem(ITEM_SLOT).getType() == Material.GRAY_STAINED_GLASS_PANE)) {
            gui.setItem(ITEM_SLOT, makeGlass(Material.LIME_STAINED_GLASS_PANE, "§a§lวางอุปกรณ์ที่นี่", List.of("§7ลากอุปกรณ์มาวางในช่องนี้")));
        }

        ItemStack item = gui.getItem(ITEM_SLOT);
        if (item != null && item.getType() == Material.LIME_STAINED_GLASS_PANE) item = null;

        ItemCategory cat = item != null ? ItemCategory.fromMaterial(item.getType()) : null;

        // === PICKAXE UPGRADES ===
        boolean pickaxe = cat == ItemCategory.PICKAXE;
        int fm = item != null ? manager.getUpgradeLevel(item, UpgradeType.FAST_MINE)  : 0;
        int m3 = item != null ? manager.getUpgradeLevel(item, UpgradeType.MINE_3X3)   : 0;

        gui.setItem(FAST_MINE_SLOT,  makeUpgradeButton(UpgradeType.FAST_MINE,  pickaxe, fm, item, player));
        gui.setItem(MINE_3X3_SLOT,   makeUpgradeButton(UpgradeType.MINE_3X3,   pickaxe, m3, item, player));

        // === SWORD UPGRADES ===
        boolean sword = cat == ItemCategory.SWORD;
        int sa = item != null ? manager.getUpgradeLevel(item, UpgradeType.STRONG_ATTACK) : 0;
        int fa = item != null ? manager.getUpgradeLevel(item, UpgradeType.FAST_ATTACK)   : 0;

        gui.setItem(STRONG_ATK_SLOT, makeUpgradeButton(UpgradeType.STRONG_ATTACK, sword, sa, item, player));
        gui.setItem(FAST_ATK_SLOT,   makeUpgradeButton(UpgradeType.FAST_ATTACK,   sword, fa, item, player));

        // Category labels
        gui.setItem(27, makeLabel(Material.IRON_PICKAXE,  "§e§l⛏ Pickaxe Upgrades", List.of("§7สำหรับจอบขุดเท่านั้น")));
        gui.setItem(31, makeLabel(Material.IRON_SWORD,    "§c§l⚔ Sword Upgrades",    List.of("§7สำหรับดาบเท่านั้น")));

        // Confirm button
        if (item != null && cat != null) {
            gui.setItem(CONFIRM_SLOT, makeGlass(Material.GREEN_STAINED_GLASS_PANE,
                "§a§l✔ เลือก Upgrade แล้วคลิก",
                List.of("§7คลิกที่ปุ่ม upgrade เพื่ออัปเกรด")));
        } else {
            gui.setItem(CONFIRM_SLOT, makeGlass(Material.GRAY_STAINED_GLASS_PANE,
                "§7§lรอวางอุปกรณ์...",
                List.of("§7วางอุปกรณ์ในช่องกลางก่อน")));
        }

        // Close
        gui.setItem(CLOSE_SLOT, makeLabel(Material.BARRIER, "§c§l✖ ปิด", List.of("§7ปิดหน้าต่างนี้")));

        // Info panel – show player balance
        String balLabel = economy.isVaultEnabled() ? "§a💰 เงินคงเหลือ" : "§b⭐ EXP คงเหลือ";
        String balValue = "§f" + economy.formatBalance(player);
        String costNote = economy.isVaultEnabled()
            ? "§7ราคาเพิ่มขึ้น §ex2 §7ทุก level"
            : "§7ราคาเพิ่มขึ้น §ex2 §7ทุก level (EXP)";
        gui.setItem(4, makeLabel(Material.BOOK, "§b§lวิธีใช้",
            List.of("§71. วางอุปกรณ์ในช่องกลาง",
                    "§72. คลิกที่ Upgrade ที่ต้องการ",
                    "§73. ระบบจะ upgrade อัตโนมัติ",
                    "§8──────────",
                    balLabel + "§8: " + balValue,
                    costNote)));
    }

    private ItemStack makeUpgradeButton(UpgradeType type, boolean compatible, int currentLevel, ItemStack target, Player player) {
        int maxLevel = manager.getMaxLevel(type);
        boolean maxed = currentLevel >= maxLevel;

        Material mat;
        List<String> lore = new ArrayList<>();

        if (!compatible) {
            // Incompatible – show locked
            mat = Material.RED_STAINED_GLASS_PANE;
            lore.add("§c§l🔒 ล็อค");
            lore.add("§7ต้องการ: " + type.getCategory().getDisplayName());
            lore.add("§7อุปกรณ์ปัจจุบันไม่ใช่ประเภทนี้");
            ItemStack btn = new ItemStack(mat);
            ItemMeta m = btn.getItemMeta();
            m.setDisplayName(type.getDisplayName() + " §8[§cล็อค§8]");
            m.setLore(lore);
            btn.setItemMeta(m);
            return btn;
        } else if (maxed) {
            mat = Material.GOLD_BLOCK;
            lore.add("§6§l★ MAX LEVEL ★");
            lore.add(type.getDescription());
            lore.add("§8──────────");
            lore.add("§aอัปเกรดเต็มแล้ว!");
        } else {
            // Check affordability to tint the button
            boolean canAfford = economy.canAfford(player, type, currentLevel);
            mat = canAfford ? Material.LIME_DYE : Material.GRAY_DYE;

            int nextLevel = currentLevel + 1;
            String costStr  = economy.formatCost(type, currentLevel);
            String balStr   = economy.formatBalance(player);

            lore.add(type.getDescription());
            lore.add("§8──────────");
            lore.add("§7ระดับปัจจุบัน: §e" + currentLevel + " §8/ §e" + maxLevel);
            lore.add("§7ระดับต่อไป: §a" + nextLevel);
            lore.add("§8──────────");

            // Show cost ladder for next 3 levels
            lore.add("§7§lราคา upgrade:");
            for (int lvl = currentLevel; lvl < Math.min(currentLevel + 3, maxLevel); lvl++) {
                String arrow = (lvl == currentLevel) ? "§a▶ " : "§8  ";
                String c = economy.formatCost(type, lvl);
                lore.add(arrow + "§7Lv." + lvl + "→" + (lvl + 1) + " §8: §e" + c);
            }

            lore.add("§8──────────");
            lore.add("§7ยอดเงินของคุณ: §f" + balStr);
            if (canAfford) {
                lore.add("");
                lore.add("§aคลิกเพื่ออัปเกรด!");
            } else {
                lore.add("§c❌ เงินไม่พอ!");
            }
        }

        ItemStack btn = new ItemStack(mat);
        ItemMeta meta = btn.getItemMeta();
        meta.setDisplayName(type.getDisplayName() + (maxed ? " §8[§6MAX§8]" : " §8[Lv." + currentLevel + "→" + (currentLevel+1) + "]"));
        meta.setLore(lore);
        btn.setItemMeta(meta);
        return btn;
    }

    private void fillBorder(Inventory gui) {
        ItemStack border = makeGlass(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        int[] borderSlots = {
            0,1,2,3,4,5,6,7,8,
            9,17,
            18,26,
            27,35,
            36,44,
            45,46,47,48,49,50,51,52,53
        };
        for (int slot : borderSlots) {
            if (gui.getItem(slot) == null) gui.setItem(slot, border);
        }
        // Dark pane dividers between categories
        for (int i = 10; i <= 16; i++) {
            if (gui.getItem(i) == null) gui.setItem(i, makeGlass(Material.BLACK_STAINED_GLASS_PANE, " ", null));
        }
        for (int i = 19; i <= 25; i++) {
            if (gui.getItem(i) == null) gui.setItem(i, makeGlass(Material.BLACK_STAINED_GLASS_PANE, " ", null));
        }
        for (int i = 36; i <= 44; i++) {
            if (gui.getItem(i) == null) gui.setItem(i, makeGlass(Material.BLACK_STAINED_GLASS_PANE, " ", null));
        }
        // Slots 30, 31 are for future upgrades / separator
        gui.setItem(30, makeGlass(Material.BLACK_STAINED_GLASS_PANE, " ", null));
        gui.setItem(34, makeGlass(Material.BLACK_STAINED_GLASS_PANE, " ", null));
    }

    private ItemStack makeGlass(Material mat, String name, List<String> lore) {
        ItemStack g = new ItemStack(mat);
        ItemMeta m = g.getItemMeta();
        m.setDisplayName(name);
        if (lore != null) m.setLore(lore);
        g.setItemMeta(m);
        return g;
    }

    private ItemStack makeLabel(Material mat, String name, List<String> lore) {
        ItemStack g = new ItemStack(mat);
        ItemMeta m = g.getItemMeta();
        m.setDisplayName(name);
        m.setLore(lore);
        g.setItemMeta(m);
        return g;
    }
}
