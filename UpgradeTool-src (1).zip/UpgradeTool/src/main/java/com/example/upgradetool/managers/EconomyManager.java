package com.example.upgradetool.managers;

import com.example.upgradetool.UpgradeToolPlugin;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.text.NumberFormat;
import java.util.Locale;

/**
 * Wraps Vault Economy. Falls back to EXP-based payment if Vault is not installed.
 */
public class EconomyManager {

    private final UpgradeToolPlugin plugin;
    private Economy economy = null;
    private final boolean vaultEnabled;

    public EconomyManager(UpgradeToolPlugin plugin) {
        this.plugin = plugin;
        this.vaultEnabled = setupEconomy();

        if (vaultEnabled) {
            plugin.getLogger().info("[Economy] Vault detected – using money for upgrade costs.");
        } else {
            plugin.getLogger().warning("[Economy] Vault not found – falling back to EXP Level costs.");
        }
    }

    private boolean setupEconomy() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp =
            plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    public boolean isVaultEnabled() { return vaultEnabled; }

    // ─── Money (Vault) ────────────────────────────────────────────────────────

    /**
     * Returns the upgrade cost in money (Vault) or EXP levels (fallback).
     * Formula: base * multiplier^currentLevel  → exponential scaling
     * Example base=100, multiplier=2.0:  Lv0→100, Lv1→200, Lv2→400, Lv3→800…
     */
    public double getUpgradeCostMoney(com.example.upgradetool.enums.UpgradeType type, int currentLevel) {
        double base = switch (type) {
            case FAST_MINE     -> plugin.getConfig().getDouble("upgrades.fast_mine.base_cost",     100.0);
            case MINE_3X3      -> plugin.getConfig().getDouble("upgrades.mine_3x3.cost",           500.0);
            case STRONG_ATTACK -> plugin.getConfig().getDouble("upgrades.strong_attack.base_cost", 150.0);
            case FAST_ATTACK   -> plugin.getConfig().getDouble("upgrades.fast_attack.base_cost",   200.0);
        };
        double multiplier = plugin.getConfig().getDouble("upgrades.cost_multiplier", 2.0);
        return base * Math.pow(multiplier, currentLevel);
    }

    /** EXP fallback: same exponential formula but integer levels */
    public int getUpgradeCostExp(com.example.upgradetool.enums.UpgradeType type, int currentLevel) {
        int base = switch (type) {
            case FAST_MINE     -> plugin.getConfig().getInt("upgrades.fast_mine.base_cost_exp",     5);
            case MINE_3X3      -> plugin.getConfig().getInt("upgrades.mine_3x3.cost_exp",           20);
            case STRONG_ATTACK -> plugin.getConfig().getInt("upgrades.strong_attack.base_cost_exp", 8);
            case FAST_ATTACK   -> plugin.getConfig().getInt("upgrades.fast_attack.base_cost_exp",   10);
        };
        // base * 2^level  (integer safe up to level 10)
        return (int) (base * Math.pow(2.0, currentLevel));
    }

    /** Check if a player can afford the next upgrade */
    public boolean canAfford(Player player, com.example.upgradetool.enums.UpgradeType type, int currentLevel) {
        if (player.hasPermission("upgradetool.admin")) return true;
        if (vaultEnabled) {
            return economy.has(player, getUpgradeCostMoney(type, currentLevel));
        } else {
            return player.getLevel() >= getUpgradeCostExp(type, currentLevel);
        }
    }

    /** Deduct the cost from the player */
    public void charge(Player player, com.example.upgradetool.enums.UpgradeType type, int currentLevel) {
        if (player.hasPermission("upgradetool.admin")) return;
        if (vaultEnabled) {
            economy.withdrawPlayer(player, getUpgradeCostMoney(type, currentLevel));
        } else {
            player.setLevel(player.getLevel() - getUpgradeCostExp(type, currentLevel));
        }
    }

    /** Human-readable cost string for display in GUI */
    public String formatCost(com.example.upgradetool.enums.UpgradeType type, int currentLevel) {
        if (vaultEnabled) {
            double cost = getUpgradeCostMoney(type, currentLevel);
            String symbol = economy.currencyNameSingular();
            return formatMoney(cost) + " " + symbol;
        } else {
            return getUpgradeCostExp(type, currentLevel) + " EXP Level";
        }
    }

    /** Human-readable balance string */
    public String formatBalance(Player player) {
        if (vaultEnabled) {
            double bal = economy.getBalance(player);
            return formatMoney(bal) + " " + economy.currencyNameSingular();
        } else {
            return player.getLevel() + " EXP Level";
        }
    }

    private String formatMoney(double amount) {
        if (amount >= 1_000_000) return String.format("%.1fM", amount / 1_000_000);
        if (amount >= 1_000)    return String.format("%.1fK", amount / 1_000);
        return NumberFormat.getInstance(Locale.US).format((long) amount);
    }
}
