package com.example.upgradetool.enums;

public enum UpgradeType {
    // Mining upgrades (Pickaxe only)
    FAST_MINE("§a⚡ ขุดเร็วขึ้น", "§7เพิ่มความเร็วในการขุด", ItemCategory.PICKAXE),
    MINE_3X3("§b⬛ ขุด 3×3", "§7ขุดพื้นที่ 3×3 พร้อมกัน", ItemCategory.PICKAXE),

    // Combat upgrades (Sword only)
    STRONG_ATTACK("§c⚔ ตีแรง", "§7เพิ่มความเสียหาย", ItemCategory.SWORD),
    FAST_ATTACK("§e🗡 ตีเร็ว", "§7เพิ่มความเร็วในการโจมตี", ItemCategory.SWORD);

    private final String displayName;
    private final String description;
    private final ItemCategory category;

    UpgradeType(String displayName, String description, ItemCategory category) {
        this.displayName = displayName;
        this.description = description;
        this.category = category;
    }

    public String getDisplayName() { return displayName; }
    public String getDescription() { return description; }
    public ItemCategory getCategory() { return category; }
}
