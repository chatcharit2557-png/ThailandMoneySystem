package com.example.upgradetool.listeners;

import com.example.upgradetool.UpgradeToolPlugin;
import com.example.upgradetool.enums.UpgradeType;
import com.example.upgradetool.managers.UpgradeManager;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class Mine3x3Listener implements Listener {

    private final UpgradeToolPlugin plugin;
    private final UpgradeManager manager;

    // Prevent recursive triggering
    private final java.util.Set<Player> processing = new java.util.HashSet<>();

    public Mine3x3Listener(UpgradeToolPlugin plugin) {
        this.plugin  = plugin;
        this.manager = plugin.getUpgradeManager();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (processing.contains(player)) return;

        ItemStack tool = player.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir()) return;

        // Check 3x3 upgrade
        if (manager.getUpgradeLevel(tool, UpgradeType.MINE_3X3) <= 0) return;

        Block center = event.getBlock();
        processing.add(player);

        List<Block> toBreak = getSurroundingBlocks(center, player);

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            for (Block b : toBreak) {
                if (b.getType() == Material.AIR) continue;
                if (!player.hasPermission("upgradetool.admin")) {
                    // Respect unbreakable blocks (bedrock etc.)
                    if (b.getType() == Material.BEDROCK) continue;
                }
                BlockBreakEvent fakeEvent = new BlockBreakEvent(b, player);
                plugin.getServer().getPluginManager().callEvent(fakeEvent);
                if (!fakeEvent.isCancelled()) {
                    b.breakNaturally(tool);
                }
            }
            processing.remove(player);
        });
    }

    private List<Block> getSurroundingBlocks(Block center, Player player) {
        List<Block> blocks = new ArrayList<>();
        // Get the face direction the player is looking at to determine the 2D plane
        org.bukkit.block.BlockFace face = getPlayerFace(player);

        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue; // skip center block

                Block relative;
                switch (face) {
                    case NORTH, SOUTH -> relative = center.getRelative(dx, dy, 0);
                    case EAST,  WEST  -> relative = center.getRelative(0, dy, dx);
                    default           -> relative = center.getRelative(dx, 0, dy); // UP/DOWN – floor mining
                }
                blocks.add(relative);
            }
        }
        return blocks;
    }

    private org.bukkit.block.BlockFace getPlayerFace(Player player) {
        float yaw   = player.getLocation().getYaw();
        float pitch = player.getLocation().getPitch();

        if (pitch > 45)  return org.bukkit.block.BlockFace.DOWN;
        if (pitch < -45) return org.bukkit.block.BlockFace.UP;

        yaw = ((yaw % 360) + 360) % 360;
        if (yaw < 45  || yaw >= 315) return org.bukkit.block.BlockFace.SOUTH;
        if (yaw < 135) return org.bukkit.block.BlockFace.WEST;
        if (yaw < 225) return org.bukkit.block.BlockFace.NORTH;
        return org.bukkit.block.BlockFace.EAST;
    }
}
