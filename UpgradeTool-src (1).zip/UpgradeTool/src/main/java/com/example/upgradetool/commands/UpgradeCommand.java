package com.example.upgradetool.commands;

import com.example.upgradetool.UpgradeToolPlugin;
import com.example.upgradetool.gui.UpgradeGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;

public class UpgradeCommand implements CommandExecutor, TabCompleter {

    private final UpgradeToolPlugin plugin;
    private final UpgradeGUI gui;

    public UpgradeCommand(UpgradeToolPlugin plugin) {
        this.plugin = plugin;
        this.gui    = new UpgradeGUI(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cคำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น!");
            return true;
        }

        if (!player.hasPermission("upgradetool.use")) {
            player.sendMessage("§cคุณไม่มีสิทธิ์ใช้คำสั่งนี้!");
            return true;
        }

        player.sendMessage("§8§l[§b§lUpgradeTool§8§l] §aเปิดหน้าต่าง Upgrade...");
        gui.open(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return Collections.emptyList();
    }
}
