package com.example.upgradetool.gui;

import com.example.upgradetool.UpgradeToolPlugin;
import com.example.upgradetool.enums.ItemCategory;
import com.example.upgradetool.enums.UpgradeType;
import com.example.upgradetool.managers.EconomyManager;
import com.example.upgradetool.managers.UpgradeManager;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class UpgradeGUIListener implements Listener {

    private final UpgradeToolPlugin plugin;
    private final UpgradeGUI gui;
    private final UpgradeManager manager;
    private final EconomyManager economy;

    public UpgradeGUIListener(UpgradeToolPlugin plugin) {
        this.plugin   = plugin;
        this.gui      = new UpgradeGUI(plugin);
        this.manager  = plugin.getUpgradeManager();
        this.economy  = plugin.getEconomyManager();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        event.setCancelled(true);

        Inventory inv = event.getInventory();
        int slot = event.getRawSlot();

        // Allow player to place/take their item in slot 13 only
        if (slot == UpgradeGUI.ITEM_SLOT) {
            handleItemSlot(event, player, inv);
            return;
        }

        // Prevent taking from non-item slots
        if (slot >= inv.getSize()) return; // clicked in player inventory — do nothing except allow item slot drag

        // Close button
        if (slot == UpgradeGUI.CLOSE_SLOT) {
            returnItemAndClose(player, inv);
            return;
        }

        // Upgrade buttons
        ItemStack currentItem = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (currentItem == null || currentItem.getType().isAir() || currentItem.getType() == Material.LIME_STAINED_GLASS_PANE) {
            player.sendMessage("§c❌ กรุณาวางอุปกรณ์ในช่องกลางก่อน!");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        UpgradeType type = getUpgradeTypeFromSlot(slot);
        if (type == null) return;

        // Compatibility check
        if (!manager.isCompatible(currentItem, type)) {
            ItemCategory needed = type.getCategory();
            ItemCategory has    = ItemCategory.fromMaterial(currentItem.getType());
            String hasName = has != null ? has.getDisplayName() : "§7ไม่รู้จัก";
            player.sendMessage("§c❌ ไม่สามารถ upgrade ได้!");
            player.sendMessage("§7อุปกรณ์ของคุณ: " + hasName);
            player.sendMessage("§7Upgrade นี้ต้องการ: " + needed.getDisplayName());
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        // Level check
        int current  = manager.getUpgradeLevel(currentItem, type);
        int maxLevel = manager.getMaxLevel(type);
        if (current >= maxLevel) {
            player.sendMessage("§6⭐ " + type.getDisplayName() + " §6อยู่ที่ระดับสูงสุดแล้ว!");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 1f);
            return;
        }

        // Cost check (money or EXP depending on Vault)
        if (!economy.canAfford(player, type, current)) {
            String costStr = economy.formatCost(type, current);
            String balStr  = economy.formatBalance(player);
            player.sendMessage("§c❌ เงินไม่พอ! ต้องการ §e" + costStr + " §cแต่มีแค่ §f" + balStr);
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        // Apply upgrade
        boolean success = manager.applyUpgrade(currentItem, type);
        if (success) {
            String costStr = economy.formatCost(type, current);
            economy.charge(player, type, current);

            player.sendMessage("§a✔ §lUpgrade สำเร็จ! §r§a" + type.getDisplayName()
                + " §aLv." + (current + 1)
                + " §8(§c-" + costStr + "§8) §7เหลือ: §f" + economy.formatBalance(player));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5f, 1.5f);

            // Update item in slot and refresh GUI
            inv.setItem(UpgradeGUI.ITEM_SLOT, currentItem);
            gui.refresh(inv, currentItem, player);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        event.setCancelled(true); // cancel all drags by default

        // If drag touches only slot 13 (and optionally player inv slots), handle manually
        boolean touchesGuiSlots = event.getRawSlots().stream()
            .anyMatch(s -> s < event.getInventory().getSize());
        if (!touchesGuiSlots) return; // only player inv — irrelevant

        boolean onlyItemSlot = event.getRawSlots().stream()
            .filter(s -> s < event.getInventory().getSize())
            .allMatch(s -> s == UpgradeGUI.ITEM_SLOT);

        if (onlyItemSlot) {
            // Treat as a place-all into item slot
            ItemStack dragged = event.getOldCursor();
            if (dragged == null || dragged.getType().isAir()) return;

            ItemCategory cat = ItemCategory.fromMaterial(dragged.getType());
            if (cat == null) {
                player.sendMessage("§c❌ ไม่สามารถ upgrade ไอเทมนี้ได้!");
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }

            Inventory inv = event.getInventory();
            ItemStack current = inv.getItem(UpgradeGUI.ITEM_SLOT);
            boolean slotEmpty = current == null || current.getType().isAir()
                                || current.getType() == Material.LIME_STAINED_GLASS_PANE;

            if (!slotEmpty) {
                for (ItemStack lo : player.getInventory().addItem(current).values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), lo);
                }
            }
            inv.setItem(UpgradeGUI.ITEM_SLOT, dragged.clone());
            player.setItemOnCursor(null);
            gui.refresh(inv, dragged, player);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        // Return the item in slot 13 to player
        Inventory inv = event.getInventory();
        ItemStack item = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (item != null && !item.getType().isAir() && item.getType() != Material.LIME_STAINED_GLASS_PANE) {
            // Drop or give back
            for (ItemStack leftover : player.getInventory().addItem(item).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
            inv.setItem(UpgradeGUI.ITEM_SLOT, null);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private void handleItemSlot(InventoryClickEvent event, Player player, Inventory inv) {
        // event is already cancelled — we manage the swap manually
        InventoryAction action = event.getAction();
        ItemStack cursor  = event.getCursor();
        ItemStack current = inv.getItem(UpgradeGUI.ITEM_SLOT);
        boolean slotEmpty = current == null || current.getType().isAir()
                            || current.getType() == Material.LIME_STAINED_GLASS_PANE;

        switch (action) {
            // ── Place item into the slot ──────────────────────────────────────
            case PLACE_ALL, PLACE_ONE, PLACE_SOME, SWAP_WITH_CURSOR -> {
                if (cursor == null || cursor.getType().isAir()) return;

                // Validate category
                ItemCategory cat = ItemCategory.fromMaterial(cursor.getType());
                if (cat == null) {
                    player.sendMessage("§c❌ ไม่สามารถ upgrade ไอเทมนี้ได้!");
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                    return;
                }

                // If slot already has a valid item, give it back via cursor
                if (!slotEmpty) {
                    player.setItemOnCursor(current);
                } else {
                    player.setItemOnCursor(null);
                }
                inv.setItem(UpgradeGUI.ITEM_SLOT, cursor.clone());
                gui.refresh(inv, cursor, player);
            }

            // ── Pick item out of the slot ─────────────────────────────────────
            case PICKUP_ALL, PICKUP_ONE, PICKUP_SOME, PICKUP_HALF -> {
                if (slotEmpty) return;
                player.setItemOnCursor(current.clone());
                inv.setItem(UpgradeGUI.ITEM_SLOT, null);
                gui.refresh(inv, null, player);
            }

            // ── Shift-click from player inv into slot ─────────────────────────
            case MOVE_TO_OTHER_INVENTORY -> {
                // Shift-click from player inventory (rawSlot >= inv.getSize())
                // event.getCurrentItem() is the item in player's inventory
                ItemStack clicked = event.getCurrentItem();
                if (clicked == null || clicked.getType().isAir()) return;

                ItemCategory cat = ItemCategory.fromMaterial(clicked.getType());
                if (cat == null) {
                    player.sendMessage("§c❌ ไม่สามารถ upgrade ไอเทมนี้ได้!");
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                    return;
                }

                // If slot occupied, swap
                if (!slotEmpty) {
                    // give current slot item back to player
                    for (ItemStack lo : player.getInventory().addItem(current).values()) {
                        player.getWorld().dropItemNaturally(player.getLocation(), lo);
                    }
                }
                inv.setItem(UpgradeGUI.ITEM_SLOT, clicked.clone());
                event.setCurrentItem(null); // remove from player inv
                gui.refresh(inv, clicked, player);
            }

            default -> { /* ignore other actions */ }
        }
    }

    private void returnItemAndClose(Player player, Inventory inv) {
        ItemStack item = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (item != null && !item.getType().isAir() && item.getType() != Material.LIME_STAINED_GLASS_PANE) {
            for (ItemStack lo : player.getInventory().addItem(item).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), lo);
            }
            inv.setItem(UpgradeGUI.ITEM_SLOT, null);
        }
        player.closeInventory();
    }

    private UpgradeType getUpgradeTypeFromSlot(int slot) {
        return switch (slot) {
            case UpgradeGUI.FAST_MINE_SLOT   -> UpgradeType.FAST_MINE;
            case UpgradeGUI.MINE_3X3_SLOT    -> UpgradeType.MINE_3X3;
            case UpgradeGUI.STRONG_ATK_SLOT  -> UpgradeType.STRONG_ATTACK;
            case UpgradeGUI.FAST_ATK_SLOT    -> UpgradeType.FAST_ATTACK;
            default -> null;
        };
    }

    private boolean isUpgradeGUI(String title) {
        return ChatColor.stripColor(title).equals(ChatColor.stripColor(UpgradeGUI.GUI_TITLE));
    }


}
