package com.example.upgradetool.managers;

import com.example.upgradetool.UpgradeToolPlugin;
import com.example.upgradetool.enums.ItemCategory;
import com.example.upgradetool.enums.UpgradeType;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class UpgradeManager {

    private final UpgradeToolPlugin plugin;

    // NBT keys
    public final NamespacedKey KEY_FAST_MINE;
    public final NamespacedKey KEY_MINE_3X3;
    public final NamespacedKey KEY_STRONG_ATTACK;
    public final NamespacedKey KEY_FAST_ATTACK;

    public UpgradeManager(UpgradeToolPlugin plugin) {
        this.plugin = plugin;
        KEY_FAST_MINE     = new NamespacedKey(plugin, "fast_mine");
        KEY_MINE_3X3      = new NamespacedKey(plugin, "mine_3x3");
        KEY_STRONG_ATTACK = new NamespacedKey(plugin, "strong_attack");
        KEY_FAST_ATTACK   = new NamespacedKey(plugin, "fast_attack");
    }

    /** Returns true if the upgrade was applied, false if already maxed */
    public boolean applyUpgrade(ItemStack item, UpgradeType type) {
        if (item == null || item.getItemMeta() == null) return false;

        int maxLevel = getMaxLevel(type);
        int current  = getUpgradeLevel(item, type);
        if (current >= maxLevel) return false;

        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();

        switch (type) {
            case FAST_MINE -> {
                pdc.set(KEY_FAST_MINE, PersistentDataType.INTEGER, current + 1);
                // Apply efficiency enchant as visual cue
                meta.addEnchant(Enchantment.DIG_SPEED, current + 1, true);
            }
            case MINE_3X3 -> {
                pdc.set(KEY_MINE_3X3, PersistentDataType.INTEGER, 1);
            }
            case STRONG_ATTACK -> {
                pdc.set(KEY_STRONG_ATTACK, PersistentDataType.INTEGER, current + 1);
                meta.addEnchant(Enchantment.DAMAGE_ALL, current + 1, true);
            }
            case FAST_ATTACK -> {
                pdc.set(KEY_FAST_ATTACK, PersistentDataType.INTEGER, current + 1);
                meta.addEnchant(Enchantment.KNOCKBACK, current + 1, true);
            }
        }

        // Rebuild lore
        rebuildLore(meta, item);
        item.setItemMeta(meta);
        return true;
    }

    public int getUpgradeLevel(ItemStack item, UpgradeType type) {
        if (item == null || item.getItemMeta() == null) return 0;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        return switch (type) {
            case FAST_MINE     -> pdc.getOrDefault(KEY_FAST_MINE,     PersistentDataType.INTEGER, 0);
            case MINE_3X3      -> pdc.getOrDefault(KEY_MINE_3X3,      PersistentDataType.INTEGER, 0);
            case STRONG_ATTACK -> pdc.getOrDefault(KEY_STRONG_ATTACK, PersistentDataType.INTEGER, 0);
            case FAST_ATTACK   -> pdc.getOrDefault(KEY_FAST_ATTACK,   PersistentDataType.INTEGER, 0);
        };
    }

    public int getMaxLevel(UpgradeType type) {
        return switch (type) {
            case FAST_MINE     -> plugin.getConfig().getInt("upgrades.fast_mine.max_level", 5);
            case MINE_3X3      -> 1;
            case STRONG_ATTACK -> plugin.getConfig().getInt("upgrades.strong_attack.max_level", 5);
            case FAST_ATTACK   -> plugin.getConfig().getInt("upgrades.fast_attack.max_level", 3);
        };
    }

    public int getUpgradeCost(UpgradeType type, int currentLevel) {
        int base = switch (type) {
            case FAST_MINE     -> plugin.getConfig().getInt("upgrades.fast_mine.base_cost", 5);
            case MINE_3X3      -> plugin.getConfig().getInt("upgrades.mine_3x3.cost", 20);
            case STRONG_ATTACK -> plugin.getConfig().getInt("upgrades.strong_attack.base_cost", 8);
            case FAST_ATTACK   -> plugin.getConfig().getInt("upgrades.fast_attack.base_cost", 10);
        };
        return base + (currentLevel * base);
    }

    /** Check if item category matches upgrade type */
    public boolean isCompatible(ItemStack item, UpgradeType upgradeType) {
        if (item == null) return false;
        ItemCategory itemCat = ItemCategory.fromMaterial(item.getType());
        if (itemCat == null) return false;
        return itemCat == upgradeType.getCategory();
    }

    private void rebuildLore(ItemMeta meta, ItemStack item) {
        List<String> lore = new ArrayList<>();
        lore.add("§8─────────────────");
        lore.add("§7§lUpgrades:");

        PersistentDataContainer pdc = meta.getPersistentDataContainer();

        int fm = pdc.getOrDefault(KEY_FAST_MINE,     PersistentDataType.INTEGER, 0);
        int m3 = pdc.getOrDefault(KEY_MINE_3X3,      PersistentDataType.INTEGER, 0);
        int sa = pdc.getOrDefault(KEY_STRONG_ATTACK, PersistentDataType.INTEGER, 0);
        int fa = pdc.getOrDefault(KEY_FAST_ATTACK,   PersistentDataType.INTEGER, 0);

        if (fm > 0) lore.add("§a⚡ ขุดเร็วขึ้น §f" + buildStars(fm, 5));
        if (m3 > 0) lore.add("§b⬛ ขุด 3×3 §f✦");
        if (sa > 0) lore.add("§c⚔ ตีแรง §f" + buildStars(sa, 5));
        if (fa > 0) lore.add("§e🗡 ตีเร็ว §f" + buildStars(fa, 3));

        if (lore.size() == 2) lore.add("§7ยังไม่มี upgrade");
        lore.add("§8─────────────────");
        meta.setLore(lore);
    }

    private String buildStars(int level, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < max; i++) {
            sb.append(i < level ? "§e★" : "§8★");
        }
        return sb.toString();
    }
}
