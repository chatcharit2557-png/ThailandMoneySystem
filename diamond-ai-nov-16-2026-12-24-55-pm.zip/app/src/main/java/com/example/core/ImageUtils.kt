package com.example.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

object ImageUtils {
    private const val MAX_DIMENSION = 1280

    suspend fun loadScaledBitmap(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }
            val maxSide = max(boundsOpts.outWidth, boundsOpts.outHeight)
            var sampleSize = 1
            while (maxSide / sampleSize > MAX_DIMENSION) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return@withContext null

            scaleDownIfNeeded(decoded)
        }.getOrNull()
    }

    suspend fun persistPickerImageToCache(context: Context, uri: Uri): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                val bitmap = loadScaledBitmap(context, uri) ?: return@withContext null
                val dir = File(context.filesDir, "attached_images").apply { mkdirs() }
                val file = File(dir, "img_${System.currentTimeMillis()}.jpg")
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 88, out)
                }
                file.absolutePath
            }.getOrNull()
        }

    suspend fun loadBitmapFromPath(path: String): Bitmap? = withContext(Dispatchers.IO) {
        runCatching {
            BitmapFactory.decodeFile(path)
        }.getOrNull()
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= MAX_DIMENSION && height <= MAX_DIMENSION) return bitmap
        val ratio = width.toFloat() / height.toFloat()
        val targetWidth: Int
        val targetHeight: Int
        if (width > height) {
            targetWidth = MAX_DIMENSION
            targetHeight = (MAX_DIMENSION / ratio).toInt().coerceAtLeast(1)
        } else {
            targetHeight = MAX_DIMENSION
            targetWidth = (MAX_DIMENSION * ratio).toInt().coerceAtLeast(1)
        }
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }
}
