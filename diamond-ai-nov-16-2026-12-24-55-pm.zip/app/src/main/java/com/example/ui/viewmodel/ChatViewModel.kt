package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ImageUtils
import com.example.data.ai.DiamondAiRepository
import com.example.data.ai.DiamondMode
import com.example.data.local.ConversationEntity
import com.example.data.local.DiamondLocalRepository
import com.example.data.local.ChatMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "ChatViewModel"

sealed interface ChatAiState {
    data object Idle : ChatAiState
    data object Loading : ChatAiState
    data class Streaming(val partialText: String) : ChatAiState
    data class Error(val message: String) : ChatAiState
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
    private val aiRepository: DiamondAiRepository,
    private val localRepository: DiamondLocalRepository
) : ViewModel() {

    private val _activeConversationId = MutableStateFlow<Long?>(null)
    val activeConversationId: StateFlow<Long?> = _activeConversationId.asStateFlow()

    private val _selectedMode = MutableStateFlow(DiamondMode.GENERAL)
    val selectedMode: StateFlow<DiamondMode> = _selectedMode.asStateFlow()

    private val _aiState = MutableStateFlow<ChatAiState>(ChatAiState.Idle)
    val aiState: StateFlow<ChatAiState> = _aiState.asStateFlow()

    private val _attachedImageUri = MutableStateFlow<Uri?>(null)
    val attachedImageUri: StateFlow<Uri?> = _attachedImageUri.asStateFlow()

    val conversations: StateFlow<List<ConversationEntity>> = localRepository.conversations
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val messages: StateFlow<List<ChatMessage>> = _activeConversationId
        .flatMapLatest { convId ->
            if (convId == null) flowOf(emptyList())
            else localRepository.getMessages(convId)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private var activeGenerationJob: Job? = null

    fun selectMode(mode: DiamondMode) {
        _selectedMode.value = mode
        val currentId = _activeConversationId.value
        if (currentId != null) {
            val currentTitle = conversations.value.find { it.id == currentId }?.title ?: return
            viewModelScope.launch {
                localRepository.updateConversationMeta(currentId, currentTitle, mode.id)
            }
        }
    }

    fun startNewChat() {
        activeGenerationJob?.cancel()
        _activeConversationId.value = null
        _aiState.value = ChatAiState.Idle
        _attachedImageUri.value = null
    }

    fun selectConversation(conversation: ConversationEntity) {
        activeGenerationJob?.cancel()
        _activeConversationId.value = conversation.id
        _selectedMode.value = DiamondMode.fromId(conversation.modeId)
        _aiState.value = ChatAiState.Idle
        _attachedImageUri.value = null
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            if (_activeConversationId.value == id) {
                startNewChat()
            }
            localRepository.deleteConversation(id)
        }
    }

    fun attachImage(uri: Uri?) {
        _attachedImageUri.value = uri
    }

    fun clearError() {
        if (_aiState.value is ChatAiState.Error) {
            _aiState.value = ChatAiState.Idle
        }
    }

    fun stopGeneration() {
        val currentStreaming = (_aiState.value as? ChatAiState.Streaming)?.partialText
        activeGenerationJob?.cancel()
        val convId = _activeConversationId.value
        if (convId != null && !currentStreaming.isNullOrBlank()) {
            viewModelScope.launch {
                localRepository.addMessage(
                    conversationId = convId,
                    isUser = false,
                    text = currentStreaming
                )
            }
        }
        _aiState.value = ChatAiState.Idle
    }

    fun sendMessage(context: Context, rawPrompt: String, overrideMode: DiamondMode? = null) {
        val trimmed = rawPrompt.trim()
        val imageUri = _attachedImageUri.value
        if (trimmed.isEmpty() && imageUri == null) return

        if (overrideMode != null) {
            _selectedMode.value = overrideMode
        }

        val effectivePrompt = trimmed.ifEmpty { "ช่วยวิเคราะห์รูปภาพนี้และอธิบายอย่างละเอียด" }
        _attachedImageUri.value = null

        activeGenerationJob?.cancel()
        activeGenerationJob = viewModelScope.launch {
            _aiState.value = ChatAiState.Loading
            try {
                val mode = _selectedMode.value
                var convId = _activeConversationId.value
                if (convId == null) {
                    val title = effectivePrompt.take(42).let {
                        if (effectivePrompt.length > 42) "$it..." else it
                    }
                    convId = localRepository.createConversation(title = title, modeId = mode.id)
                    _activeConversationId.value = convId
                } else {
                    val currentTitle = conversations.value.find { it.id == convId }?.title
                        ?: effectivePrompt.take(42)
                    localRepository.updateConversationMeta(convId, currentTitle, mode.id)
                }

                val historyBeforeSend = localRepository.getMessagesSnapshot(convId)

                val cachedImagePath = imageUri?.let {
                    ImageUtils.persistPickerImageToCache(context, it)
                }
                val bitmap = cachedImagePath?.let { ImageUtils.loadBitmapFromPath(it) }

                localRepository.addMessage(
                    conversationId = convId,
                    isUser = true,
                    text = effectivePrompt,
                    imagePath = cachedImagePath
                )

                val buffer = StringBuilder()
                aiRepository.streamChatResponse(
                    mode = mode,
                    history = historyBeforeSend,
                    prompt = effectivePrompt,
                    attachedBitmap = bitmap
                ).collect { chunk ->
                    buffer.append(chunk)
                    _aiState.value = ChatAiState.Streaming(buffer.toString())
                }

                val finalResponse = buffer.toString().trim()
                if (finalResponse.isNotEmpty()) {
                    localRepository.addMessage(
                        conversationId = convId,
                        isUser = false,
                        text = finalResponse
                    )
                    _aiState.value = ChatAiState.Idle
                } else {
                    _aiState.value = ChatAiState.Error("Diamond AI ไม่สามารถสร้างคำตอบได้ กรุณาลองใหม่อีกครั้ง")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Chat generation timed out", e)
                _aiState.value = ChatAiState.Error("การเชื่อมต่อใช้เวลานานเกิน 60 วินาที กรุณาลองใหม่อีกครั้ง")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Chat generation failed", e)
                _aiState.value = ChatAiState.Error(
                    e.localizedMessage ?: "เกิดข้อผิดพลาดในการเชื่อมต่อ Diamond AI"
                )
            }
        }
    }

    fun regenerateLastResponse() {
        val convId = _activeConversationId.value ?: return
        val currentMsgs = messages.value
        val lastUserMsg = currentMsgs.lastOrNull { it.isUser } ?: return
        val lastMsg = currentMsgs.lastOrNull()

        activeGenerationJob?.cancel()
        activeGenerationJob = viewModelScope.launch {
            _aiState.value = ChatAiState.Loading
            try {
                if (lastMsg != null && !lastMsg.isUser) {
                    localRepository.deleteMessage(lastMsg.id)
                }
                val snapshot = localRepository.getMessagesSnapshot(convId)
                val historyWithoutLastUser = snapshot.dropLastWhile { it.id == lastUserMsg.id }
                val bitmap = lastUserMsg.imagePath?.let { ImageUtils.loadBitmapFromPath(it) }

                val buffer = StringBuilder()
                aiRepository.streamChatResponse(
                    mode = _selectedMode.value,
                    history = historyWithoutLastUser,
                    prompt = lastUserMsg.text,
                    attachedBitmap = bitmap
                ).collect { chunk ->
                    buffer.append(chunk)
                    _aiState.value = ChatAiState.Streaming(buffer.toString())
                }

                val finalText = buffer.toString().trim()
                if (finalText.isNotEmpty()) {
                    localRepository.addMessage(
                        conversationId = convId,
                        isUser = false,
                        text = finalText
                    )
                    _aiState.value = ChatAiState.Idle
                } else {
                    _aiState.value = ChatAiState.Error("ไม่สามารถสร้างคำตอบใหม่ได้")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Regenerate timed out", e)
                _aiState.value = ChatAiState.Error("การเชื่อมต่อหมดเวลา กรุณาลองใหม่")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Regenerate failed", e)
                _aiState.value = ChatAiState.Error(
                    e.localizedMessage ?: "เกิดข้อผิดพลาดในการสร้างคำตอบใหม่"
                )
            }
        }
    }

    fun continueFromTool(title: String, prompt: String, assistantResult: String) {
        activeGenerationJob?.cancel()
        viewModelScope.launch {
            val convId = localRepository.createConversation(
                title = title.take(42),
                modeId = DiamondMode.GENERAL.id
            )
            localRepository.addMessage(
                conversationId = convId,
                isUser = true,
                text = prompt
            )
            localRepository.addMessage(
                conversationId = convId,
                isUser = false,
                text = assistantResult
            )
            _selectedMode.value = DiamondMode.GENERAL
            _activeConversationId.value = convId
            _aiState.value = ChatAiState.Idle
        }
    }

    fun saveMessageToVault(messageText: String) {
        viewModelScope.launch {
            val previewTitle = messageText.lineSequence()
                .firstOrNull { it.isNotBlank() }
                ?.replace("#", "")
                ?.replace("*", "")
                ?.trim()
                ?.take(48)
                ?: "คำตอบจาก Diamond AI"
            localRepository.saveToVault(
                title = previewTitle,
                content = messageText,
                category = _selectedMode.value.labelTh
            )
        }
    }
}
