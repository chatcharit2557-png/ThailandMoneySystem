package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.CodeResult
import com.example.data.ai.DiamondAiRepository
import com.example.data.ai.DiamondToolType
import com.example.data.ai.PlanResult
import com.example.data.ai.SummaryResult
import com.example.data.local.DiamondLocalRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private const val TAG = "ToolsViewModel"

sealed interface ToolUiState {
    data object Idle : ToolUiState
    data object Loading : ToolUiState
    data class StreamingText(val text: String) : ToolUiState
    data class TextSuccess(val text: String) : ToolUiState
    data class SummarySuccess(val result: SummaryResult) : ToolUiState
    data class PlanSuccess(val result: PlanResult) : ToolUiState
    data class CodeSuccess(val result: CodeResult) : ToolUiState
    data class Error(val message: String) : ToolUiState
}

class ToolsViewModel(
    private val aiRepository: DiamondAiRepository,
    private val localRepository: DiamondLocalRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ToolUiState>(ToolUiState.Idle)
    val uiState: StateFlow<ToolUiState> = _uiState.asStateFlow()

    private var activeJob: Job? = null

    fun resetState() {
        activeJob?.cancel()
        _uiState.value = ToolUiState.Idle
    }

    fun runTool(
        tool: DiamondToolType,
        input: String,
        optionOne: String = "",
        optionTwo: String = ""
    ) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _uiState.value = ToolUiState.Loading
            try {
                when (tool) {
                    DiamondToolType.SUMMARIZE -> {
                        val result = aiRepository.generateStructuredSummary(trimmed)
                        _uiState.value = ToolUiState.SummarySuccess(result)
                    }

                    DiamondToolType.PLANNER -> {
                        val result = aiRepository.generateStructuredPlan(
                            goal = trimmed,
                            details = optionOne
                        )
                        _uiState.value = ToolUiState.PlanSuccess(result)
                    }

                    DiamondToolType.CODE_STUDIO -> {
                        val language = optionOne.ifBlank { "Kotlin" }
                        val action = optionTwo.ifBlank { "เขียนโค้ด" }
                        val result = aiRepository.generateStructuredCode(
                            task = trimmed,
                            language = language,
                            actionType = action
                        )
                        _uiState.value = ToolUiState.CodeSuccess(result)
                    }

                    DiamondToolType.TRANSLATE -> {
                        val targetLang = optionOne.ifBlank { "English" }
                        val tone = optionTwo.ifBlank { "เป็นธรรมชาติ" }
                        val systemPrompt = """
                            You are an expert bilingual translator. Translate the user's text accurately into $targetLang with a '$tone' tone.
                            Output the main translation clearly first, followed by a brief Thai note explaining key nuances or alternative phrasing if helpful.
                        """.trimIndent()
                        streamTextResponse(systemPrompt, trimmed)
                    }

                    DiamondToolType.WRITER -> {
                        val format = optionOne.ifBlank { "อีเมล" }
                        val tone = optionTwo.ifBlank { "สุภาพเป็นมืออาชีพ" }
                        val systemPrompt = """
                            You are an expert Thai and English copywriter.
                            Draft a polished '$format' with a '$tone' tone based on the user's brief.
                            Provide a clear subject/hook and clean formatting ready to send.
                        """.trimIndent()
                        streamTextResponse(systemPrompt, trimmed)
                    }

                    DiamondToolType.IDEAS_RECIPE -> {
                        val focus = optionOne.ifBlank { "สร้างสรรค์" }
                        val systemPrompt = """
                            You are a creative genius and culinary/lifestyle expert.
                            Give inspiring, practical ideas or step-by-step recipes in natural Thai with a '$focus' style.
                        """.trimIndent()
                        streamTextResponse(systemPrompt, trimmed)
                    }
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Tool execution timed out", e)
                _uiState.value = ToolUiState.Error("การประมวลผลหมดเวลา (60 วินาที) กรุณาลองใหม่อีกครั้ง")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Tool execution failed", e)
                _uiState.value = ToolUiState.Error(
                    e.localizedMessage ?: "เกิดข้อผิดพลาดในการใช้งานเครื่องมือ AI"
                )
            }
        }
    }

    private suspend fun streamTextResponse(systemPrompt: String, userPrompt: String) {
        val buffer = StringBuilder()
        aiRepository.streamToolText(systemPrompt, userPrompt).collect { chunk ->
            buffer.append(chunk)
            _uiState.value = ToolUiState.StreamingText(buffer.toString())
        }
        val finalText = buffer.toString().trim()
        if (finalText.isNotEmpty()) {
            _uiState.value = ToolUiState.TextSuccess(finalText)
        } else {
            _uiState.value = ToolUiState.Error("AI ไม่ได้ส่งข้อความตอบกลับ กรุณาลองใหม่")
        }
    }

    fun saveToolResultToVault(title: String, content: String, category: String) {
        viewModelScope.launch {
            localRepository.saveToVault(
                title = title.take(60),
                content = content,
                category = category
            )
        }
    }
}
