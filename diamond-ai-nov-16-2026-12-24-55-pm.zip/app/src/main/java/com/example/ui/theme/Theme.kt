package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val DarkDiamondColorScheme = darkColorScheme(
    primary = DiamondCyan,
    onPrimary = Color(0xFF041C2C),
    primaryContainer = Color(0xFF0C3654),
    onPrimaryContainer = DiamondCyanBright,
    secondary = DiamondIndigo,
    onSecondary = Color(0xFF101338),
    secondaryContainer = Color(0xFF252B5C),
    onSecondaryContainer = Color(0xFFE0E7FF),
    tertiary = DiamondMint,
    onTertiary = Color(0xFF022C22),
    background = ObsidianBg,
    onBackground = CrystalWhite,
    surface = ObsidianSurface,
    onSurface = CrystalWhite,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = CrystalSilver,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceElevated,
    surfaceContainerHigh = ObsidianSurfaceHighest,
    outline = ObsidianOutline,
    outlineVariant = Color(0xFF1D2842),
    error = ErrorRedDark,
    onError = Color(0xFF450A0A),
    errorContainer = ErrorContainerDark,
    onErrorContainer = Color(0xFFFECACA)
)

private val LightDiamondColorScheme = lightColorScheme(
    primary = SapphirePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6EEFF),
    onPrimaryContainer = Color(0xFF032D49),
    secondary = SapphireSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0E7FF),
    onSecondaryContainer = Color(0xFF1E1B4B),
    tertiary = Color(0xFF059669),
    onTertiary = Color.White,
    background = PearlBg,
    onBackground = InkDark,
    surface = PearlSurface,
    onSurface = InkDark,
    surfaceVariant = PearlSurfaceVariant,
    onSurfaceVariant = InkMuted,
    surfaceContainerLow = PearlSurface,
    surfaceContainer = PearlSurfaceVariant,
    surfaceContainerHigh = Color(0xFFDDEAF8),
    outline = PearlOutline,
    outlineVariant = Color(0xFFE2E8F0),
    error = ErrorRedLight,
    onError = Color.White,
    errorContainer = ErrorContainerLight,
    onErrorContainer = Color(0xFF7F1D1D)
)

val DiamondShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun DiamondAiTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkDiamondColorScheme else LightDiamondColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DiamondTypography,
        shapes = DiamondShapes,
        content = content
    )
}
