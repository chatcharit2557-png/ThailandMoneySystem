package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Ice-Diamond Signature Palette (Dark Theme)
val DiamondCyan = Color(0xFF38BDF8)
val DiamondCyanBright = Color(0xFF7DD3FC)
val DiamondDeepBlue = Color(0xFF0284C7)
val DiamondIndigo = Color(0xFF818CF8)
val DiamondViolet = Color(0xFFA78BFA)
val DiamondMint = Color(0xFF34D399)

val ObsidianBg = Color(0xFF070B14)
val ObsidianSurface = Color(0xFF0E1525)
val ObsidianSurfaceElevated = Color(0xFF162038)
val ObsidianSurfaceHighest = Color(0xFF1E2B48)
val ObsidianOutline = Color(0xFF2B3A5C)
val CrystalWhite = Color(0xFFF1F5F9)
val CrystalSilver = Color(0xFF94A3B8)

// Crisp Pearl Palette (Light Theme)
val PearlBg = Color(0xFFF4F8FC)
val PearlSurface = Color(0xFFFFFFFF)
val PearlSurfaceVariant = Color(0xFFE8F1FB)
val PearlOutline = Color(0xFFCBD5E1)
val SapphirePrimary = Color(0xFF0284C7)
val SapphireSecondary = Color(0xFF4F46E5)
val InkDark = Color(0xFF0F172A)
val InkMuted = Color(0xFF475569)

val ErrorRedDark = Color(0xFFF87171)
val ErrorContainerDark = Color(0xFF450A0A)
val ErrorRedLight = Color(0xFFDC2626)
val ErrorContainerLight = Color(0xFFFEE2E2)
