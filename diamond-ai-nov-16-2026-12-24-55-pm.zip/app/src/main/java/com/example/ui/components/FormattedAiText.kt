package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DiamondMonoFont

private sealed interface MarkdownBlock {
    data class TextBlock(val text: String) : MarkdownBlock
    data class CodeBlock(val language: String, val code: String) : MarkdownBlock
}

@Composable
fun FormattedAiText(
    markdown: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    onCodeCopied: () -> Unit = {}
) {
    val blocks = remember(markdown) { splitMarkdownBlocks(markdown) }
    val clipboard = LocalClipboardManager.current

    SelectionContainer(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            blocks.forEach { block ->
                when (block) {
                    is MarkdownBlock.CodeBlock -> {
                        CodeBlockCard(
                            language = block.language,
                            code = block.code,
                            onCopy = {
                                clipboard.setText(AnnotatedString(block.code))
                                onCodeCopied()
                            }
                        )
                    }

                    is MarkdownBlock.TextBlock -> {
                        val lines = block.text.lines()
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            lines.forEach { rawLine ->
                                val line = rawLine.trimEnd()
                                when {
                                    line.isBlank() -> Spacer(modifier = Modifier.height(2.dp))
                                    line.startsWith("### ") -> {
                                        Text(
                                            text = parseInlineStyles(line.removePrefix("### "), textColor),
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    line.startsWith("## ") -> {
                                        Text(
                                            text = parseInlineStyles(line.removePrefix("## "), textColor),
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    line.startsWith("# ") -> {
                                        Text(
                                            text = parseInlineStyles(line.removePrefix("# "), textColor),
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = textColor
                                        )
                                    }

                                    line.trimStart().startsWith("- ") || line.trimStart().startsWith("* ") -> {
                                        val indent = line.takeWhile { it == ' ' }.length
                                        val clean = line.trimStart().drop(2)
                                        Row(
                                            modifier = Modifier.padding(start = (indent.coerceAtMost(6) * 4).dp),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = "•",
                                                style = MaterialTheme.typography.bodyLarge,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = parseInlineStyles(clean, textColor),
                                                style = MaterialTheme.typography.bodyLarge,
                                                color = textColor
                                            )
                                        }
                                    }

                                    else -> {
                                        Text(
                                            text = parseInlineStyles(line, textColor),
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = textColor
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CodeBlockCard(
    language: String,
    code: String,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 2.dp
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = language.ifBlank { "code" }.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                IconButton(onClick = onCopy) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "คัดลอกโค้ด",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Text(
                text = code,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = DiamondMonoFont,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 14.dp, end = 14.dp, bottom = 12.dp)
            )
        }
    }
}

private fun splitMarkdownBlocks(markdown: String): List<MarkdownBlock> {
    val result = mutableListOf<MarkdownBlock>()
    val lines = markdown.lines()
    val textBuffer = StringBuilder()
    val codeBuffer = StringBuilder()
    var inCode = false
    var codeLang = ""

    for (line in lines) {
        val trimmed = line.trim()
        if (trimmed.startsWith("```")) {
            if (!inCode) {
                if (textBuffer.isNotBlank()) {
                    result.add(MarkdownBlock.TextBlock(textBuffer.toString().trimEnd()))
                    textBuffer.clear()
                }
                inCode = true
                codeLang = trimmed.removePrefix("```").trim()
                codeBuffer.clear()
            } else {
                result.add(MarkdownBlock.CodeBlock(codeLang, codeBuffer.toString().trimEnd()))
                codeBuffer.clear()
                inCode = false
                codeLang = ""
            }
        } else if (inCode) {
            codeBuffer.appendLine(line)
        } else {
            textBuffer.appendLine(line)
        }
    }

    if (inCode && codeBuffer.isNotBlank()) {
        result.add(MarkdownBlock.CodeBlock(codeLang, codeBuffer.toString().trimEnd()))
    } else if (textBuffer.isNotBlank()) {
        result.add(MarkdownBlock.TextBlock(textBuffer.toString().trimEnd()))
    }

    if (result.isEmpty()) {
        result.add(MarkdownBlock.TextBlock(markdown))
    }
    return result
}

private fun parseInlineStyles(text: String, baseColor: Color): AnnotatedString {
    return buildAnnotatedString {
        var i = 0
        while (i < text.length) {
            if (text.startsWith("**", i)) {
                val end = text.indexOf("**", i + 2)
                if (end != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = baseColor)) {
                        append(text.substring(i + 2, end))
                    }
                    i = end + 2
                    continue
                }
            }
            if (text[i] == '`') {
                val end = text.indexOf('`', i + 1)
                if (end != -1) {
                    withStyle(
                        SpanStyle(
                            fontFamily = DiamondMonoFont,
                            fontWeight = FontWeight.Medium
                        )
                    ) {
                        append(text.substring(i + 1, end))
                    }
                    i = end + 1
                    continue
                }
            }
            append(text[i])
            i++
        }
    }
}
