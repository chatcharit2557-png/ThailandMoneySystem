package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.data.ai.DiamondAiRepository
import com.example.data.local.DiamondLocalRepository

class DiamondViewModelFactory(
    private val aiRepository: DiamondAiRepository,
    private val localRepository: DiamondLocalRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ChatViewModel::class.java) ->
                ChatViewModel(aiRepository, localRepository) as T
            modelClass.isAssignableFrom(ToolsViewModel::class.java) ->
                ToolsViewModel(aiRepository, localRepository) as T
            modelClass.isAssignableFrom(VaultViewModel::class.java) ->
                VaultViewModel(localRepository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
