package com.example.ui

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.outlined.AutoAwesomeMosaic
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.rounded.AutoAwesomeMosaic
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.data.ai.DiamondToolType
import com.example.ui.components.DiamondAvatarBadge
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ToolDetailScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.ToolsViewModel
import com.example.ui.viewmodel.VaultViewModel

const val ROUTE_CHAT = "chat"
const val ROUTE_TOOLS = "tools"
const val ROUTE_TOOL_DETAIL = "tool_detail/{toolId}"
const val ROUTE_VAULT = "vault"

private data class TopLevelDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val topLevelDestinations = listOf(
    TopLevelDestination(
        route = ROUTE_CHAT,
        labelRes = R.string.nav_chat,
        selectedIcon = Icons.AutoMirrored.Rounded.Chat,
        unselectedIcon = Icons.AutoMirrored.Outlined.Chat,
        testTag = "nav_chat"
    ),
    TopLevelDestination(
        route = ROUTE_TOOLS,
        labelRes = R.string.nav_tools,
        selectedIcon = Icons.Rounded.AutoAwesomeMosaic,
        unselectedIcon = Icons.Outlined.AutoAwesomeMosaic,
        testTag = "nav_tools"
    ),
    TopLevelDestination(
        route = ROUTE_VAULT,
        labelRes = R.string.nav_vault,
        selectedIcon = Icons.Rounded.Bookmarks,
        unselectedIcon = Icons.Outlined.Bookmarks,
        testTag = "nav_vault"
    )
)

@SuppressLint("UnusedBoxWithConstraintsScope")
@Composable
fun DiamondApp(
    chatViewModel: ChatViewModel,
    toolsViewModel: ToolsViewModel,
    vaultViewModel: VaultViewModel,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val isDetailRoute = currentDestination?.route == ROUTE_TOOL_DETAIL

    fun navigateTopLevel(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useNavRail && !isDetailRoute) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 3.dp
                    ) {
                        topLevelDestinations.forEach { dest ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.route == dest.route
                            } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .consumeWindowInsets(innerPadding)
            ) {
                if (useNavRail && !isDetailRoute) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        header = {
                            DiamondAvatarBadge(
                                size = 40.dp,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )
                        },
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.weight(1f))
                        topLevelDestinations.forEach { dest ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.route == dest.route
                            } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = { Text(stringResource(dest.labelRes)) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_CHAT,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        composable(ROUTE_CHAT) {
                            ChatScreen(
                                viewModel = chatViewModel,
                                isDarkTheme = isDarkTheme,
                                onToggleTheme = onToggleTheme
                            )
                        }

                        composable(ROUTE_TOOLS) {
                            ToolsScreen(
                                onSelectTool = { tool ->
                                    navController.navigate("tool_detail/${tool.id}")
                                }
                            )
                        }

                        composable(
                            route = ROUTE_TOOL_DETAIL,
                            arguments = listOf(
                                navArgument("toolId") { type = NavType.StringType }
                            )
                        ) { entry ->
                            val toolId = entry.arguments?.getString("toolId").orEmpty()
                            val tool = DiamondToolType.fromId(toolId)
                            ToolDetailScreen(
                                tool = tool,
                                viewModel = toolsViewModel,
                                onBack = { navController.popBackStack() },
                                onContinueInChat = { title, prompt, result ->
                                    chatViewModel.continueFromTool(title, prompt, result)
                                    navigateTopLevel(ROUTE_CHAT)
                                }
                            )
                        }

                        composable(ROUTE_VAULT) {
                            VaultScreen(
                                viewModel = vaultViewModel,
                                onContinueInChat = { title, prompt, result ->
                                    chatViewModel.continueFromTool(title, prompt, result)
                                    navigateTopLevel(ROUTE_CHAT)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
