package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.CheckCircleOutline
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.ai.CodeResult
import com.example.data.ai.DiamondToolType
import com.example.data.ai.PlanResult
import com.example.data.ai.SummaryResult
import com.example.ui.components.CodeBlockCard
import com.example.ui.components.FacetedErrorCard
import com.example.ui.components.FormattedAiText
import com.example.ui.components.StreamingPulseIndicator
import com.example.ui.viewmodel.ToolUiState
import com.example.ui.viewmodel.ToolsViewModel

@Composable
fun ToolDetailScreen(
    tool: DiamondToolType,
    viewModel: ToolsViewModel,
    onBack: () -> Unit,
    onContinueInChat: (title: String, prompt: String, result: String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    DisposableEffect(tool) {
        onDispose {
            viewModel.resetState()
        }
    }

    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var inputText by rememberSaveable(tool.id) { mutableStateOf("") }
    var extraOptionOne by rememberSaveable(tool.id) {
        mutableStateOf(
            when (tool) {
                DiamondToolType.TRANSLATE -> "English"
                DiamondToolType.CODE_STUDIO -> "Kotlin"
                DiamondToolType.WRITER -> "อีเมล"
                DiamondToolType.IDEAS_RECIPE -> "สร้างสรรค์และทำง่าย"
                else -> ""
            }
        )
    }
    var extraOptionTwo by rememberSaveable(tool.id) {
        mutableStateOf(
            when (tool) {
                DiamondToolType.TRANSLATE -> "เป็นธรรมชาติ"
                DiamondToolType.CODE_STUDIO -> "เขียนโค้ด"
                DiamondToolType.WRITER -> "สุภาพเป็นมืออาชีพ"
                else -> ""
            }
        )
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 780.dp)
                .imePadding()
        ) {
            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("tool_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(R.string.back)
                    )
                }
                Icon(
                    imageVector = tool.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = tool.titleTh,
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = tool.badgeTh,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Tailored Option Chips per tool
                ToolOptionSection(
                    tool = tool,
                    optionOne = extraOptionOne,
                    onOptionOneChange = { extraOptionOne = it },
                    optionTwo = extraOptionTwo,
                    onOptionTwoChange = { extraOptionTwo = it }
                )

                // Input Box
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    label = { Text("ข้อมูลหรือคำสั่งของคุณ") },
                    placeholder = { Text(tool.inputHintTh) },
                    minLines = 4,
                    maxLines = 8,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tool_input_field")
                )

                Button(
                    onClick = {
                        viewModel.runTool(
                            tool = tool,
                            input = inputText,
                            optionOne = extraOptionOne,
                            optionTwo = extraOptionTwo
                        )
                    },
                    enabled = inputText.isNotBlank() && uiState !is ToolUiState.Loading,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("tool_run_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "สร้างผลลัพธ์ด้วย Diamond AI",
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                // Result Section
                when (val state = uiState) {
                    ToolUiState.Idle -> Unit

                    ToolUiState.Loading -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer
                        ) {
                            StreamingPulseIndicator(
                                label = "Diamond AI กำลังวิเคราะห์และจัดระเบียบผลลัพธ์...",
                                modifier = Modifier.padding(18.dp)
                            )
                        }
                    }

                    is ToolUiState.StreamingText -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                FormattedAiText(markdown = state.text)
                                Spacer(Modifier.height(6.dp))
                                StreamingPulseIndicator(label = "กำลังพิมพ์...")
                            }
                        }
                    }

                    is ToolUiState.TextSuccess -> {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            FormattedAiText(
                                markdown = state.text,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                        ToolResultActionRow(
                            onCopy = {
                                clipboard.setText(AnnotatedString(state.text))
                                Toast.makeText(context, context.getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
                            },
                            onSave = {
                                viewModel.saveToolResultToVault(
                                    title = "${tool.titleTh}: ${inputText.take(30)}",
                                    content = state.text,
                                    category = tool.titleTh
                                )
                                Toast.makeText(context, context.getString(R.string.saved_toast), Toast.LENGTH_SHORT).show()
                            },
                            onContinue = {
                                onContinueInChat(tool.titleTh, inputText, state.text)
                            }
                        )
                    }

                    is ToolUiState.SummarySuccess -> {
                        val plainExport = formatSummaryPlain(state.result)
                        StructuredSummaryCard(result = state.result)
                        ToolResultActionRow(
                            onCopy = {
                                clipboard.setText(AnnotatedString(plainExport))
                                Toast.makeText(context, context.getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
                            },
                            onSave = {
                                viewModel.saveToolResultToVault(
                                    title = state.result.headline,
                                    content = plainExport,
                                    category = tool.titleTh
                                )
                                Toast.makeText(context, context.getString(R.string.saved_toast), Toast.LENGTH_SHORT).show()
                            },
                            onContinue = {
                                onContinueInChat(state.result.headline, inputText, plainExport)
                            }
                        )
                    }

                    is ToolUiState.PlanSuccess -> {
                        val plainExport = formatPlanPlain(state.result)
                        StructuredPlanView(result = state.result)
                        ToolResultActionRow(
                            onCopy = {
                                clipboard.setText(AnnotatedString(plainExport))
                                Toast.makeText(context, context.getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
                            },
                            onSave = {
                                viewModel.saveToolResultToVault(
                                    title = state.result.planTitle,
                                    content = plainExport,
                                    category = tool.titleTh
                                )
                                Toast.makeText(context, context.getString(R.string.saved_toast), Toast.LENGTH_SHORT).show()
                            },
                            onContinue = {
                                onContinueInChat(state.result.planTitle, inputText, plainExport)
                            }
                        )
                    }

                    is ToolUiState.CodeSuccess -> {
                        val plainExport = formatCodePlain(state.result)
                        StructuredCodeView(
                            result = state.result,
                            onCopyCode = {
                                clipboard.setText(AnnotatedString(state.result.code))
                                Toast.makeText(context, context.getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
                            }
                        )
                        ToolResultActionRow(
                            onCopy = {
                                clipboard.setText(AnnotatedString(plainExport))
                                Toast.makeText(context, context.getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
                            },
                            onSave = {
                                viewModel.saveToolResultToVault(
                                    title = state.result.summary,
                                    content = plainExport,
                                    category = tool.titleTh
                                )
                                Toast.makeText(context, context.getString(R.string.saved_toast), Toast.LENGTH_SHORT).show()
                            },
                            onContinue = {
                                onContinueInChat(state.result.summary, inputText, plainExport)
                            }
                        )
                    }

                    is ToolUiState.Error -> {
                        FacetedErrorCard(
                            message = state.message,
                            onRetry = {
                                viewModel.runTool(tool, inputText, extraOptionOne, extraOptionTwo)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun ToolOptionSection(
    tool: DiamondToolType,
    optionOne: String,
    onOptionOneChange: (String) -> Unit,
    optionTwo: String,
    onOptionTwoChange: (String) -> Unit
) {
    when (tool) {
        DiamondToolType.TRANSLATE -> {
            ChipGroupRow(
                label = "แปลเป็นภาษา",
                options = listOf("English", "ไทย", "日本語", "中文", "한국어"),
                selected = optionOne,
                onSelect = onOptionOneChange
            )
            ChipGroupRow(
                label = "ระดับภาษา",
                options = listOf("เป็นธรรมชาติ", "ทางการ", "ธุรกิจสุภาพ", "สั้นกระชับ"),
                selected = optionTwo,
                onSelect = onOptionTwoChange
            )
        }

        DiamondToolType.CODE_STUDIO -> {
            ChipGroupRow(
                label = "ภาษาโปรแกรม",
                options = listOf("Kotlin", "Python", "JavaScript", "TypeScript", "SQL"),
                selected = optionOne,
                onSelect = onOptionOneChange
            )
            ChipGroupRow(
                label = "สิ่งที่ต้องการทำ",
                options = listOf("เขียนโค้ด", "แก้บั๊ก", "อธิบายโค้ด", "ปรับปรุงประสิทธิภาพ"),
                selected = optionTwo,
                onSelect = onOptionTwoChange
            )
        }

        DiamondToolType.WRITER -> {
            ChipGroupRow(
                label = "รูปแบบข้อความ",
                options = listOf("อีเมล", "แคปชันโซเชียล", "ประกาศทางการ", "ข้อความแชท"),
                selected = optionOne,
                onSelect = onOptionOneChange
            )
            ChipGroupRow(
                label = "โทนเสียง",
                options = listOf("สุภาพเป็นมืออาชีพ", "เป็นกันเอง", "น่าเชื่อถือ", "สนุกสนาน"),
                selected = optionTwo,
                onSelect = onOptionTwoChange
            )
        }

        DiamondToolType.IDEAS_RECIPE -> {
            ChipGroupRow(
                label = "สไตล์ที่ต้องการ",
                options = listOf("สร้างสรรค์และทำง่าย", "ประหยัดเวลา", "แปลกใหม่ไม่ซ้ำใคร", "แบบละเอียด"),
                selected = optionOne,
                onSelect = onOptionOneChange
            )
        }

        DiamondToolType.PLANNER -> {
            OutlinedTextField(
                value = optionOne,
                onValueChange = onOptionOneChange,
                label = { Text("งบประมาณ / ข้อจำกัดเพิ่มเติม (ไม่บังคับ)") },
                placeholder = { Text("เช่น งบไม่เกิน 5,000 บาท หรือ มีเวลาวันละ 1 ชม.") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        DiamondToolType.SUMMARIZE -> Unit
    }
}

@Composable
private fun ChipGroupRow(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(end = 8.dp)
        ) {
            items(options) { item ->
                FilterChip(
                    selected = selected == item,
                    onClick = { onSelect(item) },
                    label = { Text(item) }
                )
            }
        }
    }
}

@Composable
private fun StructuredSummaryCard(result: SummaryResult) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = result.headline,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = result.summary,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (result.keyPoints.isNotEmpty()) {
                Text(
                    text = "ประเด็นสำคัญ",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                result.keyPoints.forEach { point ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("•", color = MaterialTheme.colorScheme.primary)
                        Text(point, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            if (result.actionItems.isNotEmpty()) {
                Text(
                    text = "สิ่งที่ควรทำต่อ",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
                result.actionItems.forEach { action ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircleOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(action, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun StructuredPlanView(result: PlanResult) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = result.planTitle,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Schedule,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "ระยะเวลา: ${result.estimatedDuration}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = result.overview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        result.steps.forEachIndexed { index, step ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = step.stepTitle,
                                style = MaterialTheme.typography.titleSmall,
                                modifier = Modifier.weight(1f)
                            )
                            if (step.timeframe.isNotBlank()) {
                                Text(
                                    text = step.timeframe,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Text(
                            text = step.detail,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (result.proTips.isNotEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Lightbulb,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text("เคล็ดลับเพิ่มเติม", style = MaterialTheme.typography.titleSmall)
                    }
                    result.proTips.forEach { tip ->
                        Text("• $tip", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun StructuredCodeView(
    result: CodeResult,
    onCopyCode: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = result.summary,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                CodeBlockCard(
                    language = result.language,
                    code = result.code,
                    onCopy = onCopyCode
                )
                Text(
                    text = "คำอธิบาย",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = result.explanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (result.improvements.isNotEmpty()) {
                    Text(
                        text = "คำแนะนำเพิ่มเติม",
                        style = MaterialTheme.typography.titleSmall
                    )
                    result.improvements.forEach { tip ->
                        Text("• $tip", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolResultActionRow(
    onCopy: () -> Unit,
    onSave: () -> Unit,
    onContinue: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(
            onClick = onCopy,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(stringResource(R.string.copy_text))
        }
        OutlinedButton(
            onClick = onSave,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(Icons.Rounded.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(stringResource(R.string.save_to_vault))
        }
        Button(
            onClick = onContinue,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1.2f)
        ) {
            Icon(Icons.AutoMirrored.Rounded.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(stringResource(R.string.continue_in_chat), maxLines = 1)
        }
    }
}

private fun formatSummaryPlain(r: SummaryResult): String = buildString {
    appendLine("# ${r.headline}")
    appendLine(r.summary)
    if (r.keyPoints.isNotEmpty()) {
        appendLine("\n## ประเด็นสำคัญ")
        r.keyPoints.forEach { appendLine("- $it") }
    }
    if (r.actionItems.isNotEmpty()) {
        appendLine("\n## สิ่งที่ควรทำต่อ")
        r.actionItems.forEach { appendLine("- $it") }
    }
}

private fun formatPlanPlain(r: PlanResult): String = buildString {
    appendLine("# ${r.planTitle} (${r.estimatedDuration})")
    appendLine(r.overview)
    appendLine()
    r.steps.forEachIndexed { idx, step ->
        appendLine("### ${idx + 1}. ${step.stepTitle} [${step.timeframe}]")
        appendLine(step.detail)
    }
    if (r.proTips.isNotEmpty()) {
        appendLine("\n## เคล็ดลับเพิ่มเติม")
        r.proTips.forEach { appendLine("- $it") }
    }
}

private fun formatCodePlain(r: CodeResult): String = buildString {
    appendLine("### ${r.summary}")
    appendLine("```${r.language}")
    appendLine(r.code)
    appendLine("```")
    appendLine(r.explanation)
    if (r.improvements.isNotEmpty()) {
        appendLine("\nคำแนะนำเพิ่มเติม:")
        r.improvements.forEach { appendLine("- $it") }
    }
}
