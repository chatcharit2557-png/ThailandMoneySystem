package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.core.configureAppCheck
import com.example.data.ai.DiamondAiRepository
import com.example.data.local.DiamondDatabase
import com.example.data.local.DiamondLocalRepository
import com.example.ui.DiamondApp
import com.example.ui.theme.DiamondAiTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.DiamondViewModelFactory
import com.example.ui.viewmodel.ToolsViewModel
import com.example.ui.viewmodel.VaultViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check with launch intent before any UI or Firebase calls.
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        val database = DiamondDatabase.getInstance(applicationContext)
        val localRepository = DiamondLocalRepository(database.diamondDao())
        val aiRepository = DiamondAiRepository()
        val factory = DiamondViewModelFactory(aiRepository, localRepository)

        setContent {
            var isDarkTheme by rememberSaveable { mutableStateOf(true) }

            val chatViewModel: ChatViewModel = viewModel(factory = factory)
            val toolsViewModel: ToolsViewModel = viewModel(factory = factory)
            val vaultViewModel: VaultViewModel = viewModel(factory = factory)

            DiamondAiTheme(darkTheme = isDarkTheme) {
                DiamondApp(
                    chatViewModel = chatViewModel,
                    toolsViewModel = toolsViewModel,
                    vaultViewModel = vaultViewModel,
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = { isDarkTheme = !isDarkTheme }
                )
            }
        }
    }
}
