package com.example.data.local

import kotlinx.coroutines.flow.Flow

class DiamondLocalRepository(private val dao: DiamondDao) {
    val conversations: Flow<List<ConversationEntity>> = dao.getAllConversations()
    val savedItems: Flow<List<SavedItemEntity>> = dao.getAllSavedItems()

    fun getMessages(conversationId: Long): Flow<List<ChatMessage>> =
        dao.getMessagesForConversation(conversationId)

    suspend fun getMessagesSnapshot(conversationId: Long): List<ChatMessage> =
        dao.getMessagesSnapshot(conversationId)

    suspend fun createConversation(title: String, modeId: String): Long {
        return dao.insertConversation(
            ConversationEntity(
                title = title,
                modeId = modeId,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateConversationMeta(id: Long, title: String, modeId: String) {
        dao.updateConversation(
            id = id,
            title = title,
            modeId = modeId,
            updatedAt = System.currentTimeMillis()
        )
    }

    suspend fun deleteConversation(id: Long) {
        dao.deleteConversationById(id)
    }

    suspend fun addMessage(
        conversationId: Long,
        isUser: Boolean,
        text: String,
        imagePath: String? = null
    ): Long {
        return dao.insertMessage(
            ChatMessage(
                conversationId = conversationId,
                isUser = isUser,
                text = text,
                imagePath = imagePath,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteMessage(messageId: Long) {
        dao.deleteMessageById(messageId)
    }

    suspend fun saveToVault(title: String, content: String, category: String): Long {
        return dao.insertSavedItem(
            SavedItemEntity(
                title = title,
                content = content,
                category = category,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteSavedItem(id: Long) {
        dao.deleteSavedItemById(id)
    }
}
