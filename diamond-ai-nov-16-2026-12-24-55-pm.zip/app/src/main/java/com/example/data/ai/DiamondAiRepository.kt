package com.example.data.ai

import android.graphics.Bitmap
import com.example.data.local.ChatMessage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

class DiamondAiRepository {

    companion object {
        private const val DEFAULT_MODEL = "gemini-3.8-flash"
        private const val AI_TIMEOUT_MS = 60_000L
    }

    private val generalModel by lazy {
        Firebase.ai.generativeModel(
            modelName = DEFAULT_MODEL,
            systemInstruction = content { text(DiamondMode.GENERAL.systemPrompt) }
        )
    }

    private fun modelForMode(mode: DiamondMode) =
        if (mode == DiamondMode.GENERAL) {
            generalModel
        } else {
            Firebase.ai.generativeModel(
                modelName = DEFAULT_MODEL,
                systemInstruction = content { text(mode.systemPrompt) }
            )
        }

    fun streamChatResponse(
        mode: DiamondMode,
        history: List<ChatMessage>,
        prompt: String,
        attachedBitmap: Bitmap?
    ): Flow<String> = flow {
        val model = modelForMode(mode)
        val chatHistory = history
            .filter { it.text.isNotBlank() }
            .takeLast(20)
            .map { msg ->
                content(role = if (msg.isUser) "user" else "model") {
                    text(msg.text)
                }
            }

        val chat = model.startChat(history = chatHistory)
        val userContent = content("user") {
            if (attachedBitmap != null) {
                image(attachedBitmap)
            }
            text(prompt.ifBlank { "ช่วยวิเคราะห์รูปภาพนี้อย่างละเอียดและอธิบายเป็นภาษาไทย" })
        }

        withTimeout(AI_TIMEOUT_MS) {
            chat.sendMessageStream(userContent).collect { chunk ->
                val chunkText = chunk.text
                if (!chunkText.isNullOrEmpty()) {
                    emit(chunkText)
                }
            }
        }
    }

    fun streamToolText(
        systemPrompt: String,
        userPrompt: String
    ): Flow<String> = flow {
        val model by lazy {
            Firebase.ai.generativeModel(
                modelName = DEFAULT_MODEL,
                systemInstruction = content { text(systemPrompt) }
            )
        }
        withTimeout(AI_TIMEOUT_MS) {
            model.generateContentStream(userPrompt).collect { chunk ->
                val chunkText = chunk.text
                if (!chunkText.isNullOrEmpty()) {
                    emit(chunkText)
                }
            }
        }
    }

    suspend fun generateStructuredSummary(inputText: String): SummaryResult {
        val schema = Schema.obj(
            properties = mapOf(
                "headline" to Schema.string(description = "A concise headline summarizing the topic"),
                "summary" to Schema.string(description = "A clear 2-4 sentence executive summary in Thai (or same language as input)"),
                "keyPoints" to Schema.array(
                    items = Schema.string(),
                    description = "3 to 6 most important bullet points"
                ),
                "actionItems" to Schema.array(
                    items = Schema.string(),
                    description = "Concrete next steps or takeaways if applicable"
                )
            ),
            optionalProperties = listOf("actionItems")
        )

        val model = Firebase.ai.generativeModel(
            modelName = DEFAULT_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = schema
            }
        )

        val response = withTimeout(AI_TIMEOUT_MS) {
            model.generateContent(
                "สรุปเนื้อหาต่อไปนี้ให้กระชับ ชัดเจน และเป็นประเด็นสำคัญ (ตอบเป็นภาษาเดียวกับต้นฉบับ หรือภาษาไทย):\n\n$inputText"
            )
        }

        val jsonStr = response.text ?: throw IllegalStateException("AI ไม่ได้ส่งข้อความตอบกลับ")
        val json = JSONObject(jsonStr)
        val keyPointsJson = json.optJSONArray("keyPoints")
        val keyPoints = if (keyPointsJson != null) {
            (0 until keyPointsJson.length()).map { keyPointsJson.getString(it) }
        } else {
            emptyList()
        }
        val actionJson = json.optJSONArray("actionItems")
        val actionItems = if (actionJson != null) {
            (0 until actionJson.length()).map { actionJson.getString(it) }
        } else {
            emptyList()
        }

        return SummaryResult(
            headline = json.optString("headline", "สรุปเนื้อหา"),
            summary = json.optString("summary", ""),
            keyPoints = keyPoints,
            actionItems = actionItems
        )
    }

    suspend fun generateStructuredPlan(goal: String, details: String): PlanResult {
        val stepSchema = Schema.obj(
            properties = mapOf(
                "stepTitle" to Schema.string(description = "Short actionable title for this phase/step"),
                "timeframe" to Schema.string(description = "Suggested time or day (e.g., วันที่ 1, สัปดาห์ที่ 1, ช่วงเช้า)"),
                "detail" to Schema.string(description = "Detailed description of what to do in this step")
            )
        )

        val planSchema = Schema.obj(
            properties = mapOf(
                "planTitle" to Schema.string(description = "Catchy and clear title for the plan"),
                "estimatedDuration" to Schema.string(description = "Total estimated time or duration"),
                "overview" to Schema.string(description = "Brief overview of the strategy"),
                "steps" to Schema.array(
                    items = stepSchema,
                    description = "Sequential actionable steps (4 to 8 steps)"
                ),
                "proTips" to Schema.array(
                    items = Schema.string(),
                    description = "2 to 4 practical tips to ensure success"
                )
            ),
            optionalProperties = listOf("proTips")
        )

        val model = Firebase.ai.generativeModel(
            modelName = DEFAULT_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = planSchema
            }
        )

        val prompt = buildString {
            append("ช่วยวางแผนอย่างละเอียดและทำได้จริงสำหรับเป้าหมาย: $goal")
            if (details.isNotBlank()) {
                append("\nเงื่อนไข/รายละเอียดเพิ่มเติม: $details")
            }
            append("\nตอบเป็นภาษาไทยที่อ่านง่าย ชัดเจน")
        }

        val response = withTimeout(AI_TIMEOUT_MS) {
            model.generateContent(prompt)
        }

        val jsonStr = response.text ?: throw IllegalStateException("AI ไม่ได้ส่งข้อความตอบกลับ")
        val json = JSONObject(jsonStr)
        val stepsArr = json.optJSONArray("steps")
        val steps = if (stepsArr != null) {
            (0 until stepsArr.length()).map { idx ->
                val obj = stepsArr.getJSONObject(idx)
                PlanStep(
                    stepTitle = obj.optString("stepTitle", "ขั้นตอนที่ ${idx + 1}"),
                    timeframe = obj.optString("timeframe", ""),
                    detail = obj.optString("detail", "")
                )
            }
        } else {
            emptyList()
        }

        val tipsArr = json.optJSONArray("proTips")
        val tips = if (tipsArr != null) {
            (0 until tipsArr.length()).map { tipsArr.getString(it) }
        } else {
            emptyList()
        }

        return PlanResult(
            planTitle = json.optString("planTitle", goal),
            estimatedDuration = json.optString("estimatedDuration", "-"),
            overview = json.optString("overview", ""),
            steps = steps,
            proTips = tips
        )
    }

    suspend fun generateStructuredCode(
        task: String,
        language: String,
        actionType: String
    ): CodeResult {
        val codeSchema = Schema.obj(
            properties = mapOf(
                "summary" to Schema.string(description = "Brief 1-sentence summary of the solution"),
                "language" to Schema.string(description = "Programming language name"),
                "code" to Schema.string(description = "Clean, complete, ready-to-use source code without markdown fences"),
                "explanation" to Schema.string(description = "Clear explanation of how the code works or how the bug was fixed"),
                "improvements" to Schema.array(
                    items = Schema.string(),
                    description = "2 to 3 best practices or performance/safety tips"
                )
            ),
            optionalProperties = listOf("improvements")
        )

        val model = Firebase.ai.generativeModel(
            modelName = DEFAULT_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = codeSchema
            }
        )

        val prompt = """
            Action: $actionType
            Programming Language: $language
            Request / Code:
            $task

            Provide clean production-quality code and explain clearly in Thai (keep technical terms in English).
        """.trimIndent()

        val response = withTimeout(AI_TIMEOUT_MS) {
            model.generateContent(prompt)
        }

        val jsonStr = response.text ?: throw IllegalStateException("AI ไม่ได้ส่งข้อความตอบกลับ")
        val json = JSONObject(jsonStr)
        val impArr = json.optJSONArray("improvements")
        val improvements = if (impArr != null) {
            (0 until impArr.length()).map { impArr.getString(it) }
        } else {
            emptyList()
        }

        return CodeResult(
            summary = json.optString("summary", "ผลลัพธ์โค้ด"),
            language = json.optString("language", language),
            code = json.optString("code", ""),
            explanation = json.optString("explanation", ""),
            improvements = improvements
        )
    }
}
