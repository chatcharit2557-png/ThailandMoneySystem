package com.example.data.ai

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Summarize
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.ui.graphics.vector.ImageVector

enum class DiamondToolType(
    val id: String,
    val titleTh: String,
    val descriptionTh: String,
    val badgeTh: String,
    val icon: ImageVector,
    val inputHintTh: String
) {
    SUMMARIZE(
        id = "summarize",
        titleTh = "สรุปเนื้อหาอัจฉริยะ",
        descriptionTh = "ย่อบทความยาวๆ หรือบันทึกการประชุมเป็นประเด็นสำคัญและสิ่งที่ต้องทำ",
        badgeTh = "Structured AI",
        icon = Icons.Rounded.Summarize,
        inputHintTh = "วางบทความ เนื้อหา หรือบันทึกการประชุมที่ต้องการสรุปที่นี่..."
    ),
    PLANNER(
        id = "planner",
        titleTh = "วางแผนโปรเจกต์ & ทริป",
        descriptionTh = "สร้างแผนงานเป็นขั้นตอน พร้อมกรอบเวลาและเคล็ดลับทำสำเร็จ",
        badgeTh = "Step-by-Step",
        icon = Icons.Rounded.CalendarMonth,
        inputHintTh = "เช่น วางแผนลดน้ำหนัก 30 วัน, ทริปญี่ปุ่น 5 วัน, หรือเปิดร้านกาแฟ..."
    ),
    CODE_STUDIO(
        id = "code_studio",
        titleTh = "Code & Debug Studio",
        descriptionTh = "เขียนโค้ดใหม่ อธิบายการทำงาน หรือตรวจหาจุดผิดพลาดพร้อมคำแนะนำ",
        badgeTh = "Developer",
        icon = Icons.Rounded.Code,
        inputHintTh = "บอกสิ่งที่ต้องการให้เขียน หรือวางโค้ดที่มีบั๊กให้ช่วยตรวจสอบ..."
    ),
    TRANSLATE(
        id = "translate",
        titleTh = "นักแปลภาษามืออาชีพ",
        descriptionTh = "แปลภาษาอย่างเป็นธรรมชาติ เลือกระดับภาษาได้ทั้งทางการและเป็นกันเอง",
        badgeTh = "Multi-Lang",
        icon = Icons.Rounded.Translate,
        inputHintTh = "พิมพ์หรือวางข้อความที่ต้องการแปลที่นี่..."
    ),
    WRITER(
        id = "writer",
        titleTh = "ร่างอีเมล & แคปชัน",
        descriptionTh = "สร้างอีเมลธุรกิจ ข้อความสำคัญ หรือโพสต์โซเชียลให้น่าสนใจ",
        badgeTh = "Copywriting",
        icon = Icons.Rounded.Email,
        inputHintTh = "บอกหัวข้อหรือประเด็นที่ต้องการสื่อสาร (เช่น ขอลาพักร้อน, ขายสินค้า)..."
    ),
    IDEAS_RECIPE(
        id = "ideas_recipe",
        titleTh = "คิดไอเดีย & สูตรอาหาร",
        descriptionTh = "เปลี่ยนวัตถุดิบในตู้เย็นเป็นเมนูเด็ด หรือระดมสมองไอเดียสร้างสรรค์",
        badgeTh = "Creative",
        icon = Icons.Rounded.Restaurant,
        inputHintTh = "เช่น มีอกไก่ ไข่ กระเทียม ทำเมนูอะไรดี หรือ ขอไอเดียของขวัญวันเกิด..."
    );

    companion object {
        fun fromId(id: String): DiamondToolType = entries.find { it.id == id } ?: SUMMARIZE
    }
}

data class SummaryResult(
    val headline: String,
    val summary: String,
    val keyPoints: List<String>,
    val actionItems: List<String>
)

data class PlanStep(
    val stepTitle: String,
    val timeframe: String,
    val detail: String
)

data class PlanResult(
    val planTitle: String,
    val estimatedDuration: String,
    val overview: String,
    val steps: List<PlanStep>,
    val proTips: List<String>
)

data class CodeResult(
    val summary: String,
    val language: String,
    val code: String,
    val explanation: String,
    val improvements: List<String>
)
