package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ConversationEntity::class, ChatMessage::class, SavedItemEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DiamondDatabase : RoomDatabase() {
    abstract fun diamondDao(): DiamondDao

    companion object {
        @Volatile
        private var INSTANCE: DiamondDatabase? = null

        fun getInstance(context: Context): DiamondDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DiamondDatabase::class.java,
                    "diamond_ai_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
