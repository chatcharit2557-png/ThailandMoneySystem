package com.example.data.ai

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.School
import androidx.compose.ui.graphics.vector.ImageVector

enum class DiamondMode(
    val id: String,
    val labelTh: String,
    val subtitleTh: String,
    val icon: ImageVector,
    val systemPrompt: String
) {
    GENERAL(
        id = "general",
        labelTh = "รอบรู้ทุกเรื่อง",
        subtitleTh = "ผู้ช่วยส่วนตัวอัจฉริยะ ถาม-ตอบและช่วยงานทั่วไป",
        icon = Icons.Rounded.AutoAwesome,
        systemPrompt = """
            You are Diamond AI, an ultra-capable, friendly, and accurate all-purpose AI assistant.
            Respond in the user's language (default to natural, polite, clear Thai when asked in Thai, or English when asked in English).
            Structure answers clearly with concise bullet points or numbered steps when helpful.
            Be practical, proactive, and insightful.
        """.trimIndent()
    ),
    CODE(
        id = "code",
        labelTh = "โค้ด & เทค",
        subtitleTh = "เขียนโค้ด แก้บั๊ก ออกแบบระบบ และอธิบายเทคนิค",
        icon = Icons.Rounded.Code,
        systemPrompt = """
            You are Diamond AI (Code & Tech Specialist), a senior software architect and engineer.
            Provide clean, production-grade code inside fenced markdown code blocks (e.g. ```kotlin), explain edge cases, and offer concise debugging steps.
            Respond in the user's language (Thai or English).
        """.trimIndent()
    ),
    WRITE(
        id = "write",
        labelTh = "เขียน & แปล",
        subtitleTh = "แต่งคอนเทนต์ ร่างอีเมล สรุปความ และแปลภาษาธรรมชาติ",
        icon = Icons.Rounded.EditNote,
        systemPrompt = """
            You are Diamond AI (Writing & Translation Expert), skilled in persuasive copywriting, formal/casual Thai & English communication, natural translation, and crisp summarization.
            Preserve nuance, tone, and clarity.
        """.trimIndent()
    ),
    TUTOR(
        id = "tutor",
        labelTh = "ติวเตอร์อัจฉริยะ",
        subtitleTh = "อธิบายบทเรียน คณิตศาสตร์ วิทยาศาสตร์ แบบเข้าใจง่าย",
        icon = Icons.Rounded.School,
        systemPrompt = """
            You are Diamond AI (Smart Tutor), a patient and brilliant teacher.
            Break down complex concepts, math problems, or science questions step-by-step with relatable analogies and clear verification steps.
        """.trimIndent()
    ),
    PLAN(
        id = "plan",
        labelTh = "วางแผน & ไอเดีย",
        subtitleTh = "คิดโปรเจกต์ วางแผนเที่ยว จัดตารางงาน และกลยุทธ์",
        icon = Icons.Rounded.Lightbulb,
        systemPrompt = """
            You are Diamond AI (Creative Strategist & Planner).
            Generate actionable plans, creative brainstorms, checklists, timelines, and pros/cons comparisons tailored to the user's goals.
        """.trimIndent()
    );

    companion object {
        fun fromId(id: String): DiamondMode = entries.find { it.id == id } ?: GENERAL
    }
}

data class StarterPrompt(
    val title: String,
    val subtitle: String,
    val prompt: String,
    val mode: DiamondMode
)

val defaultStarterPrompts = listOf(
    StarterPrompt(
        title = "วางแผนทริปสุดสัปดาห์",
        subtitle = "จัดตารางเที่ยว 2 วัน 1 คืน พร้อมงบประมาณ",
        prompt = "ช่วยวางแผนทริปเที่ยวเชียงใหม่ 2 วัน 1 คืน แบบชิลๆ เน้นคาเฟ่ ธรรมชาติ และอาหารท้องถิ่น พร้อมประมาณงบให้ด้วย",
        mode = DiamondMode.PLAN
    ),
    StarterPrompt(
        title = "ช่วยเขียน & แก้โค้ด",
        subtitle = "เขียนฟังก์ชัน หรือหาสาเหตุบั๊กอย่างรวดเร็ว",
        prompt = "ช่วยอธิบายความแตกต่างระหว่าง StateFlow กับ SharedFlow ใน Kotlin Coroutines พร้อมตัวอย่างการใช้งานจริง",
        mode = DiamondMode.CODE
    ),
    StarterPrompt(
        title = "ร่างข้อความ & แปลภาษา",
        subtitle = "เขียนอีเมลมืออาชีพ หรือแปลภาษาแบบเป็นธรรมชาติ",
        prompt = "ช่วยร่างอีเมลภาษาอังกฤษแบบสุภาพ เพื่อขอเลื่อนนัดประชุมกับลูกค้าจากวันพุธเป็นวันศุกร์ พร้อมคำแปลภาษาไทย",
        mode = DiamondMode.WRITE
    ),
    StarterPrompt(
        title = "ติวเรื่องยากให้เข้าใจง่าย",
        subtitle = "สรุปความรู้หรือแก้โจทย์ทีละขั้นตอน",
        prompt = "ช่วยอธิบายหลักการทำงานของ AI และ Machine Learning ให้คนทั่วไปเข้าใจง่ายๆ ภายใน 5 ข้อ",
        mode = DiamondMode.TUTOR
    )
)
