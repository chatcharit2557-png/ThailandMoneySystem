package com.globalmarket.listeners;

import com.globalmarket.GlobalMarket;
import com.globalmarket.gui.AuctionHouseGUI;
import com.globalmarket.gui.CommandMenuGUI;
import com.globalmarket.gui.SellGUI;
import com.globalmarket.gui.ShopGUI;
import com.globalmarket.models.AuctionListing;
import com.globalmarket.models.ShopItem;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class GUIListener implements Listener {

    private final GlobalMarket plugin;

    public GUIListener(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        Player player = (Player) event.getPlayer();

        if (!event.getView().getTitle().equals(SellGUI.TITLE)) return;

        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
        double totalEarned = 0;
        int itemCount = 0;

        for (int slot : SellGUI.SELL_SLOTS) {
            ItemStack item = event.getInventory().getItem(slot);
            if (item == null || item.getType() == Material.AIR) continue;

            // ห้ามขายเหรียญตลาด - คืนเสมอ
            if (com.globalmarket.utils.CoinItem.isCoin(plugin, item)) {
                player.getInventory().addItem(item.clone());
                continue;
            }

            double price = plugin.getShopManager().getSellPrice(item.getType());
            if (price <= 0) {
                // ของที่ขายไม่ได้ คืนผู้เล่น
                player.getInventory().addItem(item.clone());
                continue;
            }

            double tax = price * item.getAmount() * plugin.getConfig().getDouble("economy.tax-rate", 0.05);
            double net = price * item.getAmount() - tax;
            totalEarned += net;
            itemCount += item.getAmount();
        }

        if (totalEarned > 0) {
            plugin.getEconomy().depositPlayer(player, totalEarned);
            player.sendMessage(GUIUtils.color("&8[&6Market&8] &a✔ ขายสำเร็จ! &e" + itemCount
                    + " ชิ้น &a→ &6" + currency + String.format("%.2f", totalEarned)));
        } else if (itemCount == 0) {
            // ไม่มีของ ไม่ต้องแจ้ง
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        String title = event.getView().getTitle();
        ItemStack clicked = event.getCurrentItem();

        if (clicked == null || clicked.getType() == Material.AIR) return;

        // ===== COMMAND MENU =====
        if (title.equals(CommandMenuGUI.TITLE)) {
            event.setCancelled(true);
            String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().hasDisplayName()
                    ? clicked.getItemMeta().getDisplayName() : "";

            if (itemName.contains("ขายไอเทม")) {
                player.closeInventory();
                player.performCommand("sell");
            } else if (itemName.contains("ร้านค้าโลก")) {
                player.closeInventory();
                player.performCommand("shop");
            } else if (itemName.contains("Auction House")) {
                player.closeInventory();
                player.performCommand("ah");
            } else if (itemName.contains("ลงขายใน AH")) {
                player.closeInventory();
                // แจ้งให้ใส่ราคา
                player.sendMessage(GUIUtils.color("&8[&6Market&8] &eพิมพ์ราคาที่ต้องการ: &f/ahsell <ราคา>"));
            } else if (itemName.contains("รายการของฉัน")) {
                player.closeInventory();
                com.globalmarket.gui.AuctionHouseGUI.openMyListings(player, plugin);
            } else if (itemName.contains("ปิด")) {
                player.closeInventory();
            }
            return;
        }

        // ===== COIN MENU จาก GUI อื่น =====
        if (clicked.getType() == org.bukkit.Material.SUNFLOWER) {
            String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().hasDisplayName()
                    ? clicked.getItemMeta().getDisplayName() : "";
            if (itemName.contains("เมนูตลาด")) {
                event.setCancelled(true);
                CommandMenuGUI.open(player, plugin);
                return;
            }
        }

        // ===== SELL GUI =====
        if (title.equals(SellGUI.TITLE)) {
            // ป้องกันคลิกในโซนล่าง (ตกแต่ง)
            int slot = event.getSlot();
            boolean isBottomBar = slot >= 27 && slot < 54;

            if (isBottomBar) {
                event.setCancelled(true);
                // ปุ่มยกเลิก
                String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().hasDisplayName()
                        ? clicked.getItemMeta().getDisplayName() : "";
                if (itemName.contains("ยกเลิก")) {
                    // คืนของในช่องวางกลับ inventory ผู้เล่น
                    for (int s : SellGUI.SELL_SLOTS) {
                        ItemStack inSlot = event.getInventory().getItem(s);
                        if (inSlot != null && inSlot.getType() != Material.AIR) {
                            player.getInventory().addItem(inSlot.clone());
                            event.getInventory().setItem(s, null);
                        }
                    }
                    player.closeInventory();
                }
                return;
            }

            // อัพเดทราคาเรียลไทม์หลังคลิก (delay 1 tick รอ item เปลี่ยน)
            org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.getOpenInventory().getTitle().equals(SellGUI.TITLE)) {
                    double total = SellGUI.calculateTotal(event.getInventory(), plugin);
                    SellGUI.updatePriceDisplay(event.getInventory(), plugin, total,
                            plugin.getConfig().getString("economy.currency-symbol", "$"));
                }
            }, 1L);
            return;
        }

        // ===== AUCTION HOUSE =====
        if (title.startsWith(AuctionHouseGUI.TITLE_PREFIX)) {
            event.setCancelled(true);

            String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().hasDisplayName()
                    ? clicked.getItemMeta().getDisplayName() : "";

            if (itemName.contains("ปิด")) { player.closeInventory(); return; }

            if (itemName.contains("หน้าก่อน") || itemName.contains("◀")) {
                int currentPage = getCurrentPage(title);
                AuctionHouseGUI.open(player, plugin, currentPage - 1);
                return;
            }
            if (itemName.contains("ถัดไป") || itemName.contains("▶")) {
                int currentPage = getCurrentPage(title);
                AuctionHouseGUI.open(player, plugin, currentPage + 1);
                return;
            }
            if (itemName.contains("รายการของฉัน")) {
                AuctionHouseGUI.openMyListings(player, plugin);
                return;
            }
            if (itemName.contains("รีเฟรช")) {
                AuctionHouseGUI.open(player, plugin, getCurrentPage(title));
                return;
            }
            if (itemName.contains("กลับ")) {
                AuctionHouseGUI.open(player, plugin, 1);
                return;
            }

            // คลิกไอเทมเพื่อซื้อ
            if (event.getSlot() < 45 && clicked.getType() != Material.GRAY_STAINED_GLASS_PANE) {
                List<AuctionListing> listings = plugin.getAuctionManager().getActiveListings();

                // หา listing จาก slot
                int pageNum = getCurrentPage(title);
                int index = (pageNum - 1) * 45 + event.getSlot();
                if (index >= 0 && index < listings.size()) {
                    AuctionListing listing = listings.get(index);

                    if (event.isRightClick() && title.contains("รายการของฉัน")) {
                        // ยกเลิก listing
                        if (plugin.getAuctionManager().cancelListing(player, listing.getId())) {
                            player.sendMessage(GUIUtils.color("&8[&6Market&8] &aยกเลิกรายการ &e" + listing.getId() + " &aเรียบร้อย"));
                            AuctionHouseGUI.openMyListings(player, plugin);
                        }
                        return;
                    }

                    // ซื้อ
                    if (listing.getSellerUUID().equals(player.getUniqueId())) {
                        player.sendMessage(GUIUtils.color("&8[&6Market&8] &cคุณไม่สามารถซื้อไอเทมของตัวเองได้!"));
                        return;
                    }
                    if (!plugin.getEconomyManager().hasEnough(player, listing.getPrice())) {
                        player.sendMessage(GUIUtils.color("&8[&6Market&8] &cเงินไม่พอ! ต้องการ &e"
                                + plugin.getConfig().getString("economy.currency-symbol", "$")
                                + String.format("%.2f", listing.getPrice())));
                        return;
                    }

                    // ยืนยันการซื้อ - เปิด confirm GUI
                    openConfirmGUI(player, listing);
                }
            }
            return;
        }

        // ===== CONFIRM BUY =====
        if (title.startsWith("§6§l ยืนยันการซื้อ")) {
            event.setCancelled(true);
            String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().hasDisplayName()
                    ? clicked.getItemMeta().getDisplayName() : "";

            if (itemName.contains("§a§l✔")) {
                // ดึง listing ID จาก lore
                String listingId = getListingIdFromMeta(clicked);
                if (listingId != null) {
                    if (plugin.getAuctionManager().buyListing(player, listingId)) {
                        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
                        player.sendMessage(GUIUtils.color("&8[&6Market&8] &aซื้อไอเทมสำเร็จ!"));
                        player.closeInventory();
                    } else {
                        player.sendMessage(GUIUtils.color("&8[&6Market&8] &cไม่สามารถซื้อได้ รายการอาจถูกขายไปแล้ว"));
                        AuctionHouseGUI.open(player, plugin, 1);
                    }
                }
                return;
            }
            if (itemName.contains("§c§l✘")) {
                player.closeInventory();
                AuctionHouseGUI.open(player, plugin, 1);
            }
            return;
        }

        // ===== SHOP MAIN =====
        if (title.equals(ShopGUI.TITLE_PREFIX + " §8│ §7หมวดหมู่")) {
            event.setCancelled(true);
            String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().hasDisplayName()
                    ? clicked.getItemMeta().getDisplayName() : "";

            if (itemName.contains("ปิด")) { player.closeInventory(); return; }

            // อ่าน category ID จาก PDC ที่เก็บไว้ใน item
            if (clicked.getItemMeta() != null) {
                org.bukkit.NamespacedKey catKey = new org.bukkit.NamespacedKey(plugin, "shop_category");
                String catId = clicked.getItemMeta().getPersistentDataContainer()
                        .get(catKey, org.bukkit.persistence.PersistentDataType.STRING);
                if (catId != null) {
                    ShopGUI.openCategory(player, plugin, catId, 1);
                    return;
                }
            }
            return;
        }

        // ===== SHOP CATEGORY =====
        if (title.startsWith(ShopGUI.TITLE_PREFIX + " §8│")) {
            event.setCancelled(true);
            String itemName = clicked.getItemMeta() != null && clicked.getItemMeta().hasDisplayName()
                    ? clicked.getItemMeta().getDisplayName() : "";

            if (itemName.contains("ปิด")) { player.closeInventory(); return; }
            if (itemName.contains("◀ กลับ")) { ShopGUI.openMain(player, plugin); return; }
            if (itemName.contains("◀")) {
                String catId = extractCategoryFromTitle(title);
                ShopGUI.openCategory(player, plugin, catId, getCurrentPage(title) - 1);
                return;
            }
            if (itemName.contains("▶")) {
                String catId = extractCategoryFromTitle(title);
                ShopGUI.openCategory(player, plugin, catId, getCurrentPage(title) + 1);
                return;
            }

            // คลิกไอเทม
            if (event.getSlot() >= 9 && event.getSlot() < 45
                    && clicked.getType() != Material.GRAY_STAINED_GLASS_PANE) {
                handleShopItemClick(player, clicked, event.isShiftClick(), event.isRightClick());
            }
        }
    }

    private void openConfirmGUI(Player player, AuctionListing listing) {
        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
        org.bukkit.inventory.Inventory inv = org.bukkit.Bukkit.createInventory(null, 27,
                "§6§l ยืนยันการซื้อ");

        for (int i = 0; i < 27; i++) inv.setItem(i, GUIUtils.createGlassPane("§r"));

        // ไอเทม
        inv.setItem(13, listing.getItem());

        // ปุ่มยืนยัน
        ItemStack confirm = GUIUtils.createItem(Material.LIME_WOOL, "§a§l✔ ยืนยัน",
                "§fราคา: §6" + currency + String.format("%.2f", listing.getPrice()),
                "§fผู้ขาย: §b" + listing.getSellerName(),
                "§7─────────────",
                "§aคลิกเพื่อซื้อ",
                "§7ID:" + listing.getId());
        inv.setItem(11, confirm);

        // ปุ่มยกเลิก
        ItemStack cancel = GUIUtils.createItem(Material.RED_WOOL, "§c§l✘ ยกเลิก",
                "§7กลับไป Auction House");
        inv.setItem(15, cancel);

        player.openInventory(inv);
    }

    private String getListingIdFromMeta(ItemStack item) {
        if (item.getItemMeta() == null || item.getItemMeta().getLore() == null) return null;
        for (String line : item.getItemMeta().getLore()) {
            if (line.contains("ID:")) {
                return org.bukkit.ChatColor.stripColor(line).replace("ID:", "").trim();
            }
        }
        return null;
    }

    private void handleShopItemClick(Player player, ItemStack clicked, boolean shift, boolean rightClick) {
        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
        String matName = clicked.getType().name();

        ShopItem shopItem = plugin.getShopManager().getAllItems().stream()
                .filter(i -> i.getMaterial() == clicked.getType())
                .findFirst().orElse(null);

        if (shopItem == null) return;

        if (!rightClick) {
            // ซื้อ
            int amount = shift ? 64 : 1;
            if (plugin.getShopManager().buyItem(player, shopItem, amount)) {
                player.sendMessage(GUIUtils.color("&8[&6Market&8] &aซื้อ &e" + shopItem.getDisplayName()
                        + " &ax" + amount + " &aราคา &6" + currency
                        + String.format("%.2f", shopItem.getBuyPrice() * amount)));
            } else {
                player.sendMessage(GUIUtils.color("&8[&6Market&8] &cเงินไม่พอ!"));
            }
        } else {
            // ขาย
            ItemStack inHand = player.getInventory().getItemInMainHand();
            if (inHand.getType() == clicked.getType()) {
                double earned = plugin.getShopManager().sellItemToShop(player, inHand);
                if (earned > 0) {
                    player.sendMessage(GUIUtils.color("&8[&6Market&8] &aขาย &e" + shopItem.getDisplayName()
                            + " &aได้ &6" + currency + String.format("%.2f", earned)));
                }
            } else {
                player.sendMessage(GUIUtils.color("&8[&6Market&8] &eถือไอเทมนั้นแล้วคลิกขวาเพื่อขาย"));
            }
        }
    }

    private boolean isCategoryItem(ItemStack item, String catId) {
        if (item.getItemMeta() == null || item.getItemMeta().getLore() == null) return false;
        for (String line : item.getItemMeta().getLore()) {
            if (line.contains("สินค้า:")) return true;
        }
        return false;
    }

    private int getCurrentPage(String title) {
        try {
            if (title.contains("หน้า")) {
                String pageStr = title.substring(title.lastIndexOf("หน้า ") + 5);
                if (pageStr.contains("/")) pageStr = pageStr.substring(0, pageStr.indexOf("/"));
                return Integer.parseInt(org.bukkit.ChatColor.stripColor(pageStr).trim());
            }
        } catch (Exception ignored) {}
        return 1;
    }

    private String extractCategoryFromTitle(String title) {
        // "§a§lGlobal Shop §8│ §c§lอาวุธ §8│ §71/2" -> หมวดหมู่
        String[] catIds = {"weapons", "armor", "tools", "food", "blocks", "materials", "potions", "misc"};
        String[][] catNames = {{"อาวุธ"}, {"เกราะ"}, {"เครื่องมือ"}, {"อาหาร"},
                               {"บล็อก"}, {"วัตถุดิบ"}, {"ยา"}, {"อื่นๆ"}};
        for (int i = 0; i < catIds.length; i++) {
            if (title.contains(catNames[i][0])) return catIds[i];
        }
        return "misc";
    }
}
