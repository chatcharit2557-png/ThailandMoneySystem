package com.globalmarket;

import com.globalmarket.commands.*;
import com.globalmarket.gui.SidebarManager;
import com.globalmarket.managers.AuctionManager;
import com.globalmarket.managers.ShopManager;
import com.globalmarket.managers.EconomyManager;
import com.globalmarket.managers.DataManager;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class GlobalMarket extends JavaPlugin {

    private static GlobalMarket instance;
    private Economy economy;
    private AuctionManager auctionManager;
    private ShopManager shopManager;
    private EconomyManager economyManager;
    private DataManager dataManager;
    private SidebarManager sidebarManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        if (!setupEconomy()) {
            getLogger().severe("Vault หรือ Economy plugin ไม่พบ! กรุณาติดตั้ง Vault");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Init managers
        dataManager = new DataManager(this);
        economyManager = new EconomyManager(this, economy);
        auctionManager = new AuctionManager(this);
        shopManager = new ShopManager(this);
        sidebarManager = new SidebarManager(this);

        // Register commands
        getCommand("sell").setExecutor(new SellCommand(this));
        getCommand("ah").setExecutor(new AHCommand(this));
        getCommand("ahsell").setExecutor(new AHSellCommand(this));
        getCommand("shop").setExecutor(new ShopCommand(this));
        getCommand("menu").setExecutor(new com.globalmarket.commands.MenuCommand(this));
        getCommand("gmarket").setExecutor(new AdminCommand(this));

        // Register listeners
        getServer().getPluginManager().registerEvents(new com.globalmarket.listeners.GUIListener(this), this);
        getServer().getPluginManager().registerEvents(new com.globalmarket.listeners.PlayerListener(this), this);

        getLogger().info("GlobalMarket เปิดใช้งานแล้ว! 🏪");
    }

    @Override
    public void onDisable() {
        if (sidebarManager != null) sidebarManager.cleanup();
        if (auctionManager != null) auctionManager.saveAll();
        if (dataManager != null) dataManager.saveAll();
        getLogger().info("GlobalMarket ปิดใช้งานแล้ว!");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        economy = rsp.getProvider();
        return economy != null;
    }

    public static GlobalMarket getInstance() { return instance; }
    public Economy getEconomy() { return economy; }
    public AuctionManager getAuctionManager() { return auctionManager; }
    public ShopManager getShopManager() { return shopManager; }
    public EconomyManager getEconomyManager() { return economyManager; }
    public DataManager getDataManager() { return dataManager; }
    public SidebarManager getSidebarManager() { return sidebarManager; }
}
