package com.globalmarket.commands;

import com.globalmarket.GlobalMarket;
import com.globalmarket.gui.CommandMenuGUI;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MenuCommand implements CommandExecutor {

    private final GlobalMarket plugin;

    public MenuCommand(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(GUIUtils.color("&cใช้ได้เฉพาะผู้เล่นเท่านั้น!"));
            return true;
        }
        CommandMenuGUI.open((Player) sender, plugin);
        return true;
    }
}
