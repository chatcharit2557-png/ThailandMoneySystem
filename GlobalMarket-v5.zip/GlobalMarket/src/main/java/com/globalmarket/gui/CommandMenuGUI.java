package com.globalmarket.gui;

import com.globalmarket.GlobalMarket;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class CommandMenuGUI {

    public static final String TITLE = "§6§l💰 เมนูตลาด";

    public static void open(Player player, GlobalMarket plugin) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);

        // ตกแต่ง
        for (int i = 0; i < 27; i++) inv.setItem(i, GUIUtils.createGlassPane("§r"));

        // หัวข้อ
        inv.setItem(4, GUIUtils.createItem(Material.SUNFLOWER,
                "§6§l✦ เมนูตลาด ✦",
                "§7กดเลือกคำสั่งที่ต้องการ"));

        // /sell - ขายไอเทม
        inv.setItem(10, GUIUtils.createItem(Material.GOLD_NUGGET,
                "§e§l💰 ขายไอเทม",
                "§7─────────────────",
                "§fเปิดหน้าต่างขายของ",
                "§fวางของแล้วปิดเพื่อขาย",
                "§7─────────────────",
                "§aคลิกเพื่อใช้ §8(/sell)"));

        // /shop - ร้านค้าโลก
        inv.setItem(11, GUIUtils.createItem(Material.EMERALD,
                "§a§l🏪 ร้านค้าโลก",
                "§7─────────────────",
                "§fซื้อขายไอเทมราคาคงที่",
                "§f8 หมวดหมู่ 200+ ชนิด",
                "§7─────────────────",
                "§aคลิกเพื่อใช้ §8(/shop)"));

        // /ah - Auction House
        inv.setItem(12, GUIUtils.createItem(Material.DIAMOND,
                "§b§l🏦 Auction House",
                "§7─────────────────",
                "§fซื้อขายกับผู้เล่นอื่น",
                "§fตั้งราคาเองได้",
                "§7─────────────────",
                "§aคลิกเพื่อใช้ §8(/ah)"));

        // /ahsell - ลงขายใน AH
        inv.setItem(13, GUIUtils.createItem(Material.GOLD_INGOT,
                "§6§l📋 ลงขายใน AH",
                "§7─────────────────",
                "§fถือไอเทมแล้วกด",
                "§fเพื่อลงขายในตลาด",
                "§7─────────────────",
                "§eต้องถือไอเทมก่อน!",
                "§aคลิกเพื่อใช้ §8(/ahsell)"));

        // /ah my - รายการของฉัน
        inv.setItem(14, GUIUtils.createItem(Material.BOOK,
                "§d§l📖 รายการของฉัน",
                "§7─────────────────",
                "§fดูไอเทมที่ลงขายอยู่",
                "§fยกเลิกรายการได้",
                "§7─────────────────",
                "§aคลิกเพื่อใช้"));

        // ปิด
        inv.setItem(16, GUIUtils.createItem(Material.BARRIER,
                "§c§lปิด",
                "§7ปิดเมนูนี้"));

        player.openInventory(inv);
    }

    // ไอเทม coin สำหรับใส่ใน GUI อื่น
    public static org.bukkit.inventory.ItemStack getCoinMenuItem() {
        return GUIUtils.createItem(Material.SUNFLOWER,
                "§6§l✦ เมนูตลาด ✦",
                "§7─────────────────",
                "§aคลิก §fเพื่อเปิดเมนูคำสั่ง",
                "§7ไม่ต้องพิมพ์คำสั่ง!");
    }
}
