package com.example.upgradetool.gui;

import com.example.upgradetool.UpgradeToolPlugin;
import com.example.upgradetool.enums.ItemCategory;
import com.example.upgradetool.enums.UpgradeType;
import com.example.upgradetool.managers.EconomyManager;
import com.example.upgradetool.managers.UpgradeManager;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class UpgradeGUIListener implements Listener {

    private final UpgradeToolPlugin plugin;
    private final UpgradeGUI gui;
    private final UpgradeManager manager;
    private final EconomyManager economy;

    public UpgradeGUIListener(UpgradeToolPlugin plugin) {
        this.plugin   = plugin;
        this.gui      = new UpgradeGUI(plugin);
        this.manager  = plugin.getUpgradeManager();
        this.economy  = plugin.getEconomyManager();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        event.setCancelled(true);

        Inventory inv = event.getInventory();
        int slot = event.getRawSlot();

        // Allow player to place/take their item in slot 13 only
        if (slot == UpgradeGUI.ITEM_SLOT) {
            handleItemSlot(event, player, inv);
            return;
        }

        // Prevent taking from non-item slots
        if (slot >= inv.getSize()) return; // clicked in player inventory — do nothing except allow item slot drag

        // Close button
        if (slot == UpgradeGUI.CLOSE_SLOT) {
            returnItemAndClose(player, inv);
            return;
        }

        // Upgrade buttons
        ItemStack currentItem = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (currentItem == null || currentItem.getType().isAir() || currentItem.getType() == Material.LIME_STAINED_GLASS_PANE) {
            player.sendMessage("§c❌ กรุณาวางอุปกรณ์ในช่องกลางก่อน!");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        UpgradeType type = getUpgradeTypeFromSlot(slot);
        if (type == null) return;

        // Compatibility check
        if (!manager.isCompatible(currentItem, type)) {
            ItemCategory needed = type.getCategory();
            ItemCategory has    = ItemCategory.fromMaterial(currentItem.getType());
            String hasName = has != null ? has.getDisplayName() : "§7ไม่รู้จัก";
            player.sendMessage("§c❌ ไม่สามารถ upgrade ได้!");
            player.sendMessage("§7อุปกรณ์ของคุณ: " + hasName);
            player.sendMessage("§7Upgrade นี้ต้องการ: " + needed.getDisplayName());
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        // Level check
        int current  = manager.getUpgradeLevel(currentItem, type);
        int maxLevel = manager.getMaxLevel(type);
        if (current >= maxLevel) {
            player.sendMessage("§6⭐ " + type.getDisplayName() + " §6อยู่ที่ระดับสูงสุดแล้ว!");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 1f);
            return;
        }

        // Cost check (money or EXP depending on Vault)
        if (!economy.canAfford(player, type, current)) {
            String costStr = economy.formatCost(type, current);
            String balStr  = economy.formatBalance(player);
            player.sendMessage("§c❌ เงินไม่พอ! ต้องการ §e" + costStr + " §cแต่มีแค่ §f" + balStr);
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        // Apply upgrade
        boolean success = manager.applyUpgrade(currentItem, type);
        if (success) {
            String costStr = economy.formatCost(type, current);
            economy.charge(player, type, current);

            player.sendMessage("§a✔ §lUpgrade สำเร็จ! §r§a" + type.getDisplayName()
                + " §aLv." + (current + 1)
                + " §8(§c-" + costStr + "§8) §7เหลือ: §f" + economy.formatBalance(player));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5f, 1.5f);

            // Update item in slot and refresh GUI
            inv.setItem(UpgradeGUI.ITEM_SLOT, currentItem);
            gui.refresh(inv, currentItem, player);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!isUpgradeGUI(event.getView().getTitle())) return;
        // Allow drag only if it only touches slot 13
        for (int slot : event.getRawSlots()) {
            if (slot != UpgradeGUI.ITEM_SLOT && slot < event.getInventory().getSize()) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        // Return the item in slot 13 to player
        Inventory inv = event.getInventory();
        ItemStack item = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (item != null && !item.getType().isAir() && item.getType() != Material.LIME_STAINED_GLASS_PANE) {
            // Drop or give back
            for (ItemStack leftover : player.getInventory().addItem(item).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
            inv.setItem(UpgradeGUI.ITEM_SLOT, null);
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────

    private void handleItemSlot(InventoryClickEvent event, Player player, Inventory inv) {
        event.setCancelled(false); // Allow click in item slot

        // After the click, schedule a refresh
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            ItemStack item = inv.getItem(UpgradeGUI.ITEM_SLOT);

            // If it's the glass placeholder, treat as empty
            if (item != null && item.getType() == Material.LIME_STAINED_GLASS_PANE) {
                gui.refresh(inv, null, player);
                return;
            }

            // Validate the placed item
            if (item != null && !item.getType().isAir()) {
                ItemCategory cat = ItemCategory.fromMaterial(item.getType());
                if (cat == null) {
                    // Not an upgradable item – return it
                    for (ItemStack lo : player.getInventory().addItem(item).values()) {
                        player.getWorld().dropItemNaturally(player.getLocation(), lo);
                    }
                    inv.setItem(UpgradeGUI.ITEM_SLOT, makeEmptySlot());
                    player.sendMessage("§c❌ ไม่สามารถ upgrade ไอเทมนี้ได้!");
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                    gui.refresh(inv, null, player);
                    return;
                }
            }
            gui.refresh(inv, item, player);
        });
    }

    private void returnItemAndClose(Player player, Inventory inv) {
        ItemStack item = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (item != null && !item.getType().isAir() && item.getType() != Material.LIME_STAINED_GLASS_PANE) {
            for (ItemStack lo : player.getInventory().addItem(item).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), lo);
            }
            inv.setItem(UpgradeGUI.ITEM_SLOT, null);
        }
        player.closeInventory();
    }

    private UpgradeType getUpgradeTypeFromSlot(int slot) {
        return switch (slot) {
            case UpgradeGUI.FAST_MINE_SLOT   -> UpgradeType.FAST_MINE;
            case UpgradeGUI.MINE_3X3_SLOT    -> UpgradeType.MINE_3X3;
            case UpgradeGUI.STRONG_ATK_SLOT  -> UpgradeType.STRONG_ATTACK;
            case UpgradeGUI.FAST_ATK_SLOT    -> UpgradeType.FAST_ATTACK;
            default -> null;
        };
    }

    private boolean isUpgradeGUI(String title) {
        return ChatColor.stripColor(title).equals(ChatColor.stripColor(UpgradeGUI.GUI_TITLE));
    }

    private ItemStack makeEmptySlot() {
        ItemStack g = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        var m = g.getItemMeta();
        m.setDisplayName("§a§lวางอุปกรณ์ที่นี่");
        m.setLore(java.util.List.of("§7ลากอุปกรณ์มาวางในช่องนี้"));
        g.setItemMeta(m);
        return g;
    }
}
