package com.example.upgradetool.gui;

import com.example.upgradetool.UpgradeToolPlugin;
import com.example.upgradetool.enums.ItemCategory;
import com.example.upgradetool.enums.UpgradeType;
import com.example.upgradetool.managers.EconomyManager;
import com.example.upgradetool.managers.UpgradeManager;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class UpgradeGUIListener implements Listener {

    private final UpgradeToolPlugin plugin;
    private final UpgradeGUI gui;
    private final UpgradeManager manager;
    private final EconomyManager economy;

    public UpgradeGUIListener(UpgradeToolPlugin plugin) {
        this.plugin  = plugin;
        this.gui     = new UpgradeGUI(plugin);
        this.manager = plugin.getUpgradeManager();
        this.economy = plugin.getEconomyManager();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CLICK
    // ─────────────────────────────────────────────────────────────────────────
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        // Always cancel first — we handle everything manually
        event.setCancelled(true);

        Inventory inv = event.getInventory();
        int rawSlot   = event.getRawSlot();
        InventoryAction action = event.getAction();

        // ── Shift-click FROM player inventory (bottom half) ───────────────────
        if (rawSlot >= inv.getSize() && action == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            handleShiftClickFromPlayer(event, player, inv);
            return;
        }

        // ── Clicked inside the GUI (top half) ────────────────────────────────
        if (rawSlot == UpgradeGUI.ITEM_SLOT) {
            handleItemSlotClick(event, player, inv);
            return;
        }

        if (rawSlot == UpgradeGUI.CLOSE_SLOT) {
            returnItemAndClose(player, inv);
            return;
        }

        // Clicked a GUI button (not item slot, not player inv)
        if (rawSlot < inv.getSize()) {
            handleUpgradeButtonClick(player, inv, rawSlot);
        }
        // clicks in player inv with no shift = ignore (item stays in place)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DRAG — block everything except a single-slot drag onto ITEM_SLOT
    // ─────────────────────────────────────────────────────────────────────────
    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        event.setCancelled(true);

        // Only act if the drag touches exactly slot 13 inside the GUI
        boolean touchesItemSlot = event.getRawSlots().contains(UpgradeGUI.ITEM_SLOT);
        boolean touchesOtherGuiSlots = event.getRawSlots().stream()
            .anyMatch(s -> s < event.getInventory().getSize() && s != UpgradeGUI.ITEM_SLOT);

        if (!touchesItemSlot || touchesOtherGuiSlots) return;

        // Manually place the dragged item
        ItemStack dragged = event.getOldCursor();
        if (dragged == null || dragged.getType().isAir()) return;

        ItemCategory cat = ItemCategory.fromMaterial(dragged.getType());
        if (cat == null) {
            player.sendMessage("§c❌ ไม่สามารถ upgrade ไอเทมนี้ได้!");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        placeIntoItemSlot(player, event.getInventory(), dragged.clone());
        // schedule cursor clear — cannot set cursor inside drag event reliably
        plugin.getServer().getScheduler().runTask(plugin, () ->
            player.setItemOnCursor(null));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CLOSE — always return item in slot 13
    // ─────────────────────────────────────────────────────────────────────────
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (!isUpgradeGUI(event.getView().getTitle())) return;

        Inventory inv = event.getInventory();
        ItemStack item = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (isRealItem(item)) {
            for (ItemStack lo : player.getInventory().addItem(item).values())
                player.getWorld().dropItemNaturally(player.getLocation(), lo);
            inv.setItem(UpgradeGUI.ITEM_SLOT, null);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Helpers
    // ═════════════════════════════════════════════════════════════════════════

    /** Shift-click from bottom inventory → move item to slot 13 */
    private void handleShiftClickFromPlayer(InventoryClickEvent event, Player player, Inventory inv) {
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return;

        ItemCategory cat = ItemCategory.fromMaterial(clicked.getType());
        if (cat == null) {
            player.sendMessage("§c❌ ไม่สามารถ upgrade ไอเทมนี้ได้!");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        // Return old item in slot 13 to player first
        ItemStack old = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (isRealItem(old)) {
            for (ItemStack lo : player.getInventory().addItem(old).values())
                player.getWorld().dropItemNaturally(player.getLocation(), lo);
        }

        inv.setItem(UpgradeGUI.ITEM_SLOT, clicked.clone());
        event.setCurrentItem(null);  // remove from player inv slot
        gui.refresh(inv, clicked, player);
    }

    /** Click on slot 13 itself — place cursor item or pick up slot item */
    private void handleItemSlotClick(InventoryClickEvent event, Player player, Inventory inv) {
        InventoryAction action = event.getAction();
        ItemStack cursor  = event.getCursor();
        ItemStack current = inv.getItem(UpgradeGUI.ITEM_SLOT);

        switch (action) {
            case PLACE_ALL, PLACE_ONE, PLACE_SOME, SWAP_WITH_CURSOR -> {
                if (cursor == null || cursor.getType().isAir()) return;
                ItemCategory cat = ItemCategory.fromMaterial(cursor.getType());
                if (cat == null) {
                    player.sendMessage("§c❌ ไม่สามารถ upgrade ไอเทมนี้ได้!");
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                    return;
                }
                // Schedule: set slot item then adjust cursor on next tick
                final ItemStack toPlace = cursor.clone();
                final ItemStack toReturn = isRealItem(current) ? current.clone() : null;
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    inv.setItem(UpgradeGUI.ITEM_SLOT, toPlace);
                    player.setItemOnCursor(toReturn != null ? toReturn : new ItemStack(Material.AIR));
                    gui.refresh(inv, toPlace, player);
                });
            }
            case PICKUP_ALL, PICKUP_ONE, PICKUP_SOME, PICKUP_HALF -> {
                if (!isRealItem(current)) return;
                final ItemStack toPickup = current.clone();
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    inv.setItem(UpgradeGUI.ITEM_SLOT, null);
                    player.setItemOnCursor(toPickup);
                    gui.refresh(inv, null, player);
                });
            }
            default -> {}
        }
    }

    /** Click on an upgrade button */
    private void handleUpgradeButtonClick(Player player, Inventory inv, int slot) {
        ItemStack currentItem = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (!isRealItem(currentItem)) {
            player.sendMessage("§c❌ กรุณาวางอุปกรณ์ในช่องกลางก่อน!");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        UpgradeType type = getUpgradeTypeFromSlot(slot);
        if (type == null) return;

        if (!manager.isCompatible(currentItem, type)) {
            ItemCategory needed = type.getCategory();
            ItemCategory has    = ItemCategory.fromMaterial(currentItem.getType());
            String hasName = has != null ? has.getDisplayName() : "§7ไม่รู้จัก";
            player.sendMessage("§c❌ ไม่สามารถ upgrade ได้! ต้องการ: " + needed.getDisplayName() + " §cแต่มี: " + hasName);
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        int current  = manager.getUpgradeLevel(currentItem, type);
        int maxLevel = manager.getMaxLevel(type);
        if (current >= maxLevel) {
            player.sendMessage("§6⭐ " + type.getDisplayName() + " §6อยู่ที่ระดับสูงสุดแล้ว!");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 1f);
            return;
        }

        if (!economy.canAfford(player, type, current)) {
            player.sendMessage("§c❌ เงินไม่พอ! ต้องการ §e" + economy.formatCost(type, current)
                + " §cแต่มีแค่ §f" + economy.formatBalance(player));
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }

        if (manager.applyUpgrade(currentItem, type)) {
            String cost = economy.formatCost(type, current);
            economy.charge(player, type, current);
            player.sendMessage("§a✔ §lUpgrade สำเร็จ! §r§a" + type.getDisplayName()
                + " §aLv." + (current + 1)
                + " §8(§c-" + cost + "§8) §7เหลือ: §f" + economy.formatBalance(player));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5f, 1.5f);
            inv.setItem(UpgradeGUI.ITEM_SLOT, currentItem);
            gui.refresh(inv, currentItem, player);
        }
    }

    /** Place an item into slot 13, returning any existing item to the player */
    private void placeIntoItemSlot(Player player, Inventory inv, ItemStack item) {
        ItemStack old = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (isRealItem(old)) {
            for (ItemStack lo : player.getInventory().addItem(old).values())
                player.getWorld().dropItemNaturally(player.getLocation(), lo);
        }
        inv.setItem(UpgradeGUI.ITEM_SLOT, item);
        gui.refresh(inv, item, player);
    }

    private void returnItemAndClose(Player player, Inventory inv) {
        ItemStack item = inv.getItem(UpgradeGUI.ITEM_SLOT);
        if (isRealItem(item)) {
            for (ItemStack lo : player.getInventory().addItem(item).values())
                player.getWorld().dropItemNaturally(player.getLocation(), lo);
            inv.setItem(UpgradeGUI.ITEM_SLOT, null);
        }
        player.closeInventory();
    }

    private UpgradeType getUpgradeTypeFromSlot(int slot) {
        return switch (slot) {
            case UpgradeGUI.FAST_MINE_SLOT  -> UpgradeType.FAST_MINE;
            case UpgradeGUI.MINE_3X3_SLOT   -> UpgradeType.MINE_3X3;
            case UpgradeGUI.STRONG_ATK_SLOT -> UpgradeType.STRONG_ATTACK;
            case UpgradeGUI.FAST_ATK_SLOT   -> UpgradeType.FAST_ATTACK;
            default -> null;
        };
    }

    private boolean isRealItem(ItemStack item) {
        return item != null && !item.getType().isAir()
            && item.getType() != Material.LIME_STAINED_GLASS_PANE;
    }

    private boolean isUpgradeGUI(String title) {
        return ChatColor.stripColor(title).equals(ChatColor.stripColor(UpgradeGUI.GUI_TITLE));
    }
}
