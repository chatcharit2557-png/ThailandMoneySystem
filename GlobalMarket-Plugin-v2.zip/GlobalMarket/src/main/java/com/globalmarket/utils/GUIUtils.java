package com.globalmarket.utils;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class GUIUtils {

    public static ItemStack createItem(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        if (lore.length > 0) {
            meta.setLore(Arrays.stream(lore)
                    .map(l -> ChatColor.translateAlternateColorCodes('&', l))
                    .collect(Collectors.toList()));
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack createGlassPane(String name) {
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            pane.setItemMeta(meta);
        }
        return pane;
    }

    public static ItemStack createNavButton(Material mat, String name, String... lore) {
        ItemStack item = createItem(mat, name, lore);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static ItemStack createShopDisplayItem(org.bukkit.inventory.ItemStack baseItem,
                                                   String displayName, double buyPrice, double sellPrice,
                                                   String currency) {
        ItemStack display = baseItem.clone();
        ItemMeta meta = display.getItemMeta();
        if (meta == null) return display;
        meta.setDisplayName("§e" + displayName);
        meta.setLore(Arrays.asList(
                "§7─────────────────",
                "§f ซื้อ: §a" + currency + String.format("%.2f", buyPrice),
                "§f ขาย: §c" + currency + String.format("%.2f", sellPrice),
                "§7─────────────────",
                "§eคลิกซ้าย §fซื้อ 1 ชิ้น",
                "§eShift+คลิกซ้าย §fซื้อ 64 ชิ้น",
                "§eคลิกขวา §fขาย 1 ชิ้น"
        ));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        display.setItemMeta(meta);
        return display;
    }

    public static ItemStack createAHListingItem(org.bukkit.inventory.ItemStack item,
                                                 String sellerName, double price,
                                                 String timeLeft, String currency) {
        ItemStack display = item.clone();
        ItemMeta meta = display.getItemMeta();
        if (meta == null) return display;

        String itemName = meta.hasDisplayName() ? meta.getDisplayName()
                : "§f" + item.getType().name().replace("_", " ");
        meta.setDisplayName(itemName);

        List<String> lore = new java.util.ArrayList<>();
        lore.add("§7─────────────────");
        lore.add("§f ผู้ขาย: §b" + sellerName);
        lore.add("§f ราคา: §6" + currency + String.format("%.2f", price));
        lore.add("§f หมดอายุใน: §e" + timeLeft);
        lore.add("§7─────────────────");
        lore.add("§aคลิก §fเพื่อซื้อ");
        meta.setLore(lore);
        display.setItemMeta(meta);
        return display;
    }

    public static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
