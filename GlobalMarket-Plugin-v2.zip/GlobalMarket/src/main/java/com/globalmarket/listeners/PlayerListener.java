package com.globalmarket.listeners;

import com.globalmarket.GlobalMarket;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener implements Listener {

    private final GlobalMarket plugin;

    public PlayerListener(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        // แสดง Sidebar
        if (plugin.getConfig().getBoolean("sidebar.enabled", true)
                && event.getPlayer().hasPermission("globalmarket.sidebar")) {
            plugin.getSidebarManager().updateSidebar(event.getPlayer());
        }
        // คืนไอเทมที่ค้างอยู่
        plugin.getDataManager().givePendingReturns(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        // ไม่ต้อง remove scoreboard เพราะจะ reset เอง
    }
}
