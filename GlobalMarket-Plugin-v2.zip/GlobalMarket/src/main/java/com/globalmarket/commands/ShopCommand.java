package com.globalmarket.commands;

import com.globalmarket.GlobalMarket;
import com.globalmarket.gui.ShopGUI;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShopCommand implements CommandExecutor {

    private final GlobalMarket plugin;

    public ShopCommand(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission("globalmarket.shop")) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        if (args.length > 0) {
            // เปิดหมวดหมู่โดยตรง
            String cat = args[0].toLowerCase();
            ShopGUI.openCategory(player, plugin, cat, 1);
        } else {
            ShopGUI.openMain(player, plugin);
        }

        return true;
    }
}
