package com.globalmarket.commands;

import com.globalmarket.GlobalMarket;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class AdminCommand implements CommandExecutor {

    private final GlobalMarket plugin;

    public AdminCommand(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("globalmarket.admin")) {
            sender.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload":
                plugin.reloadConfig();
                sender.sendMessage(GUIUtils.color("&8[&6Market&8] &aโหลด config ใหม่เรียบร้อย!"));
                break;

            case "sidebar":
                if (args.length < 2) { sender.sendMessage(GUIUtils.color("&eใช้: /gmarket sidebar <on|off>")); break; }
                boolean enable = args[1].equalsIgnoreCase("on");
                sender.sendMessage(GUIUtils.color("&8[&6Market&8] &aSidebar: " + (enable ? "&aเปิด" : "&cปิด")));
                break;

            case "listings":
                int count = plugin.getAuctionManager().getActiveLiistingCount();
                sender.sendMessage(GUIUtils.color("&8[&6Market&8] &fรายการ AH ที่ active: &e" + count));
                break;

            default:
                sendHelp(sender);
        }

        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(GUIUtils.color("&6&l=== GlobalMarket Admin ==="));
        sender.sendMessage(GUIUtils.color("&e/gmarket reload &7- โหลด config ใหม่"));
        sender.sendMessage(GUIUtils.color("&e/gmarket sidebar <on|off> &7- เปิด/ปิด sidebar"));
        sender.sendMessage(GUIUtils.color("&e/gmarket listings &7- ดูจำนวนรายการ AH"));
    }
}
