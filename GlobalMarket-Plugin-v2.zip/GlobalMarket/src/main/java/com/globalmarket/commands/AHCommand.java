package com.globalmarket.commands;

import com.globalmarket.GlobalMarket;
import com.globalmarket.gui.AuctionHouseGUI;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AHCommand implements CommandExecutor {

    private final GlobalMarket plugin;

    public AHCommand(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission("globalmarket.ah")) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        int page = 1;
        if (args.length > 0) {
            try { page = Integer.parseInt(args[0]); } catch (NumberFormatException ignored) {}
        }

        AuctionHouseGUI.open(player, plugin, page);
        return true;
    }
}
