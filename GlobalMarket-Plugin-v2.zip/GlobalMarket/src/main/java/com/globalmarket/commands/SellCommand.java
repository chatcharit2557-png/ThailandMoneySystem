package com.globalmarket.commands;

import com.globalmarket.GlobalMarket;
import com.globalmarket.gui.SellGUI;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SellCommand implements CommandExecutor {

    private final GlobalMarket plugin;

    public SellCommand(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission("globalmarket.sell")) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        SellGUI.open(player, plugin);
        return true;
    }
}
