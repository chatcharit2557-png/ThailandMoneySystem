package com.globalmarket.commands;

import com.globalmarket.GlobalMarket;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class AHSellCommand implements CommandExecutor {

    private final GlobalMarket plugin;

    public AHSellCommand(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission("globalmarket.ah")) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        if (args.length < 1) {
            player.sendMessage(GUIUtils.color("&8[&6Market&8] &eวิธีใช้: &f/ahsell <ราคา> [ชั่วโมง]"));
            return true;
        }

        ItemStack inHand = player.getInventory().getItemInMainHand();
        if (inHand.getType() == Material.AIR) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix")
                    + plugin.getConfig().getString("messages.no-item-in-hand")));
            return true;
        }

        double price;
        try {
            price = Double.parseDouble(args[0]);
        } catch (NumberFormatException e) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix")
                    + plugin.getConfig().getString("messages.invalid-price")));
            return true;
        }

        double minPrice = plugin.getConfig().getDouble("economy.min-price", 1.0);
        double maxPrice = plugin.getConfig().getDouble("economy.max-price", 999999999.0);
        if (price < minPrice || price > maxPrice) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix")
                    + "&cราคาต้องอยู่ระหว่าง &e" + minPrice + " &c- &e" + maxPrice));
            return true;
        }

        int maxListings = plugin.getConfig().getInt("auction-house.max-listings-per-player", 10);
        int defaultHours = plugin.getConfig().getInt("auction-house.default-duration-hours", 24);
        int maxHours = plugin.getConfig().getInt("auction-house.max-duration-hours", 168);

        long durationHours = defaultHours;
        if (args.length >= 2) {
            try {
                durationHours = Math.min(Long.parseLong(args[1]), maxHours);
            } catch (NumberFormatException ignored) {}
        }

        // ดึงไอเทมออกจากมือ
        ItemStack toSell = inHand.clone();
        player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));

        String listingId = plugin.getAuctionManager().createListing(player, toSell, price, durationHours);
        if (listingId == null) {
            // คืนไอเทม
            player.getInventory().addItem(toSell);
            String msg = plugin.getConfig().getString("messages.max-listings-reached", "")
                    .replace("%max%", String.valueOf(maxListings));
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix") + msg));
            return true;
        }

        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
        String itemName = toSell.getType().name().replace("_", " ");
        player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix")
                + "&aลงขาย &e" + itemName
                + " &araคา &6" + currency + String.format("%.2f", price)
                + " &a[&e" + durationHours + "ชม&a.] ID: &f#" + listingId));

        return true;
    }
}
