package com.globalmarket.gui;

import com.globalmarket.GlobalMarket;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class SellGUI {

    public static final String TITLE = "§6§l💰 วางของที่ต้องการขาย";

    // Slot 0-26 = ช่องวางของ (3 แถวแรก)
    // Slot 27-53 = แถบข้อมูล (3 แถวล่าง)
    public static final int[] SELL_SLOTS = generateSellSlots();
    public static final int INFO_SLOT = 40;
    public static final int TOTAL_SLOT = 49;

    private static int[] generateSellSlots() {
        int[] slots = new int[27];
        for (int i = 0; i < 27; i++) slots[i] = i;
        return slots;
    }

    public static void open(Player player, GlobalMarket plugin) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE);

        // แถวล่าง 3 แถว = ตกแต่ง
        for (int i = 27; i < 54; i++) {
            inv.setItem(i, GUIUtils.createGlassPane("§r"));
        }

        // ป้ายบอกช่องวางของ
        inv.setItem(INFO_SLOT, GUIUtils.createItem(Material.GOLD_INGOT,
                "§e§lวิธีใช้",
                "§71. §fวางของที่ต้องการขาย",
                "§7   §7ในช่องด้านบน",
                "§72. §fดูราคารวมด้านล่าง",
                "§73. §f§lปิดหน้าต่าง §fเพื่อขายทันที",
                "§7─────────────────",
                "§cปิดหน้าต่าง = ขายทันที!"));

        // ปุ่มแสดงราคารวม (เริ่มต้น 0)
        updatePriceDisplay(inv, plugin, 0, currency(plugin));

        // ปุ่มยกเลิก
        inv.setItem(45, GUIUtils.createItem(Material.BARRIER,
                "§c§lยกเลิก",
                "§7ของจะถูกคืนให้คุณ"));

        player.openInventory(inv);
    }

    public static void updatePriceDisplay(Inventory inv, GlobalMarket plugin,
                                           double total, String currency) {
        inv.setItem(TOTAL_SLOT, GUIUtils.createItem(Material.EMERALD,
                "§a§lราคารวม: §6" + currency + String.format("%.2f", total),
                "§7─────────────────",
                total > 0
                    ? "§a§lปิดหน้าต่าง §fเพื่อขาย!"
                    : "§7ยังไม่มีของที่ขายได้",
                total > 0
                    ? "§7หักภาษี " + (int)(plugin.getConfig()
                        .getDouble("economy.tax-rate", 0.05) * 100) + "%"
                    : ""));
    }

    public static double calculateTotal(Inventory inv, GlobalMarket plugin) {
        double total = 0;
        for (int slot : SELL_SLOTS) {
            ItemStack item = inv.getItem(slot);
            if (item == null || item.getType() == Material.AIR) continue;
            double price = plugin.getShopManager().getSellPrice(item.getType());
            if (price > 0) total += price * item.getAmount();
        }
        return total;
    }

    private static String currency(GlobalMarket plugin) {
        return plugin.getConfig().getString("economy.currency-symbol", "$");
    }
}
