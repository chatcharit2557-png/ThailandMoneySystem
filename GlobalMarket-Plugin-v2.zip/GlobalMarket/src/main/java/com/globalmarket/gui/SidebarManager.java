package com.globalmarket.gui;

import com.globalmarket.GlobalMarket;
import com.globalmarket.models.AuctionListing;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;
import org.bukkit.scheduler.BukkitTask;

import java.text.SimpleDateFormat;
import java.util.*;

public class SidebarManager {

    private final GlobalMarket plugin;
    private final Map<UUID, Scoreboard> playerBoards = new HashMap<>();
    private BukkitTask updateTask;

    // สำหรับ animation title
    private int animFrame = 0;
    private final String[] titleFrames = {
        "§6§l✦ §e§lตลาดโลก §6§l✦",
        "§e§l✦ §6§lตลาดโลก §e§l✦",
        "§6§l✧ §e§lตลาดโลก §6§l✧"
    };

    public SidebarManager(GlobalMarket plugin) {
        this.plugin = plugin;
        if (plugin.getConfig().getBoolean("sidebar.enabled", true)) {
            startUpdateTask();
        }
    }

    private void startUpdateTask() {
        int interval = plugin.getConfig().getInt("sidebar.update-interval", 20);
        updateTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            animFrame = (animFrame + 1) % titleFrames.length;
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.hasPermission("globalmarket.sidebar")) {
                    updateSidebar(player);
                }
            }
        }, interval, interval);
    }

    public void updateSidebar(Player player) {
        Scoreboard board = playerBoards.computeIfAbsent(player.getUniqueId(),
                k -> Bukkit.getScoreboardManager().getNewScoreboard());

        Objective obj = board.getObjective("gmarket");
        if (obj != null) obj.unregister();

        obj = board.registerNewObjective("gmarket", Criteria.DUMMY,
                titleFrames[animFrame]);
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        // รวบรวมข้อมูล
        List<AuctionListing> topListings = plugin.getAuctionManager().getActiveListings();
        int activeAH = topListings.size();
        double balance = plugin.getEconomy().getBalance(player);
        int playerListings = plugin.getAuctionManager().getPlayerListings(player.getUniqueId()).size();
        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");

        // เส้นแบ่ง (ใช้ spaces ต่างกันเพื่อ unique)
        int score = 15;

        // หัว
        setLine(obj, board, "§6§m──────────────", score--);
        setLine(obj, board, " §e§lMarket Info", score--);
        setLine(obj, board, "§6§m──────────────", score--);

        // เงินของผู้เล่น
        setLine(obj, board, " §fเงิน: §a" + currency + String.format("%.2f", balance), score--);
        setLine(obj, board, " §fรายการฉัน: §e" + playerListings, score--);
        setLine(obj, board, "§7§m──────────────", score--);

        // AH overview
        setLine(obj, board, " §b§lAuction House", score--);
        setLine(obj, board, " §fรายการทั้งหมด: §e" + activeAH, score--);
        setLine(obj, board, "§7§m──────────────", score--);

        // Top listings (สูงสุด 3 รายการ)
        setLine(obj, board, " §d§lรายการล่าสุด:", score--);
        int shown = 0;
        for (AuctionListing listing : topListings) {
            if (shown >= 3) break;
            String itemName = listing.getItem().getType().name().replace("_", " ");
            if (itemName.length() > 10) itemName = itemName.substring(0, 10) + "..";
            setLine(obj, board, " §7" + itemName + " §6" + currency + String.format("%.0f", listing.getPrice()), score--);
            shown++;
        }
        if (shown == 0) {
            setLine(obj, board, " §7ยังไม่มีรายการ", score--);
        }

        setLine(obj, board, "§6§m──────────────", score--);

        // เวลา
        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        setLine(obj, board, " §8" + time, score--);

        player.setScoreboard(board);
    }

    private void setLine(Objective obj, Scoreboard board, String text, int score) {
        // ป้องกัน duplicate entries
        Score s = obj.getScore(text);
        s.setScore(score);
    }

    public void removeSidebar(Player player) {
        Scoreboard blank = Bukkit.getScoreboardManager().getNewScoreboard();
        player.setScoreboard(blank);
        playerBoards.remove(player.getUniqueId());
    }

    public void cleanup() {
        if (updateTask != null) updateTask.cancel();
        for (Player player : Bukkit.getOnlinePlayers()) {
            removeSidebar(player);
        }
        playerBoards.clear();
    }
}
