package com.globalmarket.gui;

import com.globalmarket.GlobalMarket;
import com.globalmarket.models.ShopItem;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;
import java.util.Map;

public class ShopGUI {

    public static final String TITLE_PREFIX = "§a§lGlobal Shop";

    // หมวดหมู่และไอคอน
    private static final Object[][] CATEGORIES = {
        {"weapons",   Material.DIAMOND_SWORD,      "§c§lอาวุธ"},
        {"armor",     Material.DIAMOND_CHESTPLATE, "§9§lเกราะ"},
        {"tools",     Material.DIAMOND_PICKAXE,    "§6§lเครื่องมือ"},
        {"food",      Material.BREAD,              "§a§lอาหาร"},
        {"blocks",    Material.GRASS_BLOCK,        "§e§lบล็อก"},
        {"materials", Material.DIAMOND,            "§b§lวัตถุดิบ"},
        {"potions",   Material.POTION,             "§5§lยา"},
        {"misc",      Material.CHEST,              "§7§lอื่นๆ"},
    };

    public static void openMain(Player player, GlobalMarket plugin) {
        String title = TITLE_PREFIX + " §8│ §7หมวดหมู่";
        Inventory inv = Bukkit.createInventory(null, 54, title);

        // ตกแต่ง
        for (int i = 0; i < 54; i++) {
            if (i < 9 || i >= 45) inv.setItem(i, GUIUtils.createGlassPane("§r"));
        }

        // หัวข้อ
        inv.setItem(4, GUIUtils.createItem(Material.GOLD_BLOCK, "§6§l✦ Global Shop ✦",
                "§7ซื้อขายไอเทมราคาคงที่",
                "§7§m──────────────────",
                "§fเลือกหมวดหมู่ที่ต้องการ"));

        // ใส่หมวดหมู่
        int[] slots = {19, 20, 21, 22, 23, 24, 25, 28};
        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");

        for (int i = 0; i < CATEGORIES.length; i++) {
            String catId = (String) CATEGORIES[i][0];
            Material icon = (Material) CATEGORIES[i][1];
            String catName = (String) CATEGORIES[i][2];
            int count = plugin.getShopManager().getItemsByCategory(catId).size();

            inv.setItem(slots[i], GUIUtils.createNavButton(icon, catName,
                    "§7สินค้า: §e" + count + " ชนิด",
                    "§7─────────────────",
                    "§aคลิก §fเพื่อเปิด"));
        }

        // ปุ่มปิด
        inv.setItem(49, GUIUtils.createNavButton(Material.BARRIER, "§c§lปิด", "§7ปิดร้านค้า"));

        player.openInventory(inv);
    }

    public static void openCategory(Player player, GlobalMarket plugin, String categoryId, int page) {
        List<ShopItem> items = plugin.getShopManager().getItemsByCategory(categoryId);
        String catName = getCategoryName(categoryId);

        int itemsPerPage = 36;
        int totalPages = Math.max(1, (int) Math.ceil(items.size() / (double) itemsPerPage));
        page = Math.max(1, Math.min(page, totalPages));

        String title = TITLE_PREFIX + " §8│ " + catName + " §8│ §7" + page + "/" + totalPages;
        Inventory inv = Bukkit.createInventory(null, 54, title);

        // Bottom bar
        for (int i = 45; i < 54; i++) inv.setItem(i, GUIUtils.createGlassPane("§r"));

        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
        int start = (page - 1) * itemsPerPage;
        int slot = 9;

        for (int i = start; i < Math.min(start + itemsPerPage, items.size()); i++) {
            ShopItem shopItem = items.get(i);
            inv.setItem(slot++, GUIUtils.createShopDisplayItem(
                    new org.bukkit.inventory.ItemStack(shopItem.getMaterial()),
                    shopItem.getDisplayName(),
                    shopItem.getBuyPrice(),
                    shopItem.getSellPrice(),
                    currency
            ));
        }

        // Top row ตกแต่ง
        for (int i = 0; i < 9; i++) inv.setItem(i, GUIUtils.createGlassPane("§r"));
        inv.setItem(4, GUIUtils.createItem(Material.GOLD_BLOCK, catName,
                "§7สินค้า: §e" + items.size() + " ชนิด",
                "§7หน้า: §e" + page + "/" + totalPages));

        // Nav
        if (page > 1) inv.setItem(45, GUIUtils.createNavButton(Material.ARROW, "§e◀ ก่อนหน้า"));
        if (page < totalPages) inv.setItem(53, GUIUtils.createNavButton(Material.ARROW, "§eถัดไป ▶"));
        inv.setItem(48, GUIUtils.createNavButton(Material.ARROW, "§e◀ กลับ", "§7กลับไปหมวดหมู่"));
        inv.setItem(49, GUIUtils.createNavButton(Material.BARRIER, "§c§lปิด"));

        player.openInventory(inv);
    }

    private static String getCategoryName(String id) {
        for (Object[] cat : CATEGORIES) {
            if (cat[0].equals(id)) return (String) cat[2];
        }
        return "§7สินค้า";
    }
}
