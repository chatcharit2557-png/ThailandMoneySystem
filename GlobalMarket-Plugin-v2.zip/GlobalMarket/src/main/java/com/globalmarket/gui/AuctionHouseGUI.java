package com.globalmarket.gui;

import com.globalmarket.GlobalMarket;
import com.globalmarket.models.AuctionListing;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.List;

public class AuctionHouseGUI {

    public static final String TITLE_PREFIX = "§6§lAuction House";

    public static void open(Player player, GlobalMarket plugin, int page) {
        List<AuctionListing> listings = plugin.getAuctionManager().getActiveListings();
        int itemsPerPage = 45;
        int totalPages = Math.max(1, (int) Math.ceil(listings.size() / (double) itemsPerPage));
        page = Math.max(1, Math.min(page, totalPages));

        String title = TITLE_PREFIX + " §8│ §7หน้า " + page + "/" + totalPages;
        Inventory inv = Bukkit.createInventory(null, 54, title);

        // ใส่รายการ
        int start = (page - 1) * itemsPerPage;
        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");

        for (int i = start; i < Math.min(start + itemsPerPage, listings.size()); i++) {
            AuctionListing listing = listings.get(i);
            inv.setItem(i - start, GUIUtils.createAHListingItem(
                    listing.getItem(),
                    listing.getSellerName(),
                    listing.getPrice(),
                    listing.getFormattedTimeLeft(),
                    currency
            ));
        }

        // Bottom bar
        for (int i = 45; i < 54; i++) {
            inv.setItem(i, GUIUtils.createGlassPane("§r"));
        }

        // ปุ่มนำทาง
        if (page > 1) {
            inv.setItem(45, GUIUtils.createNavButton(Material.ARROW, "§e◀ หน้าก่อน",
                    "§7หน้า " + (page - 1) + "/" + totalPages));
        }
        if (page < totalPages) {
            inv.setItem(53, GUIUtils.createNavButton(Material.ARROW, "§eหน้าถัดไป ▶",
                    "§7หน้า " + (page + 1) + "/" + totalPages));
        }

        // ปุ่มรายการของฉัน
        inv.setItem(49, GUIUtils.createNavButton(Material.BOOK, "§b§lรายการของฉัน",
                "§7ดูไอเทมที่คุณลงขาย"));

        // ปุ่ม refresh
        inv.setItem(50, GUIUtils.createNavButton(Material.CLOCK, "§a§lรีเฟรช",
                "§7อัปเดตรายการล่าสุด"));

        // ปุ่มปิด
        inv.setItem(48, GUIUtils.createNavButton(Material.BARRIER, "§c§lปิด",
                "§7ปิดหน้าต่างนี้"));

        // แสดงจำนวนรายการ
        inv.setItem(4, GUIUtils.createItem(Material.GOLD_INGOT, "§6§lAuction House",
                "§7รายการทั้งหมด: §e" + listings.size(),
                "§7หน้า: §e" + page + " §7/ §e" + totalPages,
                "§7─────────────────",
                "§fซื้อขายไอเทมกับผู้เล่นอื่น"));

        player.openInventory(inv);
    }

    public static void openMyListings(Player player, GlobalMarket plugin) {
        List<AuctionListing> myListings = plugin.getAuctionManager()
                .getPlayerListings(player.getUniqueId());

        String title = "§b§lรายการของฉัน §8│ §7" + myListings.size() + " รายการ";
        Inventory inv = Bukkit.createInventory(null, 54, title);

        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");

        for (int i = 0; i < Math.min(myListings.size(), 45); i++) {
            AuctionListing listing = myListings.get(i);
            org.bukkit.inventory.ItemStack display = GUIUtils.createAHListingItem(
                    listing.getItem(), listing.getSellerName(),
                    listing.getPrice(), listing.getFormattedTimeLeft(), currency);
            // เพิ่ม lore ยกเลิก
            org.bukkit.inventory.meta.ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                java.util.List<String> lore = meta.getLore() != null ? meta.getLore() : new java.util.ArrayList<>();
                lore.add("§c§lคลิกขวา §cยกเลิกรายการ");
                meta.setLore(lore);
                display.setItemMeta(meta);
            }
            inv.setItem(i, display);
        }

        for (int i = 45; i < 54; i++) inv.setItem(i, GUIUtils.createGlassPane("§r"));
        inv.setItem(45, GUIUtils.createNavButton(Material.ARROW, "§e◀ กลับ", "§7กลับไป Auction House"));
        inv.setItem(49, GUIUtils.createItem(Material.BOOK, "§b§lรายการของฉัน",
                "§7รายการทั้งหมด: §e" + myListings.size(),
                "§7§m──────────────────",
                "§eคลิกขวา §7ที่ไอเทมเพื่อยกเลิก"));

        player.openInventory(inv);
    }
}
