package com.globalmarket.managers;

import com.globalmarket.GlobalMarket;
import com.globalmarket.models.ShopItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

public class ShopManager {

    private final GlobalMarket plugin;
    private final Map<String, ShopItem> shopItems = new LinkedHashMap<>();

    public ShopManager(GlobalMarket plugin) {
        this.plugin = plugin;
        loadDefaultItems();
    }

    private void loadDefaultItems() {
        // อาวุธ
        addItem("wood_sword", Material.WOODEN_SWORD, "ดาบไม้", "weapons", 50, 20, -1);
        addItem("stone_sword", Material.STONE_SWORD, "ดาบหิน", "weapons", 150, 60, -1);
        addItem("iron_sword", Material.IRON_SWORD, "ดาบเหล็ก", "weapons", 500, 200, -1);
        addItem("diamond_sword", Material.DIAMOND_SWORD, "ดาบเพชร", "weapons", 2000, 800, -1);
        addItem("bow", Material.BOW, "ธนู", "weapons", 300, 120, -1);
        addItem("arrow", Material.ARROW, "ลูกธนู", "weapons", 5, 2, -1);

        // เกราะ
        addItem("iron_helmet", Material.IRON_HELMET, "หมวกเหล็ก", "armor", 400, 160, -1);
        addItem("iron_chestplate", Material.IRON_CHESTPLATE, "เสื้อเกราะเหล็ก", "armor", 800, 320, -1);
        addItem("iron_leggings", Material.IRON_LEGGINGS, "กางเกงเหล็ก", "armor", 700, 280, -1);
        addItem("iron_boots", Material.IRON_BOOTS, "รองเท้าเหล็ก", "armor", 400, 160, -1);
        addItem("diamond_helmet", Material.DIAMOND_HELMET, "หมวกเพชร", "armor", 1800, 720, -1);
        addItem("diamond_chestplate", Material.DIAMOND_CHESTPLATE, "เสื้อเกราะเพชร", "armor", 3600, 1440, -1);

        // เครื่องมือ
        addItem("iron_pickaxe", Material.IRON_PICKAXE, "จอบเหล็ก", "tools", 600, 240, -1);
        addItem("diamond_pickaxe", Material.DIAMOND_PICKAXE, "จอบเพชร", "tools", 2500, 1000, -1);
        addItem("iron_axe", Material.IRON_AXE, "ขวานเหล็ก", "tools", 600, 240, -1);
        addItem("iron_shovel", Material.IRON_SHOVEL, "พลั่วเหล็ก", "tools", 400, 160, -1);

        // อาหาร
        addItem("bread", Material.BREAD, "ขนมปัง", "food", 20, 8, -1);
        addItem("cooked_beef", Material.COOKED_BEEF, "เนื้อวัวปิ้ง", "food", 40, 16, -1);
        addItem("cooked_chicken", Material.COOKED_CHICKEN, "ไก่ปิ้ง", "food", 30, 12, -1);
        addItem("golden_apple", Material.GOLDEN_APPLE, "แอปเปิ้ลทอง", "food", 500, 200, -1);

        // บล็อก
        addItem("stone", Material.STONE, "หิน", "blocks", 2, 1, -1);
        addItem("wood", Material.OAK_PLANKS, "ไม้กระดาน", "blocks", 3, 1, -1);
        addItem("glass", Material.GLASS, "กระจก", "blocks", 10, 4, -1);
        addItem("obsidian", Material.OBSIDIAN, "หินออบซิเดียน", "blocks", 50, 20, -1);

        // วัตถุดิบ
        addItem("iron_ingot", Material.IRON_INGOT, "เหล็กแท่ง", "materials", 80, 32, -1);
        addItem("gold_ingot", Material.GOLD_INGOT, "ทองแท่ง", "materials", 150, 60, -1);
        addItem("diamond", Material.DIAMOND, "เพชร", "materials", 500, 200, -1);
        addItem("emerald", Material.EMERALD, "มรกต", "materials", 400, 160, -1);
        addItem("netherite_ingot", Material.NETHERITE_INGOT, "เนเธอไรท์แท่ง", "materials", 5000, 2000, -1);

        // ยา
        addItem("potion_healing", Material.POTION, "ยารักษา", "potions", 100, 40, -1);
        addItem("potion_speed", Material.POTION, "ยาเร็ว", "potions", 80, 32, -1);
    }

    private void addItem(String id, Material mat, String name, String category,
                         double buy, double sell, int stock) {
        shopItems.put(id, new ShopItem(id, mat, name, category, buy, sell, stock));
    }

    public List<ShopItem> getItemsByCategory(String category) {
        return shopItems.values().stream()
                .filter(i -> i.getCategory().equals(category) && i.isEnabled())
                .collect(Collectors.toList());
    }

    public List<ShopItem> getAllItems() {
        return new ArrayList<>(shopItems.values());
    }

    public ShopItem getItem(String id) {
        return shopItems.get(id);
    }

    public boolean buyItem(Player player, ShopItem item, int amount) {
        double totalPrice = item.getBuyPrice() * amount;
        if (!plugin.getEconomyManager().hasEnough(player, totalPrice)) return false;
        if (!item.isUnlimitedStock() && item.getStock() < amount) return false;

        plugin.getEconomyManager().withdraw(player, totalPrice);
        player.getInventory().addItem(new ItemStack(item.getMaterial(), amount));
        if (!item.isUnlimitedStock()) item.setStock(item.getStock() - amount);

        return true;
    }

    public double sellItemToShop(Player player, ItemStack itemStack) {
        ShopItem shopItem = shopItems.values().stream()
                .filter(i -> i.getMaterial() == itemStack.getType() && i.isEnabled())
                .findFirst().orElse(null);

        if (shopItem == null || shopItem.getSellPrice() <= 0) return -1;

        double totalEarned = shopItem.getSellPrice() * itemStack.getAmount();
        double tax = totalEarned * plugin.getConfig().getDouble("economy.tax-rate", 0.05);
        double netEarned = totalEarned - tax;

        player.getInventory().remove(itemStack);
        plugin.getEconomy().depositPlayer(player, netEarned);

        return netEarned;
    }

    public double getSellPrice(Material material) {
        return shopItems.values().stream()
                .filter(i -> i.getMaterial() == material)
                .mapToDouble(ShopItem::getSellPrice)
                .findFirst()
                .orElse(-1);
    }
}
