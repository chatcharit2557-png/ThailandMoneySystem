package com.globalmarket.managers;

import com.globalmarket.GlobalMarket;
import com.globalmarket.models.AuctionListing;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.stream.Collectors;

public class AuctionManager {

    private final GlobalMarket plugin;
    private final Map<String, AuctionListing> listings = new LinkedHashMap<>();
    private BukkitTask expireTask;

    public AuctionManager(GlobalMarket plugin) {
        this.plugin = plugin;
        startExpireTask();
    }

    private void startExpireTask() {
        expireTask = Bukkit.getScheduler().runTaskTimer(plugin, this::checkExpired, 200L, 200L); // ทุก 10 วินาที
    }

    private void checkExpired() {
        List<AuctionListing> toExpire = listings.values().stream()
                .filter(l -> !l.isSold() && !l.isExpired() && l.getRemainingMillis() <= 0)
                .collect(Collectors.toList());

        for (AuctionListing listing : toExpire) {
            listing.setExpired(true);
            // คืนไอเทมให้ผู้ขาย
            returnItemToSeller(listing);
        }
    }

    private void returnItemToSeller(AuctionListing listing) {
        Player online = Bukkit.getPlayer(listing.getSellerUUID());
        if (online != null) {
            online.getInventory().addItem(listing.getItem());
            online.sendMessage(plugin.getConfig().getString("messages.prefix", "§8[§6Market§8] §r")
                    + "§eรายการขาย §6" + listing.getId() + " §eหมดอายุแล้ว ไอเทมถูกคืนให้คุณ");
        } else {
            plugin.getDataManager().addPendingReturn(listing.getSellerUUID(), listing.getItem());
        }
    }

    public String createListing(Player seller, ItemStack item, double price, long durationHours) {
        int maxListings = plugin.getConfig().getInt("auction-house.max-listings-per-player", 10);
        long playerListings = listings.values().stream()
                .filter(l -> l.getSellerUUID().equals(seller.getUniqueId()) && !l.isSold() && !l.isExpired())
                .count();

        if (playerListings >= maxListings) return null;

        long durationMillis = durationHours * 3_600_000L;
        AuctionListing listing = new AuctionListing(
                seller.getUniqueId(), seller.getName(), item, price, durationMillis);
        listings.put(listing.getId(), listing);
        return listing.getId();
    }

    public boolean buyListing(Player buyer, String listingId) {
        AuctionListing listing = listings.get(listingId);
        if (listing == null || listing.isSold() || listing.isExpired()) return false;
        if (listing.getSellerUUID().equals(buyer.getUniqueId())) return false;

        double price = listing.getPrice();
        if (!plugin.getEconomyManager().hasEnough(buyer, price)) return false;

        double tax = price * plugin.getConfig().getDouble("economy.tax-rate", 0.05);
        double sellerReceives = price - tax;

        plugin.getEconomyManager().withdraw(buyer, price);
        OfflinePlayer seller = Bukkit.getOfflinePlayer(listing.getSellerUUID());
        plugin.getEconomy().depositPlayer(seller, sellerReceives);

        listing.setSold(true);
        buyer.getInventory().addItem(listing.getItem());

        // แจ้งผู้ขาย
        Player onlineSeller = Bukkit.getPlayer(listing.getSellerUUID());
        if (onlineSeller != null) {
            String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
            onlineSeller.sendMessage(plugin.getConfig().getString("messages.prefix", "§8[§6Market§8] §r")
                    + "§a" + buyer.getName() + " ซื้อ §e" + listing.getItem().getType().name()
                    + " §aของคุณ ได้รับ §6" + String.format("%.2f", sellerReceives) + currency);
        }

        return true;
    }

    public List<AuctionListing> getActiveListings() {
        return listings.values().stream()
                .filter(l -> !l.isSold() && !l.isExpired())
                .sorted(Comparator.comparingLong(AuctionListing::getListedTime).reversed())
                .collect(Collectors.toList());
    }

    public List<AuctionListing> getPlayerListings(UUID playerUUID) {
        return listings.values().stream()
                .filter(l -> l.getSellerUUID().equals(playerUUID) && !l.isSold() && !l.isExpired())
                .collect(Collectors.toList());
    }

    public AuctionListing getListing(String id) {
        return listings.get(id);
    }

    public boolean cancelListing(Player player, String listingId) {
        AuctionListing listing = listings.get(listingId);
        if (listing == null) return false;
        if (!listing.getSellerUUID().equals(player.getUniqueId())
                && !player.hasPermission("globalmarket.admin")) return false;

        listing.setExpired(true);
        player.getInventory().addItem(listing.getItem());
        return true;
    }

    public void saveAll() {
        // ใน production จะ save ไป YML หรือ SQLite
        plugin.getLogger().info("บันทึกข้อมูล Auction House...");
    }

    public int getActiveLiistingCount() {
        return (int) listings.values().stream().filter(l -> !l.isSold() && !l.isExpired()).count();
    }
}
