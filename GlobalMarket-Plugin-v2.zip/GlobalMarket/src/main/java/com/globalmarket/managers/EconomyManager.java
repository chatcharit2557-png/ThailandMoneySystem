package com.globalmarket.managers;

import com.globalmarket.GlobalMarket;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;

public class EconomyManager {

    private final GlobalMarket plugin;
    private final Economy economy;

    public EconomyManager(GlobalMarket plugin, Economy economy) {
        this.plugin = plugin;
        this.economy = economy;
    }

    public double getBalance(Player player) {
        return economy.getBalance(player);
    }

    public boolean hasEnough(Player player, double amount) {
        return economy.getBalance(player) >= amount;
    }

    public boolean withdraw(Player player, double amount) {
        if (!hasEnough(player, amount)) return false;
        economy.withdrawPlayer(player, amount);
        return true;
    }

    public boolean deposit(Player player, double amount) {
        economy.depositPlayer(player, amount);
        return true;
    }

    public String format(double amount) {
        String symbol = plugin.getConfig().getString("economy.currency-symbol", "$");
        return symbol + String.format("%.2f", amount);
    }
}
