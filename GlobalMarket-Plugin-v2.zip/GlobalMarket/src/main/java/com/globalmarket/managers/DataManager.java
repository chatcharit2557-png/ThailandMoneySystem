package com.globalmarket.managers;

import com.globalmarket.GlobalMarket;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class DataManager {

    private final GlobalMarket plugin;
    // คิวไอเทมที่ต้องคืนให้ผู้เล่นเมื่อ login
    private final Map<UUID, List<ItemStack>> pendingReturns = new HashMap<>();

    public DataManager(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    public void addPendingReturn(UUID playerUUID, ItemStack item) {
        pendingReturns.computeIfAbsent(playerUUID, k -> new ArrayList<>()).add(item.clone());
    }

    public List<ItemStack> getPendingReturns(UUID playerUUID) {
        return pendingReturns.getOrDefault(playerUUID, Collections.emptyList());
    }

    public void clearPendingReturns(UUID playerUUID) {
        pendingReturns.remove(playerUUID);
    }

    public void givePendingReturns(Player player) {
        List<ItemStack> items = getPendingReturns(player.getUniqueId());
        if (items.isEmpty()) return;

        for (ItemStack item : items) {
            player.getInventory().addItem(item);
        }
        clearPendingReturns(player.getUniqueId());
        player.sendMessage(plugin.getConfig().getString("messages.prefix", "§8[§6Market§8] §r")
                + "§aคุณได้รับไอเทมที่ค้างไว้ §e" + items.size() + " §aชิ้น");
    }

    public void saveAll() {
        plugin.getLogger().info("บันทึกข้อมูล DataManager...");
    }
}
