package com.globalmarket.models;

import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class AuctionListing {
    private final String id;
    private final UUID sellerUUID;
    private final String sellerName;
    private final ItemStack item;
    private final double price;
    private final long listedTime;
    private final long expiryTime;
    private boolean sold;
    private boolean expired;

    public AuctionListing(UUID sellerUUID, String sellerName, ItemStack item,
                          double price, long durationMillis) {
        this.id = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.sellerUUID = sellerUUID;
        this.sellerName = sellerName;
        this.item = item.clone();
        this.price = price;
        this.listedTime = System.currentTimeMillis();
        this.expiryTime = listedTime + durationMillis;
        this.sold = false;
        this.expired = false;
    }

    // Constructor for loading from storage
    public AuctionListing(String id, UUID sellerUUID, String sellerName, ItemStack item,
                          double price, long listedTime, long expiryTime, boolean sold, boolean expired) {
        this.id = id;
        this.sellerUUID = sellerUUID;
        this.sellerName = sellerName;
        this.item = item;
        this.price = price;
        this.listedTime = listedTime;
        this.expiryTime = expiryTime;
        this.sold = sold;
        this.expired = expired;
    }

    public boolean isExpired() {
        return expired || System.currentTimeMillis() > expiryTime;
    }

    public long getRemainingMillis() {
        return Math.max(0, expiryTime - System.currentTimeMillis());
    }

    public String getFormattedTimeLeft() {
        long millis = getRemainingMillis();
        if (millis <= 0) return "หมดอายุ";
        long hours = millis / 3_600_000;
        long minutes = (millis % 3_600_000) / 60_000;
        if (hours > 0) return hours + "ชม. " + minutes + "นาที";
        return minutes + "นาที";
    }

    // Getters
    public String getId() { return id; }
    public UUID getSellerUUID() { return sellerUUID; }
    public String getSellerName() { return sellerName; }
    public ItemStack getItem() { return item.clone(); }
    public double getPrice() { return price; }
    public long getListedTime() { return listedTime; }
    public long getExpiryTime() { return expiryTime; }
    public boolean isSold() { return sold; }
    public void setSold(boolean sold) { this.sold = sold; }
    public void setExpired(boolean expired) { this.expired = expired; }
}
