package com.globalmarket.models;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class ShopItem {
    private final String id;
    private final Material material;
    private final String displayName;
    private final String category;
    private double buyPrice;    // ราคาที่ผู้เล่นซื้อจากร้าน
    private double sellPrice;   // ราคาที่ร้านรับซื้อจากผู้เล่น
    private int stock;          // -1 = ไม่จำกัด
    private boolean enabled;

    public ShopItem(String id, Material material, String displayName, String category,
                    double buyPrice, double sellPrice, int stock) {
        this.id = id;
        this.material = material;
        this.displayName = displayName;
        this.category = category;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
        this.stock = stock;
        this.enabled = true;
    }

    public ItemStack toItemStack(int amount) {
        return new ItemStack(material, Math.max(1, amount));
    }

    // Getters & Setters
    public String getId() { return id; }
    public Material getMaterial() { return material; }
    public String getDisplayName() { return displayName; }
    public String getCategory() { return category; }
    public double getBuyPrice() { return buyPrice; }
    public void setBuyPrice(double buyPrice) { this.buyPrice = buyPrice; }
    public double getSellPrice() { return sellPrice; }
    public void setSellPrice(double sellPrice) { this.sellPrice = sellPrice; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public boolean isUnlimitedStock() { return stock == -1; }
}
