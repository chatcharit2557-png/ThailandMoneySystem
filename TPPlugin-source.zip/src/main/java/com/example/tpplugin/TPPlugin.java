package com.example.tpplugin;

import org.bukkit.plugin.java.JavaPlugin;

public class TPPlugin extends JavaPlugin {

    private TpaManager tpaManager;

    @Override
    public void onEnable() {
        tpaManager = new TpaManager(this);

        RtpCommand rtpCommand = new RtpCommand(this);
        getCommand("rtp").setExecutor(rtpCommand);
        getServer().getPluginManager().registerEvents(new RtpGuiListener(this, rtpCommand), this);
        getCommand("tpa").setExecutor(new TpaCommand(this, tpaManager));
        getCommand("tpaccept").setExecutor(new TpAcceptCommand(this, tpaManager));
        getCommand("tpdeny").setExecutor(new TpDenyCommand(this, tpaManager));

        getLogger().info("TPPlugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("TPPlugin disabled!");
    }

    public TpaManager getTpaManager() {
        return tpaManager;
    }
}
