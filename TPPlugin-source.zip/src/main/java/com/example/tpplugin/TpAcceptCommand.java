package com.example.tpplugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class TpAcceptCommand implements CommandExecutor {

    private final TPPlugin plugin;
    private final TpaManager tpaManager;

    public TpAcceptCommand(TPPlugin plugin, TpaManager tpaManager) {
        this.plugin = plugin;
        this.tpaManager = tpaManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player target)) {
            sender.sendMessage("§cคำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น");
            return true;
        }

        UUID targetId = target.getUniqueId();

        if (!tpaManager.hasRequest(targetId)) {
            target.sendMessage("§cคุณไม่มีคำขอ TP ที่รออยู่");
            return true;
        }

        UUID requesterId = tpaManager.getRequester(targetId);
        Player requester = plugin.getServer().getPlayer(requesterId);

        tpaManager.cancelRequest(targetId);

        if (requester == null || !requester.isOnline()) {
            target.sendMessage("§cผู้เล่นที่ส่งคำขอออฟไลน์ไปแล้ว");
            return true;
        }

        requester.teleport(target.getLocation());
        target.sendMessage("§aคุณอนุญาตให้ §e" + requester.getName() + " §aTPมาหาคุณแล้ว");
        requester.sendMessage("§a" + target.getName() + " §aอนุญาตแล้ว! Teleport สำเร็จ §7→ §e" +
                target.getName() + "§7's location");

        return true;
    }
}
