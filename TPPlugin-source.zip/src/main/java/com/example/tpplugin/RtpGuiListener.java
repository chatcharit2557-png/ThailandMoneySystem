package com.example.tpplugin;

import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class RtpGuiListener implements Listener {

    private final TPPlugin plugin;
    private final RtpCommand rtpCommand;

    public RtpGuiListener(TPPlugin plugin, RtpCommand rtpCommand) {
        this.plugin = plugin;
        this.rtpCommand = rtpCommand;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!RtpCommand.GUI_TITLE.equals(event.getView().getTitle())) return;

        event.setCancelled(true); // ป้องกันเอาไอเทมออก

        if (event.getCurrentItem() == null) return;

        World.Environment env = switch (event.getSlot()) {
            case 1 -> World.Environment.NORMAL;
            case 2 -> World.Environment.NETHER;
            case 3 -> World.Environment.THE_END;
            default -> null;
        };

        if (env == null) return;

        player.closeInventory();
        rtpCommand.teleportToWorld(player, env);
    }
}
