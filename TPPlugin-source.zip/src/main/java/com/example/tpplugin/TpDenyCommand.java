package com.example.tpplugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class TpDenyCommand implements CommandExecutor {

    private final TPPlugin plugin;
    private final TpaManager tpaManager;

    public TpDenyCommand(TPPlugin plugin, TpaManager tpaManager) {
        this.plugin = plugin;
        this.tpaManager = tpaManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player target)) {
            sender.sendMessage("§cคำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น");
            return true;
        }

        UUID targetId = target.getUniqueId();

        if (!tpaManager.hasRequest(targetId)) {
            target.sendMessage("§cคุณไม่มีคำขอ TP ที่รออยู่");
            return true;
        }

        UUID requesterId = tpaManager.getRequester(targetId);
        Player requester = plugin.getServer().getPlayer(requesterId);

        tpaManager.cancelRequest(targetId);

        target.sendMessage("§cคุณปฏิเสธคำขอ TP แล้ว");

        if (requester != null && requester.isOnline()) {
            requester.sendMessage("§c" + target.getName() + " §cปฏิเสธคำขอ TP ของคุณ");
        }

        return true;
    }
}
