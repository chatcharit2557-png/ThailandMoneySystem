package com.example.tpplugin;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Random;

public class RtpCommand implements CommandExecutor {

    private final TPPlugin plugin;
    private final Random random = new Random();

    private static final int MAX_ATTEMPTS = 15;
    // Buffer (blocks) ห่างจากขอบกำแพงโลก เพื่อความปลอดภัย
    private static final double BORDER_BUFFER = 100.0;
    // ระยะขั้นต่ำจากจุดศูนย์กลาง เพื่อไม่ให้ TP มาใกล้สพอว์น
    private static final int RTP_MIN = 500;

    public static final String GUI_TITLE = "§8§l[ §6เลือกมิติ §8§l]";

    public RtpCommand(TPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cคำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น");
            return true;
        }
        if (!player.hasPermission("tpplugin.rtp")) {
            player.sendMessage("§cคุณไม่มีสิทธิ์ใช้คำสั่งนี้");
            return true;
        }
        openDimensionGui(player);
        return true;
    }

    // ─── GUI ─────────────────────────────────────────────────────────────────

    private void openDimensionGui(Player player) {
        Inventory gui = plugin.getServer().createInventory(null, 9, GUI_TITLE);

        gui.setItem(2, makeItem(Material.GRASS_BLOCK, "§a§lโลกปกติ",  "§7สุ่ม TP ในโลกปกติ"));
        gui.setItem(4, makeItem(Material.NETHERRACK,  "§c§lเนเทอร์",   "§7สุ่ม TP ในเนเทอร์"));
        gui.setItem(6, makeItem(Material.END_STONE,   "§e§lดิ เอนด์",  "§7สุ่ม TP ในดิ เอนด์"));

        player.openInventory(gui);
    }

    private ItemStack makeItem(Material mat, String name, String lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(List.of(lore));
        item.setItemMeta(meta);
        return item;
    }

    // ─── Teleport ─────────────────────────────────────────────────────────────

    public void teleportToWorld(Player player, World.Environment env) {
        try {
            World world = null;
            for (World w : plugin.getServer().getWorlds()) {
                if (w.getEnvironment() == env) { world = w; break; }
            }

            if (world == null) {
                player.sendMessage("§cไม่พบมิติ §e" + getWorldName(env) + " §cในเซิร์ฟเวอร์");
                return;
            }

            // คำนวณขอบเขตที่ปลอดภัยจาก WorldBorder
            WorldBorder border = world.getWorldBorder();
            double borderRadius = (border.getSize() / 2.0) - BORDER_BUFFER;
            double centerX = border.getCenter().getX();
            double centerZ = border.getCenter().getZ();

            // ตรวจว่า border ใหญ่พอสำหรับ RTP_MIN
            if (borderRadius < RTP_MIN) {
                player.sendMessage("§cกำแพงโลกเล็กเกินไปสำหรับ RTP (ขนาด: §e" +
                        (int) border.getSize() + "§c บล็อก)");
                return;
            }

            player.sendMessage("§aกำลังหาพิกัดสุ่มใน §e" + getWorldName(env) +
                    " §7(ขอบเขตปลอดภัย: §e" + (int) borderRadius + " §7บล็อก)§a...");

            final World targetWorld = world;
            final double safeRadius = borderRadius;

            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    Location safeLoc = findSafeLocation(targetWorld, env, centerX, centerZ, safeRadius);

                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (safeLoc == null) {
                            player.sendMessage("§cไม่สามารถหาพิกัดที่ปลอดภัยได้ กรุณาลองใหม่");
                            return;
                        }
                        try {
                            player.teleport(safeLoc);
                            player.sendMessage("§aTP สำเร็จ! §7พิกัด: §e" +
                                    safeLoc.getBlockX() + ", " +
                                    safeLoc.getBlockY() + ", " +
                                    safeLoc.getBlockZ());
                        } catch (Exception e) {
                            plugin.getLogger().severe("Teleport failed: " + e.getMessage());
                            player.sendMessage("§cเกิดข้อผิดพลาดขณะ TP กรุณาลองใหม่");
                        }
                    });
                } catch (Exception e) {
                    plugin.getLogger().severe("RTP async error: " + e.getMessage());
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            player.sendMessage("§cเกิดข้อผิดพลาด: " + e.getMessage()));
                }
            });

        } catch (Exception e) {
            plugin.getLogger().severe("RTP command error: " + e.getMessage());
            player.sendMessage("§cเกิดข้อผิดพลาด กรุณาแจ้งแอดมิน");
        }
    }

    // ─── Location Finder ──────────────────────────────────────────────────────

    /**
     * หาพิกัดปลอดภัยภายใน border ที่กำหนด
     * centerX/centerZ คือจุดศูนย์กลางของ WorldBorder
     * safeRadius คือรัศมีสูงสุดที่ปลอดภัย (หัก buffer แล้ว)
     */
    private Location findSafeLocation(World world, World.Environment env,
                                       double centerX, double centerZ, double safeRadius) {
        for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
            // สุ่มพิกัดในช่วง [RTP_MIN, safeRadius] รอบ center
            double range = safeRadius - RTP_MIN;
            double offset = RTP_MIN + random.nextDouble() * range;
            double angle  = random.nextDouble() * 2 * Math.PI;

            int x = (int) (centerX + Math.cos(angle) * offset);
            int z = (int) (centerZ + Math.sin(angle) * offset);

            // โหลด chunk ก่อนอ่าน Y
            Chunk chunk = world.getChunkAt(x >> 4, z >> 4);
            if (!chunk.isLoaded()) chunk.load();

            int y;
            if (env == World.Environment.NETHER) {
                y = findNetherY(world, x, z);
            } else {
                y = world.getHighestBlockYAt(x, z);
            }

            if (y <= world.getMinHeight() || y >= world.getMaxHeight() - 1) continue;

            Location loc = new Location(world, x + 0.5, y + 1, z + 0.5);

            // ตรวจอีกครั้งว่าพิกัดนี้อยู่ใน border จริง
            if (!world.getWorldBorder().isInside(loc)) continue;

            if (isSafe(loc)) return loc;
        }
        return null;
    }

    private int findNetherY(World world, int x, int z) {
        for (int y = 32; y < 120; y++) {
            Location feet = new Location(world, x, y, z);
            Location head = new Location(world, x, y + 1, z);
            Location ground = new Location(world, x, y - 1, z);
            if (world.getBlockAt(ground).getType().isSolid()
                    && world.getBlockAt(feet).getType().isAir()
                    && world.getBlockAt(head).getType().isAir()) {
                return y - 1;
            }
        }
        return -1;
    }

    private boolean isSafe(Location loc) {
        World world = loc.getWorld();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        Material ground = world.getBlockAt(x, y - 1, z).getType();
        Material feet   = world.getBlockAt(x, y,     z).getType();
        Material head   = world.getBlockAt(x, y + 1, z).getType();

        return ground.isSolid()
                && ground != Material.LAVA
                && ground != Material.MAGMA_BLOCK
                && feet.isAir()
                && head.isAir()
                && y > world.getMinHeight()
                && y < world.getMaxHeight() - 1;
    }

    private String getWorldName(World.Environment env) {
        return switch (env) {
            case NORMAL   -> "โลกปกติ";
            case NETHER   -> "เนเทอร์";
            case THE_END  -> "ดิ เอนด์";
            default       -> "ไม่รู้จัก";
        };
    }
}
