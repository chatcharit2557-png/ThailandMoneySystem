package com.example.tpplugin;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.Random;

public class RtpCommand implements CommandExecutor {

    private final TPPlugin plugin;
    private final Random random = new Random();

    private static final int RTP_RADIUS = 5000;
    private static final int RTP_MIN = 500;
    private static final int MAX_ATTEMPTS = 10;

    public static final String GUI_TITLE = "§8§l[ §6เลือกมิติ §8§l]";

    public RtpCommand(TPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cคำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น");
            return true;
        }

        if (!player.hasPermission("tpplugin.rtp")) {
            player.sendMessage("§cคุณไม่มีสิทธิ์ใช้คำสั่งนี้");
            return true;
        }

        openDimensionGui(player);
        return true;
    }

    private void openDimensionGui(Player player) {
        // Hopper inventory = 5 slots
        Inventory gui = plugin.getServer().createInventory(null, 5, GUI_TITLE);

        // Slot 1: Overworld — Grass Block
        ItemStack overworld = new ItemStack(Material.GRASS_BLOCK);
        ItemMeta owMeta = overworld.getItemMeta();
        owMeta.setDisplayName("§a§lโลกปกติ");
        owMeta.setLore(List.of("§7สุ่ม TP ในโลกปกติ"));
        overworld.setItemMeta(owMeta);

        // Slot 2: Nether — Netherrack
        ItemStack nether = new ItemStack(Material.NETHERRACK);
        ItemMeta neMeta = nether.getItemMeta();
        neMeta.setDisplayName("§c§lเนเทอร์");
        neMeta.setLore(List.of("§7สุ่ม TP ในเนเทอร์"));
        nether.setItemMeta(neMeta);

        // Slot 3: End — End Stone
        ItemStack end = new ItemStack(Material.END_STONE);
        ItemMeta enMeta = end.getItemMeta();
        enMeta.setDisplayName("§e§lดิ เอนด์");
        enMeta.setLore(List.of("§7สุ่ม TP ในดิ เอนด์"));
        end.setItemMeta(enMeta);

        // Hopper layout: [OW] [NE] [EN] with empty slots 0 and 4 as padding
        gui.setItem(1, overworld);
        gui.setItem(2, nether);
        gui.setItem(3, end);

        player.openInventory(gui);
    }

    public void teleportToWorld(Player player, World.Environment env) {
        try {
            // Log all loaded worlds for debugging
            plugin.getLogger().info("Loaded worlds:");
            for (World w : plugin.getServer().getWorlds()) {
                plugin.getLogger().info(" - " + w.getName() + " (env: " + w.getEnvironment() + ")");
            }

            World world = null;
            for (World w : plugin.getServer().getWorlds()) {
                if (w.getEnvironment() == env) {
                    world = w;
                    break;
                }
            }

            if (world == null) {
                player.sendMessage("§cไม่พบมิติ §e" + getWorldName(env) + " §cในเซิร์ฟเวอร์");
                player.sendMessage("§7กรุณาแจ้งแอดมินให้ตรวจสอบว่า world มิตินี้ถูกโหลดอยู่");
                return;
            }

            final World targetWorld = world;
            player.sendMessage("§aกำลังหาพิกัดสุ่มใน §e" + getWorldName(env) + "§a...");

            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    Location safeLoc = findSafeLocation(targetWorld, env);

                    if (safeLoc == null) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                player.sendMessage("§cไม่สามารถหาพิกัดที่ปลอดภัยได้ กรุณาลองใหม่"));
                        return;
                    }

                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        try {
                            player.teleport(safeLoc);
                            player.sendMessage("§aTP สำเร็จ! §7พิกัด: §e" +
                                    safeLoc.getBlockX() + ", " + safeLoc.getBlockY() + ", " + safeLoc.getBlockZ());
                        } catch (Exception e) {
                            plugin.getLogger().severe("Teleport failed: " + e.getMessage());
                            player.sendMessage("§cเกิดข้อผิดพลาดขณะ TP กรุณาลองใหม่");
                        }
                    });
                } catch (Exception e) {
                    plugin.getLogger().severe("RTP async error: " + e.getMessage());
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            player.sendMessage("§cเกิดข้อผิดพลาด: " + e.getMessage()));
                }
            });

        } catch (Exception e) {
            plugin.getLogger().severe("RTP command error: " + e.getMessage());
            player.sendMessage("§cเกิดข้อผิดพลาด กรุณาแจ้งแอดมิน");
        }
    }

    private String getWorldName(World.Environment env) {
        return switch (env) {
            case NORMAL -> "โลกปกติ";
            case NETHER -> "เนเทอร์";
            case THE_END -> "ดิ เอนด์";
            default -> "ไม่รู้จัก";
        };
    }

    private Location findSafeLocation(World world, World.Environment env) {
        for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
            int x = randomCoord();
            int z = randomCoord();

            Chunk chunk = world.getChunkAt(x >> 4, z >> 4);
            if (!chunk.isLoaded()) chunk.load();

            int y;
            if (env == World.Environment.NETHER) {
                // In Nether scan from y=30 upward for safe spot
                y = findNetherY(world, x, z);
            } else {
                y = world.getHighestBlockYAt(x, z);
            }

            if (y < world.getMinHeight() || y >= world.getMaxHeight()) continue;

            Location loc = new Location(world, x + 0.5, y + 1, z + 0.5);
            if (isSafe(loc)) return loc;
        }
        return null;
    }

    private int findNetherY(World world, int x, int z) {
        for (int y = 30; y < 120; y++) {
            Location loc = new Location(world, x, y, z);
            if (isSafe(loc)) return y - 1;
        }
        return -1;
    }

    private int randomCoord() {
        int range = RTP_RADIUS - RTP_MIN;
        int value = RTP_MIN + random.nextInt(range);
        return random.nextBoolean() ? value : -value;
    }

    private boolean isSafe(Location loc) {
        World world = loc.getWorld();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        Material ground = world.getBlockAt(x, y - 1, z).getType();
        Material feet   = world.getBlockAt(x, y,     z).getType();
        Material head   = world.getBlockAt(x, y + 1, z).getType();

        return ground.isSolid()
                && ground != Material.LAVA
                && ground != Material.MAGMA_BLOCK
                && feet.isAir()
                && head.isAir()
                && y > world.getMinHeight()
                && y < world.getMaxHeight();
    }
}
