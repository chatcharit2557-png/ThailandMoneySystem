package com.example.tpplugin;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;

public class RtpCommand implements CommandExecutor {

    private final TPPlugin plugin;
    private final Random random = new Random();

    // Radius around world center to teleport within (blocks)
    private static final int RTP_RADIUS = 5000;
    // Minimum distance from world center
    private static final int RTP_MIN = 500;
    // Max attempts to find a safe location
    private static final int MAX_ATTEMPTS = 10;

    public RtpCommand(TPPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cคำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น");
            return true;
        }

        if (!player.hasPermission("tpplugin.rtp")) {
            player.sendMessage("§cคุณไม่มีสิทธิ์ใช้คำสั่งนี้");
            return true;
        }

        player.sendMessage("§aกำลังหาพิกัดสุ่ม...");

        // Run async to avoid blocking main thread during chunk loading
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            World world = player.getWorld();
            Location safeLoc = findSafeLocation(world);

            if (safeLoc == null) {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        player.sendMessage("§cไม่สามารถหาพิกัดที่ปลอดภัยได้ กรุณาลองใหม่อีกครั้ง"));
                return;
            }

            // Teleport must happen on main thread
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                player.teleport(safeLoc);
                player.sendMessage("§aTP สำเร็จ! §7พิกัด: §e" +
                        safeLoc.getBlockX() + ", " + safeLoc.getBlockY() + ", " + safeLoc.getBlockZ());
            });
        });

        return true;
    }

    private Location findSafeLocation(World world) {
        for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
            int x = randomCoord();
            int z = randomCoord();

            // Load chunk sync to get correct Y
            Chunk chunk = world.getChunkAt(x >> 4, z >> 4);
            if (!chunk.isLoaded()) chunk.load();

            int y = world.getHighestBlockYAt(x, z);
            Location loc = new Location(world, x + 0.5, y + 1, z + 0.5);

            if (isSafe(loc)) {
                return loc;
            }
        }
        return null;
    }

    private int randomCoord() {
        int range = RTP_RADIUS - RTP_MIN;
        int value = RTP_MIN + random.nextInt(range);
        return random.nextBoolean() ? value : -value;
    }

    private boolean isSafe(Location loc) {
        World world = loc.getWorld();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        Material ground = world.getBlockAt(x, y - 1, z).getType();
        Material feet = world.getBlockAt(x, y, z).getType();
        Material head = world.getBlockAt(x, y + 1, z).getType();

        // Ground must be solid, feet & head must be passable (air-like)
        return ground.isSolid()
                && ground != Material.LAVA
                && ground != Material.WATER
                && feet.isAir()
                && head.isAir()
                && y > world.getMinHeight()
                && y < world.getMaxHeight();
    }
}
