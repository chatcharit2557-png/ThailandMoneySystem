package com.example.tpplugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TpaCommand implements CommandExecutor {

    private final TPPlugin plugin;
    private final TpaManager tpaManager;

    public TpaCommand(TPPlugin plugin, TpaManager tpaManager) {
        this.plugin = plugin;
        this.tpaManager = tpaManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player requester)) {
            sender.sendMessage("§cคำสั่งนี้ใช้ได้เฉพาะผู้เล่นเท่านั้น");
            return true;
        }

        if (!requester.hasPermission("tpplugin.tpa")) {
            requester.sendMessage("§cคุณไม่มีสิทธิ์ใช้คำสั่งนี้");
            return true;
        }

        if (args.length < 1) {
            requester.sendMessage("§cการใช้งาน: /tpa <ชื่อผู้เล่น>");
            return true;
        }

        Player target = plugin.getServer().getPlayer(args[0]);

        if (target == null || !target.isOnline()) {
            requester.sendMessage("§cไม่พบผู้เล่น §e" + args[0] + " §cในเซิร์ฟเวอร์");
            return true;
        }

        if (target.equals(requester)) {
            requester.sendMessage("§cคุณไม่สามารถส่งคำขอ TP ถึงตัวเองได้");
            return true;
        }

        tpaManager.addRequest(requester, target);

        requester.sendMessage("§aส่งคำขอ TP ไปยัง §e" + target.getName() + " §aแล้ว รอการอนุญาต...");
        target.sendMessage("§e" + requester.getName() + " §aต้องการ Teleport มาหาคุณ!");
        target.sendMessage("§7พิมพ์ §a/tpaccept §7เพื่ออนุญาต หรือ §c/tpdeny §7เพื่อปฏิเสธ §7(หมดเวลาใน 30 วินาที)");

        return true;
    }
}
