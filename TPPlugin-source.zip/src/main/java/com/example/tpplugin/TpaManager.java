package com.example.tpplugin;

import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages pending TPA requests.
 * Key   = target player UUID (the one who must accept/deny)
 * Value = requester player UUID (the one who wants to teleport)
 */
public class TpaManager {

    private final TPPlugin plugin;
    // target UUID -> requester UUID
    private final Map<UUID, UUID> pendingRequests = new HashMap<>();
    // target UUID -> expiry task
    private final Map<UUID, BukkitTask> expiryTasks = new HashMap<>();

    private static final int TIMEOUT_SECONDS = 30;

    public TpaManager(TPPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Store a new TPA request and schedule auto-expiry.
     */
    public void addRequest(Player requester, Player target) {
        UUID targetId = target.getUniqueId();

        // Cancel any previous pending request for this target
        cancelRequest(targetId);

        pendingRequests.put(targetId, requester.getUniqueId());

        // Schedule expiry
        BukkitTask task = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (pendingRequests.containsKey(targetId)) {
                pendingRequests.remove(targetId);
                expiryTasks.remove(targetId);

                // Notify both players if they're still online
                Player req = plugin.getServer().getPlayer(requester.getUniqueId());
                Player tgt = plugin.getServer().getPlayer(targetId);

                if (req != null) req.sendMessage("§cคำขอ TP ของคุณไปยัง §e" + target.getName() + " §cหมดเวลาแล้ว");
                if (tgt != null) tgt.sendMessage("§cคำขอ TP จาก §e" + requester.getName() + " §cหมดเวลาแล้ว");
            }
        }, TIMEOUT_SECONDS * 20L);

        expiryTasks.put(targetId, task);
    }

    /**
     * Returns the requester UUID for the given target, or null if none.
     */
    public UUID getRequester(UUID targetId) {
        return pendingRequests.get(targetId);
    }

    /**
     * Remove and cancel the request for a target.
     */
    public void cancelRequest(UUID targetId) {
        pendingRequests.remove(targetId);
        BukkitTask task = expiryTasks.remove(targetId);
        if (task != null) task.cancel();
    }

    public boolean hasRequest(UUID targetId) {
        return pendingRequests.containsKey(targetId);
    }
}
