#!/bin/bash
cd /workspaces/TPPlugin
unzip TPPlugin-source.zip -d TPPlugin
cd TPPlugin
mvn clean package
echo "✅ Build complete! TPPlugin.jar is ready in target/"
