package com.globalmarket.commands;

import com.globalmarket.GlobalMarket;
import com.globalmarket.utils.GUIUtils;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class SellCommand implements CommandExecutor {

    private final GlobalMarket plugin;

    public SellCommand(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.player-only")));
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission("globalmarket.sell")) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }

        ItemStack inHand = player.getInventory().getItemInMainHand();
        if (inHand.getType() == Material.AIR) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix")
                    + plugin.getConfig().getString("messages.no-item-in-hand")));
            return true;
        }

        String currency = plugin.getConfig().getString("economy.currency-symbol", "$");
        double earned = plugin.getShopManager().sellItemToShop(player, inHand);

        if (earned < 0) {
            player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix")
                    + "&cไม่สามารถขายไอเทมนี้ได้ ไม่มีในร้านค้า"));
            return true;
        }

        double tax = earned * plugin.getConfig().getDouble("economy.tax-rate", 0.05) / (1 - plugin.getConfig().getDouble("economy.tax-rate", 0.05));
        String itemName = inHand.getType().name().replace("_", " ");
        int amount = inHand.getAmount();

        player.sendMessage(GUIUtils.color(plugin.getConfig().getString("messages.prefix")
                + "&aขายได้! &e" + itemName + " &7x" + amount
                + " &a→ &6" + currency + String.format("%.2f", earned)
                + " &7(ภาษี: &c" + currency + String.format("%.2f", tax) + "&7)"));

        return true;
    }
}
