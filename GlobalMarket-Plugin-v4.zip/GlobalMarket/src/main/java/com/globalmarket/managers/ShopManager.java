package com.globalmarket.managers;

import com.globalmarket.GlobalMarket;
import com.globalmarket.models.ShopItem;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

public class ShopManager {

    private final GlobalMarket plugin;
    private final Map<String, ShopItem> shopItems = new LinkedHashMap<>();

    public ShopManager(GlobalMarket plugin) {
        this.plugin = plugin;
        loadAllItems();
    }

    private void loadAllItems() {

        // ══════════════════════════════════════
        // 🪵 ไม้และบล็อกพื้นฐาน
        // ══════════════════════════════════════
        addItem("oak_log",        Material.OAK_LOG,        "ท่อนไม้โอ๊ก",       "blocks", 8,   4,  -1);
        addItem("spruce_log",     Material.SPRUCE_LOG,     "ท่อนไม้สน",         "blocks", 8,   4,  -1);
        addItem("birch_log",      Material.BIRCH_LOG,      "ท่อนไม้เบิร์ช",     "blocks", 8,   4,  -1);
        addItem("jungle_log",     Material.JUNGLE_LOG,     "ท่อนไม้ป่า",        "blocks", 8,   4,  -1);
        addItem("acacia_log",     Material.ACACIA_LOG,     "ท่อนไม้อะเคเซีย",  "blocks", 8,   4,  -1);
        addItem("dark_oak_log",   Material.DARK_OAK_LOG,   "ท่อนไม้ดาร์กโอ๊ก", "blocks", 8,   4,  -1);
        addItem("mangrove_log",   Material.MANGROVE_LOG,   "ท่อนไม้โกงกาง",    "blocks", 10,  5,  -1);
        addItem("cherry_log",     Material.CHERRY_LOG,     "ท่อนไม้เชอร์รี่",  "blocks", 12,  6,  -1);
        addItem("bamboo",         Material.BAMBOO,          "ไม้ไผ่",            "blocks", 3,   1,  -1);
        addItem("oak_planks",     Material.OAK_PLANKS,     "ไม้กระดาน",        "blocks", 3,   1,  -1);
        addItem("stick",          Material.STICK,           "ไม้",               "blocks", 1,   0,  -1);

        // ══════════════════════════════════════
        // 🪨 หิน / แร่ทั่วไป
        // ══════════════════════════════════════
        addItem("cobblestone",    Material.COBBLESTONE,    "หินสกัด",          "blocks", 2,   1,  -1);
        addItem("stone",          Material.STONE,           "หิน",              "blocks", 3,   1,  -1);
        addItem("stone_bricks",   Material.STONE_BRICKS,   "อิฐหิน",           "blocks", 5,   2,  -1);
        addItem("granite",        Material.GRANITE,         "หินแกรนิต",        "blocks", 3,   1,  -1);
        addItem("diorite",        Material.DIORITE,         "หินไดโอไรต์",      "blocks", 3,   1,  -1);
        addItem("andesite",       Material.ANDESITE,        "หินแอนดีไซต์",     "blocks", 3,   1,  -1);
        addItem("gravel",         Material.GRAVEL,          "กรวด",             "blocks", 2,   1,  -1);
        addItem("sand",           Material.SAND,            "ทราย",             "blocks", 2,   1,  -1);
        addItem("red_sand",       Material.RED_SAND,        "ทรายแดง",          "blocks", 3,   1,  -1);
        addItem("clay",           Material.CLAY,            "ดินเหนียว",        "blocks", 5,   2,  -1);
        addItem("clay_ball",      Material.CLAY_BALL,       "ก้อนดินเหนียว",    "materials", 2, 1, -1);
        addItem("dirt",           Material.DIRT,            "ดิน",              "blocks", 2,   1,  -1);
        addItem("grass_block",    Material.GRASS_BLOCK,     "บล็อกหญ้า",        "blocks", 3,   1,  -1);
        addItem("obsidian",       Material.OBSIDIAN,        "ออบซิเดียน",       "blocks", 60,  30, -1);
        addItem("netherrack",     Material.NETHERRACK,      "หินเนเธอร์",       "blocks", 2,   1,  -1);
        addItem("soul_sand",      Material.SOUL_SAND,       "ทรายวิญญาณ",      "blocks", 8,   4,  -1);
        addItem("soul_soil",      Material.SOUL_SOIL,       "ดินวิญญาณ",        "blocks", 8,   4,  -1);
        addItem("basalt",         Material.BASALT,          "บะซอลต์",          "blocks", 4,   2,  -1);
        addItem("blackstone",     Material.BLACKSTONE,      "หินดำ",            "blocks", 5,   2,  -1);
        addItem("end_stone",      Material.END_STONE,       "หินเอนด์",         "blocks", 15,  7,  -1);

        // ══════════════════════════════════════
        // 💎 แร่และวัตถุดิบหลัก
        // ══════════════════════════════════════
        addItem("coal",              Material.COAL,              "ถ่านหิน",          "materials", 10,   5,  -1);
        addItem("charcoal",          Material.CHARCOAL,          "ถ่านไม้",          "materials", 8,    4,  -1);
        addItem("raw_iron",          Material.RAW_IRON,          "เหล็กดิบ",         "materials", 25,   12, -1);
        addItem("iron_ingot",        Material.IRON_INGOT,        "เหล็กแท่ง",        "materials", 60,   30, -1);
        addItem("raw_copper",        Material.RAW_COPPER,        "ทองแดงดิบ",        "materials", 15,   7,  -1);
        addItem("copper_ingot",      Material.COPPER_INGOT,      "ทองแดงแท่ง",       "materials", 35,   17, -1);
        addItem("raw_gold",          Material.RAW_GOLD,          "ทองดิบ",           "materials", 60,   30, -1);
        addItem("gold_ingot",        Material.GOLD_INGOT,        "ทองแท่ง",          "materials", 150,  75, -1);
        addItem("gold_nugget",       Material.GOLD_NUGGET,       "เศษทอง",           "materials", 18,   9,  -1);
        addItem("redstone",          Material.REDSTONE,          "เรดสโตน",          "materials", 20,   10, -1);
        addItem("lapis_lazuli",      Material.LAPIS_LAZULI,      "ลาพิส",            "materials", 25,   12, -1);
        addItem("diamond",           Material.DIAMOND,           "เพชร",             "materials", 600,  300,-1);
        addItem("emerald",           Material.EMERALD,           "มรกต",             "materials", 500,  250,-1);
        addItem("quartz",            Material.QUARTZ,            "ควอตซ์",           "materials", 15,   7,  -1);
        addItem("amethyst_shard",    Material.AMETHYST_SHARD,    "เศษอเมทิสต์",     "materials", 20,   10, -1);
        addItem("netherite_scrap",   Material.NETHERITE_SCRAP,   "เศษเนเธอไรท์",    "materials", 1200, 600,-1);
        addItem("netherite_ingot",   Material.NETHERITE_INGOT,   "เนเธอไรท์แท่ง",   "materials", 5500, 2750,-1);
        addItem("flint",             Material.FLINT,              "หินเหล็กไฟ",       "materials", 5,   2,  -1);
        addItem("string",            Material.STRING,             "เชือก",            "materials", 8,   4,  -1);
        addItem("feather",           Material.FEATHER,            "ขนนก",             "materials", 8,   4,  -1);
        addItem("leather",           Material.LEATHER,            "หนัง",             "materials", 15,  7,  -1);
        addItem("rabbit_hide",       Material.RABBIT_HIDE,        "หนังกระต่าย",      "materials", 8,   4,  -1);
        addItem("bone",              Material.BONE,               "กระดูก",           "materials", 10,  5,  -1);
        addItem("bone_meal",         Material.BONE_MEAL,          "ผงกระดูก",         "materials", 4,   2,  -1);
        addItem("gunpowder",         Material.GUNPOWDER,          "ดินปืน",           "materials", 20,  10, -1);
        addItem("slimeball",         Material.SLIME_BALL,         "ก้อนสไลม์",        "materials", 25,  12, -1);
        addItem("magma_cream",       Material.MAGMA_CREAM,        "ครีมแมกม่า",       "materials", 30,  15, -1);
        addItem("blaze_rod",         Material.BLAZE_ROD,          "แท่งเบลซ",         "materials", 60,  30, -1);
        addItem("blaze_powder",      Material.BLAZE_POWDER,       "ผงเบลซ",           "materials", 35,  17, -1);
        addItem("ender_pearl",       Material.ENDER_PEARL,        "ไข่มุกเอนเดอร์",  "materials", 60,  30, -1);
        addItem("ender_eye",         Material.ENDER_EYE,          "ตาเอนเดอร์",       "materials", 120, 60, -1);
        addItem("ghast_tear",        Material.GHAST_TEAR,         "น้ำตาแกสต์",       "materials", 100, 50, -1);
        addItem("spider_eye",        Material.SPIDER_EYE,         "ตาแมงมุม",         "materials", 15,  7,  -1);
        addItem("fermented_spider_eye", Material.FERMENTED_SPIDER_EYE, "ตาแมงมุมหมัก","materials", 25, 12, -1);
        addItem("ink_sac",           Material.INK_SAC,            "ถุงหมึก",          "materials", 8,   4,  -1);
        addItem("glow_ink_sac",      Material.GLOW_INK_SAC,       "ถุงหมึกเรืองแสง", "materials", 20,  10, -1);
        addItem("prismarine_shard",  Material.PRISMARINE_SHARD,   "เศษพริสมารีน",    "materials", 15,  7,  -1);
        addItem("prismarine_crystals",Material.PRISMARINE_CRYSTALS,"คริสตัลพริสมารีน","materials", 20,  10, -1);
        addItem("nautilus_shell",    Material.NAUTILUS_SHELL,     "เปลือกหอยนอติลัส","materials", 150, 75, -1);
        addItem("heart_of_sea",      Material.HEART_OF_THE_SEA,   "ใจกลางทะเล",      "materials", 1000,500,-1);
        addItem("honeycomb",         Material.HONEYCOMB,          "รังผึ้ง",          "materials", 20,  10, -1);
        addItem("honey_bottle",      Material.HONEY_BOTTLE,       "ขวดน้ำผึ้ง",      "materials", 25,  12, -1);
        addItem("phantom_membrane",  Material.PHANTOM_MEMBRANE,   "เยื่อแฟนทอม",     "materials", 80,  40, -1);
        addItem("scute",             Material.SCUTE,              "เกล็ดเต่า",        "materials", 100, 50, -1);
        addItem("dragon_breath",     Material.DRAGON_BREATH,      "ลมหายใจมังกร",    "materials", 500, 250,-1);
        addItem("shulker_shell",     Material.SHULKER_SHELL,      "เปลือกชูลเกอร์",  "materials", 300, 150,-1);
        addItem("elytra",            Material.ELYTRA,             "ปีกอีลิทรา",       "materials", 8000,4000,-1);
        addItem("totem_of_undying",  Material.TOTEM_OF_UNDYING,   "โทเทมแห่งชีวิต",  "materials", 3000,1500,-1);
        addItem("nether_star",       Material.NETHER_STAR,        "ดาวเนเธอร์",       "materials", 10000,5000,-1);

        // ══════════════════════════════════════
        // 🌾 เกษตร / พืช
        // ══════════════════════════════════════
        addItem("wheat",             Material.WHEAT,              "ข้าวสาลี",         "food", 5,   2,  -1);
        addItem("wheat_seeds",       Material.WHEAT_SEEDS,        "เมล็ดข้าวสาลี",   "food", 2,   1,  -1);
        addItem("carrot",            Material.CARROT,             "แครอท",            "food", 6,   3,  -1);
        addItem("potato",            Material.POTATO,             "มันฝรั่ง",         "food", 5,   2,  -1);
        addItem("baked_potato",      Material.BAKED_POTATO,       "มันฝรั่งอบ",       "food", 10,  5,  -1);
        addItem("beetroot",          Material.BEETROOT,           "บีทรูต",           "food", 5,   2,  -1);
        addItem("beetroot_seeds",    Material.BEETROOT_SEEDS,     "เมล็ดบีทรูต",      "food", 2,   1,  -1);
        addItem("pumpkin",           Material.PUMPKIN,            "ฟักทอง",           "food", 15,  7,  -1);
        addItem("melon_slice",       Material.MELON_SLICE,        "แตงโมชิ้น",        "food", 4,   2,  -1);
        addItem("melon",             Material.MELON,              "แตงโม",            "food", 30,  15, -1);
        addItem("sugar_cane",        Material.SUGAR_CANE,         "อ้อย",             "food", 4,   2,  -1);
        addItem("sugar",             Material.SUGAR,              "น้ำตาล",           "food", 3,   1,  -1);
        addItem("cocoa_beans",       Material.COCOA_BEANS,        "เมล็ดโกโก้",       "food", 6,   3,  -1);
        addItem("nether_wart",       Material.NETHER_WART,        "หัวนเธอร์วอร์ต",  "food", 15,  7,  -1);
        addItem("kelp",              Material.KELP,               "สาหร่าย",          "food", 2,   1,  -1);
        addItem("dried_kelp",        Material.DRIED_KELP,         "สาหร่ายแห้ง",      "food", 1,   0,  -1);
        addItem("dried_kelp_block",  Material.DRIED_KELP_BLOCK,   "บล็อกสาหร่ายแห้ง","blocks", 5, 2,  -1);
        addItem("mushroom_brown",    Material.BROWN_MUSHROOM,     "เห็ดน้ำตาล",       "food", 8,   4,  -1);
        addItem("mushroom_red",      Material.RED_MUSHROOM,       "เห็ดแดง",          "food", 8,   4,  -1);
        addItem("flower_dandelion",  Material.DANDELION,          "ดอกแดนดิไลออน",   "misc", 3,   1,  -1);
        addItem("flower_poppy",      Material.POPPY,              "ดอกป็อปปี้",       "misc", 3,   1,  -1);
        addItem("flower_rose",       Material.ROSE_BUSH,          "กุหลาบ",           "misc", 5,   2,  -1);
        addItem("flower_sunflower",  Material.SUNFLOWER,          "ทานตะวัน",         "misc", 5,   2,  -1);
        addItem("cactus",            Material.CACTUS,             "กระบองเพชร",       "blocks", 5,  2,  -1);
        addItem("vines",             Material.VINE,               "เถาวัลย์",         "blocks", 3,  1,  -1);
        addItem("lily_pad",          Material.LILY_PAD,           "ใบบัว",            "blocks", 5,  2,  -1);

        // ══════════════════════════════════════
        // 🍖 อาหาร
        // ══════════════════════════════════════
        addItem("bread",             Material.BREAD,              "ขนมปัง",           "food", 15,  7,  -1);
        addItem("cookie",            Material.COOKIE,             "คุกกี้",           "food", 5,   2,  -1);
        addItem("cake",              Material.CAKE,               "เค้ก",             "food", 100, 50, -1);
        addItem("pumpkin_pie",       Material.PUMPKIN_PIE,        "พายฟักทอง",        "food", 30,  15, -1);
        addItem("raw_beef",          Material.BEEF,               "เนื้อวัวดิบ",      "food", 15,  7,  -1);
        addItem("cooked_beef",       Material.COOKED_BEEF,        "สเต็กเนื้อวัว",   "food", 40,  20, -1);
        addItem("raw_chicken",       Material.CHICKEN,            "ไก่ดิบ",           "food", 10,  5,  -1);
        addItem("cooked_chicken",    Material.COOKED_CHICKEN,     "ไก่ทอด",           "food", 30,  15, -1);
        addItem("raw_porkchop",      Material.PORKCHOP,           "เนื้อหมูดิบ",      "food", 12,  6,  -1);
        addItem("cooked_porkchop",   Material.COOKED_PORKCHOP,    "เนื้อหมูทอด",     "food", 35,  17, -1);
        addItem("raw_mutton",        Material.MUTTON,             "เนื้อแกะดิบ",      "food", 12,  6,  -1);
        addItem("cooked_mutton",     Material.COOKED_MUTTON,      "เนื้อแกะทอด",     "food", 30,  15, -1);
        addItem("raw_rabbit",        Material.RABBIT,             "กระต่ายดิบ",       "food", 12,  6,  -1);
        addItem("cooked_rabbit",     Material.COOKED_RABBIT,      "กระต่ายทอด",      "food", 30,  15, -1);
        addItem("raw_salmon",        Material.SALMON,             "แซลมอนดิบ",        "food", 10,  5,  -1);
        addItem("cooked_salmon",     Material.COOKED_SALMON,      "แซลมอนย่าง",      "food", 25,  12, -1);
        addItem("raw_cod",           Material.COD,                "ปลาค็อดดิบ",       "food", 8,   4,  -1);
        addItem("cooked_cod",        Material.COOKED_COD,         "ปลาค็อดย่าง",     "food", 20,  10, -1);
        addItem("tropical_fish",     Material.TROPICAL_FISH,      "ปลาเขตร้อน",      "food", 15,  7,  -1);
        addItem("pufferfish",        Material.PUFFERFISH,         "ปลาปักเป้า",       "food", 15,  7,  -1);
        addItem("golden_apple",      Material.GOLDEN_APPLE,       "แอปเปิ้ลทอง",     "food", 500, 250,-1);
        addItem("enchanted_golden_apple", Material.ENCHANTED_GOLDEN_APPLE, "แอปเปิ้ลทองมนตร์","food", 5000,2500,-1);
        addItem("apple",             Material.APPLE,              "แอปเปิ้ล",         "food", 10,  5,  -1);
        addItem("chorus_fruit",      Material.CHORUS_FRUIT,       "ผลคอรัส",          "food", 15,  7,  -1);
        addItem("rabbit_stew",       Material.RABBIT_STEW,        "ซุปกระต่าย",       "food", 60,  30, -1);
        addItem("mushroom_stew",     Material.MUSHROOM_STEW,      "ซุปเห็ด",          "food", 40,  20, -1);
        addItem("beetroot_soup",     Material.BEETROOT_SOUP,      "ซุปบีทรูต",        "food", 40,  20, -1);
        addItem("suspicious_stew",   Material.SUSPICIOUS_STEW,    "ซุปน่าสงสัย",     "food", 30,  15, -1);

        // ══════════════════════════════════════
        // ⚔️ อาวุธ
        // ══════════════════════════════════════
        addItem("wood_sword",    Material.WOODEN_SWORD,    "ดาบไม้",           "weapons", 30,   10, -1);
        addItem("stone_sword",   Material.STONE_SWORD,     "ดาบหิน",           "weapons", 80,   30, -1);
        addItem("iron_sword",    Material.IRON_SWORD,      "ดาบเหล็ก",         "weapons", 350,  120,-1);
        addItem("gold_sword",    Material.GOLDEN_SWORD,    "ดาบทอง",           "weapons", 200,  70, -1);
        addItem("diamond_sword", Material.DIAMOND_SWORD,   "ดาบเพชร",          "weapons", 2500, 900,-1);
        addItem("netherite_sword",Material.NETHERITE_SWORD,"ดาบเนเธอไรท์",    "weapons", 12000,5000,-1);
        addItem("bow",           Material.BOW,              "ธนู",              "weapons", 250,  90, -1);
        addItem("crossbow",      Material.CROSSBOW,         "ครอสโบว์",         "weapons", 500,  200,-1);
        addItem("trident",       Material.TRIDENT,          "ตรีศูล",           "weapons", 3000, 1200,-1);
        addItem("arrow",         Material.ARROW,            "ลูกธนู",           "weapons", 3,    1,  -1);
        addItem("spectral_arrow",Material.SPECTRAL_ARROW,   "ลูกธนูสเปคตรัล",  "weapons", 8,    4,  -1);

        // ══════════════════════════════════════
        // 🛡️ เกราะ
        // ══════════════════════════════════════
        addItem("leather_helmet",    Material.LEATHER_HELMET,     "หมวกหนัง",         "armor", 50,   15, -1);
        addItem("leather_chest",     Material.LEATHER_CHESTPLATE, "เสื้อเกราะหนัง",   "armor", 100,  30, -1);
        addItem("leather_legs",      Material.LEATHER_LEGGINGS,   "กางเกงหนัง",       "armor", 80,   25, -1);
        addItem("leather_boots",     Material.LEATHER_BOOTS,      "รองเท้าหนัง",      "armor", 50,   15, -1);
        addItem("iron_helmet",       Material.IRON_HELMET,        "หมวกเหล็ก",        "armor", 300,  100,-1);
        addItem("iron_chest",        Material.IRON_CHESTPLATE,    "เสื้อเกราะเหล็ก",  "armor", 600,  200,-1);
        addItem("iron_legs",         Material.IRON_LEGGINGS,      "กางเกงเหล็ก",      "armor", 500,  170,-1);
        addItem("iron_boots",        Material.IRON_BOOTS,         "รองเท้าเหล็ก",     "armor", 300,  100,-1);
        addItem("gold_helmet",       Material.GOLDEN_HELMET,      "หมวกทอง",          "armor", 200,  65, -1);
        addItem("gold_chest",        Material.GOLDEN_CHESTPLATE,  "เสื้อเกราะทอง",    "armor", 400,  130,-1);
        addItem("gold_legs",         Material.GOLDEN_LEGGINGS,    "กางเกงทอง",        "armor", 350,  115,-1);
        addItem("gold_boots",        Material.GOLDEN_BOOTS,       "รองเท้าทอง",       "armor", 200,  65, -1);
        addItem("diamond_helmet",    Material.DIAMOND_HELMET,     "หมวกเพชร",         "armor", 1800, 700,-1);
        addItem("diamond_chest",     Material.DIAMOND_CHESTPLATE, "เสื้อเกราะเพชร",   "armor", 3600, 1400,-1);
        addItem("diamond_legs",      Material.DIAMOND_LEGGINGS,   "กางเกงเพชร",       "armor", 3000, 1200,-1);
        addItem("diamond_boots",     Material.DIAMOND_BOOTS,      "รองเท้าเพชร",      "armor", 1800, 700,-1);
        addItem("netherite_helmet",  Material.NETHERITE_HELMET,   "หมวกเนเธอไรท์",   "armor", 8000, 3500,-1);
        addItem("netherite_chest",   Material.NETHERITE_CHESTPLATE,"เสื้อเกราะเนเธอไรท์","armor",16000,7000,-1);
        addItem("netherite_legs",    Material.NETHERITE_LEGGINGS, "กางเกงเนเธอไรท์",  "armor", 13000,5500,-1);
        addItem("netherite_boots",   Material.NETHERITE_BOOTS,    "รองเท้าเนเธอไรท์", "armor", 8000, 3500,-1);
        addItem("turtle_helmet",     Material.TURTLE_HELMET,      "หมวกเต่า",         "armor", 1500, 600,-1);
        addItem("shield",            Material.SHIELD,             "โล่",              "armor", 200,  80, -1);

        // ══════════════════════════════════════
        // ⛏️ เครื่องมือ
        // ══════════════════════════════════════
        addItem("wood_pickaxe",    Material.WOODEN_PICKAXE,    "จอบไม้",           "tools", 25,   8,  -1);
        addItem("stone_pickaxe",   Material.STONE_PICKAXE,     "จอบหิน",           "tools", 70,   25, -1);
        addItem("iron_pickaxe",    Material.IRON_PICKAXE,      "จอบเหล็ก",         "tools", 400,  140,-1);
        addItem("gold_pickaxe",    Material.GOLDEN_PICKAXE,    "จอบทอง",           "tools", 220,  75, -1);
        addItem("diamond_pickaxe", Material.DIAMOND_PICKAXE,   "จอบเพชร",          "tools", 2200, 850,-1);
        addItem("netherite_pickaxe",Material.NETHERITE_PICKAXE,"จอบเนเธอไรท์",    "tools", 11000,4500,-1);
        addItem("iron_axe",        Material.IRON_AXE,          "ขวานเหล็ก",        "tools", 400,  140,-1);
        addItem("diamond_axe",     Material.DIAMOND_AXE,       "ขวานเพชร",         "tools", 2200, 850,-1);
        addItem("iron_shovel",     Material.IRON_SHOVEL,       "พลั่วเหล็ก",        "tools", 300,  100,-1);
        addItem("diamond_shovel",  Material.DIAMOND_SHOVEL,    "พลั่วเพชร",         "tools", 1800, 700,-1);
        addItem("iron_hoe",        Material.IRON_HOE,          "คราดเหล็ก",        "tools", 250,  85, -1);
        addItem("diamond_hoe",     Material.DIAMOND_HOE,       "คราดเพชร",         "tools", 1500, 600,-1);
        addItem("netherite_hoe",   Material.NETHERITE_HOE,     "คราดเนเธอไรท์",   "tools", 7000, 3000,-1);
        addItem("fishing_rod",     Material.FISHING_ROD,       "เบ็ดตกปลา",        "tools", 150,  50, -1);
        addItem("flint_and_steel", Material.FLINT_AND_STEEL,   "เหล็กจุดไฟ",       "tools", 100,  40, -1);
        addItem("shears",          Material.SHEARS,            "กรรไกรตัดขน",      "tools", 150,  60, -1);
        addItem("bucket",          Material.BUCKET,            "ถัง",              "tools", 150,  60, -1);
        addItem("water_bucket",    Material.WATER_BUCKET,      "ถังน้ำ",           "tools", 200,  80, -1);
        addItem("lava_bucket",     Material.LAVA_BUCKET,       "ถังลาวา",          "tools", 300,  120,-1);
        addItem("compass",         Material.COMPASS,           "เข็มทิศ",          "tools", 200,  80, -1);
        addItem("clock",           Material.CLOCK,             "นาฬิกา",           "tools", 250,  100,-1);
        addItem("spyglass",        Material.SPYGLASS,          "กล้องส่องทางไกล",  "tools", 500,  200,-1);

        // ══════════════════════════════════════
        // 🧪 ยาและยาดื่ม
        // ══════════════════════════════════════
        addItem("glass_bottle",        Material.GLASS_BOTTLE,         "ขวดแก้ว",          "potions", 10,   4,  -1);
        addItem("potion_healing",      Material.POTION,               "ยาฟื้นฟู",          "potions", 150,  60, -1);
        addItem("splash_healing",      Material.SPLASH_POTION,        "ยาฟื้นฟู (ปา)",    "potions", 200,  80, -1);
        addItem("potion_regen",        Material.POTION,               "ยาฟื้นฟูต่อเนื่อง","potions", 200,  80, -1);
        addItem("potion_speed",        Material.POTION,               "ยาเร็ว",           "potions", 120,  50, -1);
        addItem("potion_strength",     Material.POTION,               "ยาแข็งแกร่ง",      "potions", 150,  60, -1);
        addItem("potion_fire_resist",  Material.POTION,               "ยากันไฟ",          "potions", 180,  70, -1);
        addItem("potion_night_vision", Material.POTION,               "ยามองกลางคืน",     "potions", 100,  40, -1);
        addItem("potion_invisibility", Material.POTION,               "ยาล่องหน",         "potions", 180,  70, -1);
        addItem("potion_water_breath", Material.POTION,               "ยาหายใจใต้น้ำ",   "potions", 150,  60, -1);
        addItem("potion_slow_fall",    Material.POTION,               "ยาชะลอการตก",      "potions", 120,  50, -1);
        addItem("potion_luck",         Material.POTION,               "ยาโชค",            "potions", 500,  200,-1);

        // ══════════════════════════════════════
        // 🏗️ บล็อกตกแต่งและพิเศษ
        // ══════════════════════════════════════
        addItem("glass",             Material.GLASS,              "กระจก",            "blocks", 8,   4,  -1);
        addItem("glass_pane",        Material.GLASS_PANE,         "กระจกบาง",         "blocks", 3,   1,  -1);
        addItem("bookshelf",         Material.BOOKSHELF,          "ชั้นหนังสือ",      "blocks", 80,  35, -1);
        addItem("chest",             Material.CHEST,              "หีบ",              "blocks", 60,  25, -1);
        addItem("trapped_chest",     Material.TRAPPED_CHEST,      "หีบกับดัก",        "blocks", 80,  35, -1);
        addItem("barrel",            Material.BARREL,             "ถังเก็บของ",        "blocks", 80,  35, -1);
        addItem("furnace",           Material.FURNACE,            "เตาหลอม",          "blocks", 50,  20, -1);
        addItem("blast_furnace",     Material.BLAST_FURNACE,      "เตาหลอมแรงสูง",   "blocks", 200, 80, -1);
        addItem("smoker",            Material.SMOKER,             "เตาอบ",            "blocks", 100, 40, -1);
        addItem("crafting_table",    Material.CRAFTING_TABLE,     "โต๊ะงานฝีมือ",    "blocks", 30,  12, -1);
        addItem("anvil",             Material.ANVIL,              "ทั่ง",             "blocks", 500, 200,-1);
        addItem("enchanting_table",  Material.ENCHANTING_TABLE,   "โต๊ะร่ายเวทย์",   "blocks", 2000,800,-1);
        addItem("brewing_stand",     Material.BREWING_STAND,      "ขาตั้งกลั่น",     "blocks", 500, 200,-1);
        addItem("beacon",            Material.BEACON,             "บีคอน",            "blocks", 15000,7000,-1);
        addItem("conduit",           Material.CONDUIT,            "คอนดูอิต",         "blocks", 5000,2000,-1);
        addItem("bell",              Material.BELL,               "ระฆัง",            "blocks", 1000,400,-1);
        addItem("lantern",           Material.LANTERN,            "โคมไฟ",            "blocks", 30,  12, -1);
        addItem("soul_lantern",      Material.SOUL_LANTERN,       "โคมวิญญาณ",        "blocks", 35,  15, -1);
        addItem("torch",             Material.TORCH,              "คบเพลิง",          "blocks", 2,   1,  -1);
        addItem("soul_torch",        Material.SOUL_TORCH,         "คบเพลิงวิญญาณ",   "blocks", 3,   1,  -1);
        addItem("glowstone",         Material.GLOWSTONE,          "หินเรืองแสง",      "blocks", 40,  18, -1);
        addItem("glowstone_dust",    Material.GLOWSTONE_DUST,     "ผงหินเรืองแสง",   "materials", 12, 6, -1);
        addItem("sea_lantern",       Material.SEA_LANTERN,        "โคมทะเล",          "blocks", 50,  22, -1);
        addItem("shroomlight",       Material.SHROOMLIGHT,        "ชรูมไลต์",         "blocks", 30,  13, -1);
        addItem("magma_block",       Material.MAGMA_BLOCK,        "บล็อกแมกม่า",      "blocks", 20,  9,  -1);
        addItem("tnt",               Material.TNT,                "ทีเอ็นที",         "blocks", 60,  25, -1);
        addItem("wool_white",        Material.WHITE_WOOL,         "ขนแกะขาว",         "blocks", 10,  4,  -1);
        addItem("carpet_white",      Material.WHITE_CARPET,       "พรมขาว",           "blocks", 5,   2,  -1);
        addItem("terracotta",        Material.TERRACOTTA,         "เทอราคอตต้า",      "blocks", 8,   3,  -1);
        addItem("honeycomb_block",   Material.HONEYCOMB_BLOCK,    "บล็อกรังผึ้ง",    "blocks", 50,  20, -1);
        addItem("hay_block",         Material.HAY_BLOCK,          "บล็อกฟาง",         "blocks", 25,  10, -1);
        addItem("slime_block",       Material.SLIME_BLOCK,        "บล็อกสไลม์",       "blocks", 200, 80, -1);
        addItem("honey_block",       Material.HONEY_BLOCK,        "บล็อกน้ำผึ้ง",    "blocks", 150, 60, -1);
        addItem("ice",               Material.ICE,                "น้ำแข็ง",          "blocks", 8,   3,  -1);
        addItem("packed_ice",        Material.PACKED_ICE,         "น้ำแข็งอัด",       "blocks", 15,  6,  -1);
        addItem("blue_ice",          Material.BLUE_ICE,           "น้ำแข็งสีน้ำเงิน","blocks", 30,  12, -1);
        addItem("snow_block",        Material.SNOW_BLOCK,         "บล็อกหิมะ",        "blocks", 5,   2,  -1);
        addItem("snowball",          Material.SNOWBALL,           "ก้อนหิมะ",         "misc", 2,   1,  -1);

        // ══════════════════════════════════════
        // ⚡ เรดสโตน
        // ══════════════════════════════════════
        addItem("redstone_block",   Material.REDSTONE_BLOCK,    "บล็อกเรดสโตน",     "misc", 150, 60, -1);
        addItem("piston",           Material.PISTON,            "ลูกสูบ",            "misc", 60,  25, -1);
        addItem("sticky_piston",    Material.STICKY_PISTON,     "ลูกสูบกาว",        "misc", 90,  35, -1);
        addItem("lever",            Material.LEVER,             "สวิตช์",           "misc", 10,  4,  -1);
        addItem("observer",         Material.OBSERVER,          "ออปเซิร์ฟเวอร์",   "misc", 80,  35, -1);
        addItem("dispenser",        Material.DISPENSER,         "เครื่องจ่าย",       "misc", 100, 40, -1);
        addItem("dropper",          Material.DROPPER,           "ท่อดร็อป",          "misc", 80,  30, -1);
        addItem("hopper",           Material.HOPPER,            "ช่องตวัก",          "misc", 120, 50, -1);
        addItem("comparator",       Material.COMPARATOR,        "คอมพาราเตอร์",     "misc", 30,  12, -1);
        addItem("repeater",         Material.REPEATER,          "รีพีตเตอร์",        "misc", 20,  8,  -1);
        addItem("daylight_detector",Material.DAYLIGHT_DETECTOR, "ตัวตรวจจับแสง",    "misc", 60,  25, -1);

        // ══════════════════════════════════════
        // 📚 หนังสือและ Enchanting
        // ══════════════════════════════════════
        addItem("book",             Material.BOOK,              "หนังสือ",           "misc", 15,  6,  -1);
        addItem("bookshelf2",       Material.BOOKSHELF,         "ชั้นหนังสือ",       "misc", 80,  35, -1);
        addItem("enchanted_book",   Material.ENCHANTED_BOOK,    "หนังสือมนตร์",     "misc", 200, 80, -1);
        addItem("name_tag",         Material.NAME_TAG,          "แท็กชื่อ",          "misc", 300, 120,-1);
        addItem("lead",             Material.LEAD,              "เชือกจูง",          "misc", 50,  20, -1);
        addItem("saddle",           Material.SADDLE,            "อานม้า",            "misc", 300, 120,-1);
        addItem("map",              Material.MAP,               "แผนที่",            "misc", 50,  20, -1);
        addItem("paper",            Material.PAPER,             "กระดาษ",            "misc", 5,   2,  -1);

        // ══════════════════════════════════════
        // 💀 Drop จากมอนสเตอร์
        // ══════════════════════════════════════
        addItem("rotten_flesh",     Material.ROTTEN_FLESH,     "เนื้อเน่า",         "misc", 3,   1,  -1);
        addItem("bone2",            Material.BONE,             "กระดูก",            "misc", 10,  5,  -1);
        addItem("arrow2",           Material.ARROW,            "ลูกธนู",            "misc", 3,   1,  -1);
        addItem("wither_rose",      Material.WITHER_ROSE,      "กุหลาบวิเธอร์",    "misc", 50,  20, -1);
        addItem("wither_skeleton_skull", Material.WITHER_SKELETON_SKULL, "กะโหลกวิเธอร์สเกลตัน", "misc", 2000, 800, -1);
    }

    private void addItem(String id, Material mat, String name, String category,
                         double buy, double sell, int stock) {
        shopItems.put(id, new ShopItem(id, mat, name, category, buy, sell, stock));
    }

    public List<ShopItem> getItemsByCategory(String category) {
        return shopItems.values().stream()
                .filter(i -> i.getCategory().equals(category) && i.isEnabled())
                .collect(Collectors.toList());
    }

    public List<ShopItem> getAllItems() {
        return new ArrayList<>(shopItems.values());
    }

    public ShopItem getItem(String id) {
        return shopItems.get(id);
    }

    public boolean buyItem(Player player, ShopItem item, int amount) {
        double totalPrice = item.getBuyPrice() * amount;
        if (!plugin.getEconomyManager().hasEnough(player, totalPrice)) return false;
        if (!item.isUnlimitedStock() && item.getStock() < amount) return false;
        plugin.getEconomyManager().withdraw(player, totalPrice);
        player.getInventory().addItem(new ItemStack(item.getMaterial(), amount));
        if (!item.isUnlimitedStock()) item.setStock(item.getStock() - amount);
        return true;
    }

    public double sellItemToShop(Player player, ItemStack itemStack) {
        double sellPrice = getSellPrice(itemStack.getType());
        if (sellPrice <= 0) return -1;
        double total = sellPrice * itemStack.getAmount();
        double tax = total * plugin.getConfig().getDouble("economy.tax-rate", 0.05);
        double net = total - tax;
        player.getInventory().remove(itemStack);
        plugin.getEconomy().depositPlayer(player, net);
        return net;
    }

    public double getSellPrice(Material material) {
        return shopItems.values().stream()
                .filter(i -> i.getMaterial() == material)
                .mapToDouble(ShopItem::getSellPrice)
                .findFirst()
                .orElse(-1);
    }
}
