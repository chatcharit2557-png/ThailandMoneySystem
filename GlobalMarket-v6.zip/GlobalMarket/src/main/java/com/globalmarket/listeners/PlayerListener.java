package com.globalmarket.listeners;

import com.globalmarket.GlobalMarket;
import com.globalmarket.gui.CommandMenuGUI;
import com.globalmarket.utils.CoinItem;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;

public class PlayerListener implements Listener {

    private final GlobalMarket plugin;

    public PlayerListener(GlobalMarket plugin) {
        this.plugin = plugin;
    }

    // ให้เหรียญตอน login
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        if (plugin.getConfig().getBoolean("sidebar.enabled", true)
                && player.hasPermission("globalmarket.sidebar")) {
            plugin.getSidebarManager().updateSidebar(player);
        }

        plugin.getDataManager().givePendingReturns(player);

        // ให้เหรียญถ้ายังไม่มี
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!hasCoin(player)) {
                giveCoin(player);
            }
        }, 20L);
    }

    // คลิกขวาด้วยเหรียญ → เปิดเมนู
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();

        if (item == null) return;
        if (!CoinItem.isCoin(plugin, item)) return;

        Action action = event.getAction();
        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            CommandMenuGUI.open(player, plugin);
        }
    }

    // ห้ามทิ้งเหรียญ
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        if (CoinItem.isCoin(plugin, event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(
                    com.globalmarket.utils.GUIUtils.color("&8[&6Market&8] &c⚠ ทิ้งเหรียญตลาดไม่ได้!"));
        }
    }

    // ห้ามคลิกเหรียญใน inventory ไปวางที่อื่น (shift-click ออก)
    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;

        ItemStack current = event.getCurrentItem();
        ItemStack cursor  = event.getCursor();

        if (CoinItem.isCoin(plugin, current) || CoinItem.isCoin(plugin, cursor)) {
            // อนุญาตเฉพาะเคลื่อนย้ายใน hotbar ของตัวเอง
            if (event.getClickedInventory() == event.getWhoClicked().getInventory()) {
                // อนุญาตให้ย้ายใน inventory ผู้เล่น
                return;
            }
            event.setCancelled(true);
        }
    }

    // ห้ามเก็บเหรียญที่พื้น (กรณีใครพยายาม dupe)
    @EventHandler
    public void onPickupItem(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        // เหรียญไม่ควรหลุดพื้น แต่ถ้าหลุด ไม่ต้องทำอะไร
    }

    // ให้เหรียญผู้เล่น
    public void giveCoin(Player player) {
        ItemStack coin = CoinItem.create(plugin);
        // หาช่อง hotbar ว่าง (slot 0-8)
        for (int i = 0; i < 9; i++) {
            ItemStack existing = player.getInventory().getItem(i);
            if (existing == null || existing.getType() == org.bukkit.Material.AIR) {
                player.getInventory().setItem(i, coin);
                player.sendMessage(com.globalmarket.utils.GUIUtils.color(
                        "&8[&6Market&8] &aได้รับ &6✦ เหรียญตลาด &aแล้ว! &7คลิกขวาเพื่อใช้งาน"));
                return;
            }
        }
        // ถ้าไม่มีช่องว่างใน hotbar ให้ใน inventory ปกติ
        player.getInventory().addItem(coin);
        player.sendMessage(com.globalmarket.utils.GUIUtils.color(
                "&8[&6Market&8] &aได้รับ &6✦ เหรียญตลาด &aแล้ว! &7คลิกขวาเพื่อใช้งาน"));
    }

    private boolean hasCoin(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (CoinItem.isCoin(plugin, item)) return true;
        }
        return false;
    }
}
