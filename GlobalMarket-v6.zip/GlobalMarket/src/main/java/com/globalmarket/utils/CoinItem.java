package com.globalmarket.utils;

import com.globalmarket.GlobalMarket;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;

public class CoinItem {

    private static final String KEY = "market_coin";

    public static NamespacedKey getKey(GlobalMarket plugin) {
        return new NamespacedKey(plugin, KEY);
    }

    public static ItemStack create(GlobalMarket plugin) {
        ItemStack item = new ItemStack(Material.SUNFLOWER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(GUIUtils.color("&6&l✦ เหรียญตลาด ✦"));
        meta.setLore(Arrays.asList(
                GUIUtils.color("&7─────────────────"),
                GUIUtils.color("&e&lคลิกขวา &fเพื่อเปิดเมนูตลาด"),
                GUIUtils.color("&7ซื้อ ขาย ประมูล ทุกอย่าง"),
                GUIUtils.color("&7─────────────────"),
                GUIUtils.color("&c⚠ ทิ้งหรือขายไม่ได้!")));

        // tag พิเศษเพื่อระบุว่าเป็น coin จริง
        meta.getPersistentDataContainer().set(
                getKey(plugin), PersistentDataType.BYTE, (byte) 1);

        item.setItemMeta(meta);
        return item;
    }

    public static boolean isCoin(GlobalMarket plugin, ItemStack item) {
        if (item == null || item.getType() != Material.SUNFLOWER) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer()
                .has(getKey(plugin), PersistentDataType.BYTE);
    }
}
